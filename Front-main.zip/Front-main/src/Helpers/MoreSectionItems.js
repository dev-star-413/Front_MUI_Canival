const items = [
    {
        title: `${props.year} ${props.title} About`,
        target: `/festivals/${props.id}`,
    },
    {
        title: `${props.year} ${props.title} Parade Info`,
        target: `/festivals/${props.id}/paradeinfo`,
    },
    {
        title: `${props.year} ${props.title} Costume Band`,
        target: `/festivals/${props.id}/costumeband`,
    },
    {
        title: `${props.year} ${props.title} Event/Galley`,
        target: `/festivals/${props.id}/eventgallery`,
    },
    {
        title: `${props.year} ${props.title} Things to do`,
        target: `/festivals/${props.id}/thingstodo`,
    },
    {
        title: `${props.year} ${props.title} Guides and Reviews`,
        target: `/festivals/${props.id}/guidesandreviews`,
    },
    {
        title: `${props.year} ${props.title} News`,
        target: `/festivals/${props.id}/news`,
    },
    {
        title: `${props.year} ${props.title} Results`,
        target: `/festivals/${props.id}/results`,
    },
    {
        title: `Things Travelers should know for ${props.year} ${props.title}`,
        target: `/festivals/${props.id}/travelersshouldknow`,
    },
    {
        title: `${props.title} History`,
        target: `/festivals/${props.id}/history`,
    }
];