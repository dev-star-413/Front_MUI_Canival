const sidebarItems = [
    {
        title:"Reviews-Rate Bands",
        target:"UR" // user review
    },
    {
        target: '/festivals',
        title: 'Carnivals',
    },
    {
        target: '/events',
        title: 'Events & Fetes',
    },
    {
        target: '/bands',
        title: 'Carnival Bands',
    },
    {
        target: '/designers?sort=year',
        title: 'Designers',
    },
    {
        target: '/blogs',
        title: 'Blog',
    },
    // {
    //     target: '/trade',
    //     title: 'Buy-Sell-Trade',
    // },
    // {
    //     target: '/awards',
    //     title: 'Results',
    // },
]

export default sidebarItems;