import React, {useEffect, useState, useRef, useMemo} from "react";
import "../../assets/styles/Festival.css";
import {getFestivalWhole, getPastYears} from "../../functions/api";
import {Link} from "react-router-dom";
import "@fortawesome/fontawesome-free/css/all.css"
import "../../App.css"
import {LazyLoadImage, LazyLoadComponent} from 'react-lazy-load-image-component';
import FadeLoader from "react-spinners/FadeLoader";
import generateAddressImg from "../../functions/generateAddressImg";
import ReactCountryFlag from "react-country-flag"
import { Alert } from "react-bootstrap";
import NotFoundImage from "../../assets/imgs/image-not-found.jpg";
import CardCompare from "../../components/CardCompare";
import Advertisement from "../../components/Advertisement";
import {BsChevronCompactDown} from "react-icons/all";

const Slideshow = React.lazy(() => import("../../components/SlideShow"));
const Counter = React.lazy(() => import("../../components/Counter"))
const Map = React.lazy(() => import('../../components/Map'))
const RateSection = React.lazy(() => import('../../components/Festival/RateSection'));

export default function Carnival({match}) {
    const [festival, setFestival] = useState(null);
    const [festivalDate,setFestivalDate]=useState()
    const navRef = useRef(null);
    const menuRef=useRef()
    const menuRef2=useRef()
    const [fDate, setFDate]=useState(null)
    const[fixNavBar,setFixNavBar]=useState(false)
    const[navWidth,setNavWidth]=useState(100)
    const [listGuides,setListGuides]=useState([])
    const [listNews,setListNews]=useState([])
    const [listReviews,setListReviews]=useState([])
    const [typeSlide,setTypeSlide]=useState("list")
    const [openSlide,setOpenSlide]=useState(false)
    const [imageSlide,setImageSlide]=useState([])
    const [selectImage,setSelectImage]=useState(null)
    const [bands,setBands]=useState([])
    const [futureFestival,setFutureFestival]=useState([])
    const [awards,setAwards]=useState([])
    const [gallery,setGallery]=useState([])
    const [mainImg,setMainImg]=useState({})
    const [adultBand,setAdultBand]=useState([])
    const [jouvertBand,setJouvertBand]=useState([])
    const [childrenBand,setChildrenBand]=useState([])
    const [compareBands,setCompareBands]=useState([])
    const [events,setEvents]=useState([])
    const [pastYears,setPastYears]=useState(null)
    var changeNavbar=false
    const hrStyle = {
      color: '#292b2c ',
      backgroundColor: '#292b2c ',
    }
    useEffect(()=>{
      getCarnival()
    },[])

    useEffect(function () {
        window.addEventListener('scroll',handleScroll)
        window.addEventListener("hashchange", function () {
          window.scrollTo(window.scrollX, window.scrollY - 100);
      });
    },[]);
    // change title page
    useEffect(()=>{
        document.title=(festival && festival.name)?`${festival.name} `:"Hello Carnival"
    },[festival])

    useEffect(function (){
      if(bands.length < 1 )return
      var adult=[]
      var jouvert=[]
      var children=[]
      for(var b of bands){
        if(b.isChildrenService)children.push(b)
        if(b.isCustomeService)adult.push(b)
        if(b.isJouvertService)jouvert.push(b)
      }
      setAdultBand(adult)
      setJouvertBand(jouvert)
      setChildrenBand(children)
    },[bands])

    const getCarnival= async()=>{
      try {
        var slug = match.params.slug
        var res = await getFestivalWhole(slug);
        if(res && res.code!=0) {
          alert(res.msg) // FIX error handling
          if(res.code==1) window.location.href="/festivals"
          return
        }
        var {festival,news,festivalDate,galleries,nextDates,awards,bands,guides,compareBands,events}=res.data
        let pastYears = await getPastYears(festival._id);
        setPastYears(pastYears.filter(p => p.year !== festivalDate.year));  // remove the current (last) page's festival date from the list
        setEvents(events);
        setFestival(festival)
        setBands(bands)
        setFutureFestival(nextDates)
        setAwards(awards)
        setListNews(news)
        setGallery(galleries)
        setFestivalDate(festivalDate)
        if(festivalDate.img) setMainImg(festivalDate.img)
        else setMainImg(festival.mainImage)
        var SToE=festivalDate && festivalDate.bestS
        if(festivalDate && festivalDate.bestE) SToE+=' to '+ festivalDate.bestE
        setFDate(SToE)
        setListGuides(guides)
        setCompareBands(compareBands)
      } catch (error) {
          console.error(error)
          alert("Something is wrong, please try again. ")
      }
    }


    const handleScroll = ({ element ,useWindow})=> {
        var navBarRect=navRef && navRef.current && navRef.current.getBoundingClientRect();
        if(navBarRect && navBarRect.y<53 && !changeNavbar){
            setFixNavBar(true)
            setNavWidth(navBarRect.width)
        }
        else if(navBarRect && navBarRect.y>50 ){
            setFixNavBar(false)
        }
    }

    function scrollLeft(){
        if(menuRef && menuRef.current) menuRef.current.scrollLeft+=-50
        menuRef2.current.scrollLeft+=-50
    }

    function scrollRight(){
        if(menuRef && menuRef.current) menuRef.current.scrollLeft+=50
        menuRef2.current.scrollLeft+=50
    }

    function handleActionSlide(){
        setOpenSlide(!openSlide)
    }

    function Navbar() {
        return <>
            {festivalDate &&
                <>
                    {((festivalDate && festivalDate.theme) || (festivalDate && festivalDate.intro)) && <><a
                        className="p-3 text-white" href="#section-about">About</a><span className="text-secondary">|</span></>}
                    {(adultBand && adultBand[0]) && <><a className="p-3 text-white" href="#section-costumes">Costumes</a><span
                        className="text-secondary">|</span></>}
                    {((festivalDate.pImg && festivalDate.pImg.path) || (festivalDate.paradeS || festivalDate.paradeE || festivalDate.paradeLocation) ||
                      festivalDate.paradeDesc || (festivalDate.paradeGeo || festivalDate.cityLatlng)
                    ) && <><a className="p-3 text-white text-nowrap" href="#section-adult">Adult Parade</a><span
                        className="text-secondary">|</span></>}
                    {((festivalDate.jImg && festivalDate.jImg.path) || (festivalDate.jouvertStartDate || festivalDate.jouvertEndDate || festivalDate.jouvertAddress) || festivalDate.jouvert) &&
                        <><a className="p-3 text-white" href="#section-jouvert">Jouvert</a><span
                            className="text-secondary">|</span></>}
                    {((festivalDate.childrenImage && festivalDate.childrenImage.path) || festivalDate.childrenDesc ||
                        (festivalDate.childrenStartD || festivalDate.childrenEndD || festivalDate.childrenParadeAddress)
                    ) && <><a className="p-3 text-white" href="#section-children">Children</a><span
                        className="text-secondary">|</span></>}
                    {events && events.filter((event) => event.isActive ).length > 0 && <><a className="p-3 text-white" href="#section-events">Events
                    </a><span className="text-secondary">|</span></>}
                    {gallery && gallery.length > 0 && <><a className="p-3 text-white" href="#section-photos">Photos</a><span
                        className="text-secondary">|</span></>}
                    {(awards && awards.length > 0) && <><a className="p-3 text-white" href="#section-results">Results</a><span
                        className="text-secondary">|</span></>}
                    {(festival || pastYears || pastYears[0]) && (pastYears.filter(p => p.bands.length > 0).length > 0) &&
                        <><a className="p-3 text-white" href="#section-past">Past Years</a><span
                        className="text-secondary">|</span></>}
                    {listNews.length > 0 && <><a className="p-3 text-white" href="#section-news">News</a><span
                        className="text-secondary">|</span></>}
                    {/* {festivalDate && festivalDate.slug && <><a className="p-3 text-white text-nowrap"
                                                               href={"/festivals/" + festivalDate.slug}>{festivalDate.year}</a></>} */}
                </>
            }
        </>
    }
    //----------dif sections of page
    function AboutSection(){
      if(!festival || !festivalDate) return <></>
      return (
        <div id="section-about">
            {(festivalDate.theme || festivalDate.intro) &&
                <div className="pt-3 pb-1">
                    <h2 className="text-capitalize">About {festival && festival.name} {festivalDate.year}</h2>
                    {festivalDate.theme &&
                        <div className="col-12 pb-1">
                            <span className="text-capitalize"> Carnival Theme: {festivalDate.theme}</span>
                        </div>
                    }
                    {festivalDate.intro &&
                        <div className="col-12 pt-1">
                            <span>{festivalDate.intro}</span>
                        </div>
                    }
                    <hr style={hrStyle}/>
                </div>
            }
        </div>
      )
    }

    function GuideSection(){
      if(!festival || !festivalDate) return <></>
      if(listGuides.length <1 && !festivalDate.guide ) return <></>
      var content=[]

      for (var index of listGuides){
        var href=(index && index.slug)?`/blogs/${index.slug}`: " "
        content.push( <li key={href}><a className="py-1" href={href}>{index.title}</a></li> )
      }

      return(
          <div id="section-guides">
            <div className="py-2">
              <h3 className="text-capitalize">
                {festival.name} {festivalDate.year}  Guides
              </h3>
              <div className="col-12" dangerouslySetInnerHTML={{__html:festivalDate.guide}}></div>
              <ul key="guidesKey">
                {content}
              </ul>
            </div>
            <hr style={hrStyle} />
          </div>
      )
    }
    function FutureFestivalSection(){
      if(!festival || !festivalDate) return <></>
      if(futureFestival.length < 1) return <></>
      var content=[]
      for (var ff  of futureFestival){
        content.push(
          <li>
            <span className="py-1">
              {festival.name} Parade {ff.year} - {(ff.paradeS)?ff.paradeS:""}
            </span>
          </li>
        )
      }
      return(
        <div id="future-section">
          <div className="py-2">
            <h3 className="text-capitalize">
              Future {festival.name} Parade Dates
            </h3>
            <ul key=" ">
              {content}
            </ul>
          </div>
          <hr style={hrStyle} />
        </div>
      )

    }
    function ParticipatingBands(){
      if(bands.length < 1 || !festival || !festivalDate) return <></>
      var confirm=[]
      var unConfirm=[]
      for(var b of bands){
        var actived=false;
        var types=[]
        if(b.isChildrenService)types.push('Children')
        if(b.isCustomeService)types.push('Adult')
        if(b.isJouvertService)types.push('Jouvert')
        if(b.theme || b.sections >0) actived=true
        if(b.confirm){
          confirm.push(
            <li className="col-md-6" key={b && b._id}>
              <Link  to={`/bands/${b.slug}`}>
                {b.name} {(types && types[0])?' ('+types.join(', ')+') ':""} {(actived)?'  [active]':""}
              </Link>
            </li>
          )
        }else{
          unConfirm.push(
            <li className="col-md-6" key={b && b._id}>
              <Link  to={`/bands/${b.slug}`}>
              {b.name}
              {(types && types[0])?' ('+types.join(', ')+') ':""}
              </Link>

            </li>
          )
        }
      }

      return(
        <div className="py-2">
            {(confirm && confirm[0] || unConfirm && unConfirm[0]) &&
                <>
                    <h2 className="mb-2">{festival.name} {festivalDate.year} Pariticiptaing Bands</h2>
                    {(confirm && confirm[0]) ?
                        <>
                            <label>Confirmed</label>
                            <ul className="row pt-2">
                                {confirm}
                            </ul>
                        </>
                        : ""
                    }
                    {(unConfirm && unConfirm[0]) ?
                        <>
                            <label>Unconfirmed</label>
                            <ul className="row pt-2">
                                {unConfirm}
                            </ul>
                        </>
                        : ""
                    }
                    <div className="py-2" dangerouslySetInnerHTML={{__html: festival.costume}}/>
                </>
            }
        </div>
      )
    }

  
    function AdultCostumeBands(){
      var costumeContent=[]
      if(adultBand.length < 1) return null
      for (let i in adultBand){
        let slug= (adultBand && adultBand[i]) ? adultBand[i].slug : ''
        costumeContent.push(
          <Link to={'/bands/'+slug}  key={i} className="col-lg-6 col-md-6 col-sm-12 col-12 my-2" >
              <div className="row">
                <div className="col-5">
                    <LazyLoadImage className="img-fluid" src={
                        (adultBand[i].costumeImg && adultBand[i].costumeImg.path) ?
                            generateAddressImg(adultBand[i].costumeImg.path, 208, 117)
                            : (adultBand[i].costumeLImg && adultBand[i].costumeLImg.path) ?
                                generateAddressImg(adultBand[i].costumeLImg.path, 208, 117)
                                : (adultBand[i].mainImg && adultBand[i].mainImg.path) ?
                                    generateAddressImg(adultBand[i].mainImg.path, 208, 117)
                                    : NotFoundImage}
                    />
                </div>
                <div className="col-7 " >
                  <div className="text-dark" >
                    <h5 className='pt-2'>
                      {adultBand && adultBand[i].name} {adultBand && adultBand[i].year}
                    </h5>
                      {adultBand && adultBand[i].theme ? <h6>Theme: {adultBand[i].theme}</h6> : ''}
                      {adultBand && adultBand[i].lDate ? <small>Launch: {adultBand[i].lDate}</small> : ''}
                  </div>
                </div>
              </div>
          </Link>
        )
      }
      return (
        <div className="py-2" id="section-costumes">
          <h2 className="text-capitalize">Costume and Mas Bands Launch Date at {festival.name} {festivalDate.year}</h2>
          <div className="py-2" dangerouslySetInnerHTML={{__html: festivalDate.costume}}/>
          <div className="row">
            {costumeContent}
          </div>
        </div>
      )
    }
    function JouvertBands(){
      var costumeContent=[]
      if(jouvertBand.length < 1) return null
      for (let i in jouvertBand){
        let slug= (jouvertBand && jouvertBand[i]) ? jouvertBand[i].slug : ''
        costumeContent.push(
          <Link to={'/bands/'+slug}  key={i} className="col-lg-6 col-md-6 col-sm-12 col-12 my-2" >
              <div className="row">
                <div className="col-5">
                    <LazyLoadImage className="img-fluid" src={
                        (jouvertBand[i].jImg && jouvertBand[i].jImg.path) ?
                            generateAddressImg(jouvertBand[i].jImg.path, 208, 117)
                            : (jouvertBand[i].jlImg && jouvertBand[i].jlImg.path) ?
                                generateAddressImg(jouvertBand[i].jlImg.path, 208, 117)
                                : (jouvertBand[i].mainImg && jouvertBand[i].mainImg.path) ?
                                    generateAddressImg(jouvertBand[i].mainImg.path, 208, 117)
                                    : NotFoundImage}
                    />
                </div>
                <div className="col-7 " >
                  <div className="text-dark" >
                    <h5 className='pt-2'>
                      {jouvertBand && jouvertBand[i] && jouvertBand[i].name} {jouvertBand && jouvertBand[i] && jouvertBand[i].year}
                    </h5>
                      {jouvertBand && jouvertBand[i].theme ? <h6>Theme: {jouvertBand[i].theme}</h6> : ''}
                      {jouvertBand && jouvertBand[i].sections ? <small>Sections: [{jouvertBand[i].sections}]</small> : ''}
                  </div>
                </div>
              </div>
          </Link>
        )
      }
      return (
        <div className="py-2">
          <h2 className="text-capitalize">Jouvert Bands at {festival.name} {festivalDate.year}</h2>
          <div className="row">
            {costumeContent}
          </div>
        </div>
      )
    }
    function ChildrenBands(){
      var costumeContent=[]
      if(childrenBand.length < 1) return null
      for (let i in childrenBand){
        let slug= (childrenBand && childrenBand[i]) ? childrenBand[i].slug : ''
        costumeContent.push(
          <Link to={'/bands/'+slug}  key={i} className="col-lg-6 col-md-6 col-sm-12 col-12 my-2" >
              <div className="row">
                <div className="col-5">
                  <LazyLoadImage className="img-fluid" src={
                      (childrenBand[i].childrenImg && childrenBand[i].childrenImg.path) ?
                          generateAddressImg(childrenBand[i].childrenImg.path, 208, 117)
                          : (childrenBand[i].childrenlImg && childrenBand[i].childrenlImg.path) ?
                              generateAddressImg(childrenBand[i].childrenlImg.path, 208, 117)
                              : (childrenBand[i].mainImg && childrenBand[i].mainImg.path) ?
                                  generateAddressImg(childrenBand[i].mainImg.path, 208, 117)
                                  : NotFoundImage}
                  />
                </div>
                <div className="col-7 " >
                  <div className="text-dark" >
                    <h5 className='pt-2'>
                      {childrenBand && childrenBand[i].name} {childrenBand && childrenBand[i].year}
                    </h5>
                    {childrenBand && childrenBand[i].theme ? <h6>Theme: {childrenBand[i].theme}</h6> : '' }
                    {childrenBand && childrenBand[i].lDate ? <small>Launch: {childrenBand[i].lDate}</small> : '' }
                  </div>
                </div>
              </div>
          </Link>
        )
      }
      return (
        <div className="py-2">
          <h2 className="text-capitalize">Children Costume Bands at {festival.name} {festivalDate.year}</h2>
          <div className="row">
            {costumeContent}
          </div>
        </div>
      )
    }
    function EventSection () {
        if(!events || events.length < 1 || !festival || !festivalDate) return null
        var content=[]
        if (events.filter(event => event.isActive ).length < 1) return (<></>);
        for (let i in events){
            if (!events[i].isActive) continue;
            let slug= (events && events[i]) ? events[i].slug : ''
            content.push(
                <Link to={'/events/' + slug}  key={i} className="col-lg-6 col-md-6 col-sm-12 col-12 my-2" >
                    <div className="row">
                        <div className="col-5">
                            <LazyLoadImage className="img-fluid" src={
                                (events[i].imgs && events[i].imgs[0] && events[i].imgs[0].path) ?
                                    generateAddressImg(events[i].imgs[0].path, 208, 117)
                                    : NotFoundImage}
                            />
                        </div>
                        <div className="col-7 " >
                            <div className="text-dark" >
                                <h5 className='pt-2'>
                                    {events && events[i].name} {events[i]?.price}$
                                </h5>
                                {events && events[i]?.sDate || events[i]?.city?.name ? <h6>{events[i].sDate} @ {events[i]?.city.name}</h6> : '' }
                            </div>
                        </div>
                    </div>
                </Link>
            )
        }
        return (
            <>
                <hr style={hrStyle}/>
                <div className="py-2" id={'section-events'}>
                    <h2 className="text-capitalize">{festival.name} top events</h2>
                    {festivalDate.event && <div className="p-2 " dangerouslySetInnerHTML={{__html:festivalDate.event}}></div>}
                    <div className="row">
                        {content}
                    </div>
                </div>
            </>
        )
    }
    const MemorizedMap = useMemo(function MemorizedMap () {
        if(!festival || !festivalDate || !(festivalDate.paradeGeo || festivalDate.cityLatlng)) return <></>
        return (
                    <div className="py-2">
                        <h2 className="text-capitalize">{festival.name} {festivalDate.year} Parade Route</h2>
                        <React.Suspense fallback={<div style={{
                            position: "fixed",
                            top: "50%",
                            left: "50%",
                            transform: "translate(-50%, -50%)"
                        }}><FadeLoader size={150}/></div>}>
                            <LazyLoadComponent>
                                <Map paradeGeo={festivalDate.paradeGeo ? festivalDate.paradeGeo : ''} city={festivalDate.cityLatlng}/>
                            </LazyLoadComponent>
                        </React.Suspense>
                    </div>
        )
    }, [festivalDate])
    function AdultSection () {
      if(!festival || !festivalDate) return <></>
      return (
          <div id="section-adult">
              {((festivalDate.pImg && festivalDate.pImg.path) || (festivalDate.paradeS || festivalDate.paradeE || festivalDate.paradeLocation) ||
                  festivalDate.paradeDesc || (festivalDate.paradeGeo || festivalDate.cityLatlng)
                  ) &&
                  <>
                      <h2>{festival.name} Adult Parade {festivalDate.year} </h2>

                      {(festivalDate.pImg && festivalDate.pImg.path) ?
                          <div className="text-center my-2"><LazyLoadImage className="img-fluid "
                                                                           src={generateAddressImg(festivalDate.pImg.path, 720, 405)}/>
                          </div> : festival.paradeImage && festival.paradeImage.path ?
                          <div className="text-center my-2"><LazyLoadImage className="img-fluid "
                                                                           src={generateAddressImg(festival.paradeImage && festival.paradeImage.path, 720, 405)}/>
                          </div>  : ""
                      }

                      {(festivalDate.paradeS || festivalDate.paradeE || festivalDate.paradeLocation) ?
                          <div className="py-2">
                              <h3>When and Where is {festival.name} Parade {festivalDate.year}</h3>
                              {
                                  (festivalDate.paradeS || festivalDate.paradeE) ?
                                      <div className="py-2">
                                          <span>Date/Time</span><br/>
                                          {festivalDate.paradeS &&
                                              <b>Starts: {festivalDate.paradeS} to</b>
                                          }
                                          <br/>
                                          {festivalDate.paradeE &&
                                              <b>Ends: {festivalDate.paradeE}</b>
                                          }
                                      </div>
                                      : ""

                              }
                              {festivalDate.paradeLocation &&
                                  <div className="py-2">
                                      Location
                                      <br/>
                                      <b>{festivalDate.paradeLocation}</b>
                                  </div>
                              }

                          </div> : ""
                      }
                      <AdultCostumeBands/>
                      <Compare/>
                      {
                          festivalDate.paradeDesc &&
                          <div className="py-2">
                              <h3>Parade Details</h3>
                              <div className="py-2" dangerouslySetInnerHTML={{__html: festivalDate.paradeDesc}}/>
                          </div>
                      }
                      {MemorizedMap}
                      <br/>
                  </>
              }
          </div>
      )
    }
    function JouvertSection(){
      if(!festival || !festivalDate) return <></>
      return (
          <div id="section-jouvert">
              {((festivalDate.jImg && festivalDate.jImg.path) || (festivalDate.jouvertStartDate || festivalDate.jouvertEndDate || festivalDate.jouvertAddress) || festivalDate.jouvert || jouvertBand.length > 0) &&
                  <>
                      <h2>{festival.name} Jouvert {festivalDate.year} </h2>

                      {(festivalDate.jImg && festivalDate.jImg.path) ?
                          <div className="text-center my-2"><LazyLoadImage className="img-fluid "
                                                                           src={generateAddressImg(festivalDate.jImg.path, 720, 405)}/>
                          </div> : festival.jouvertImage && festival.jouvertImage.path ?
                          <div className="text-center my-2"><LazyLoadImage className="img-fluid "
                                                                           src={generateAddressImg(festival.jouvertImage && festival.jouvertImage.path, 720, 405)}/>
                          </div> : ""
                      }

                      {(festivalDate.jouvertStartDate || festivalDate.jouvertEndDate || festivalDate.jouvertAddress) ?
                          <div className="py-2">
                              <h3>When and Where is {festival.name} Jouvert {festivalDate.year}</h3>
                              {
                                  (festivalDate.jouvertStartDate || festivalDate.jouvertEndDate) ?
                                      <div className="py-2">
                                          <span>Date/Time</span><br/>
                                          {festivalDate.jouvertStartDate &&
                                              <b>Starts: {festivalDate.jouvertStartDate} to</b>
                                          }
                                          <br/>
                                          {festivalDate.jouvertEndDate &&
                                              <b>Ends: {festivalDate.jouvertEndDate}</b>
                                          }
                                      </div>
                                      : ""

                              }
                              {festivalDate.jouvertAddress &&
                                  <div className="py-2">
                                      Location
                                      <br/>
                                      <b>{festivalDate.jouvertAddress}</b>
                                  </div>
                              }

                          </div> : ""
                      }
                      <JouvertBands/>
                      {
                          (festivalDate.jouvert) ?
                              <div className="py-2">
                                  <h3>{festival.name} Jouvert Details {festivalDate.year}</h3>
                                  <div className="py-2" dangerouslySetInnerHTML={{__html: festivalDate.jouvert}}/>
                              </div> :
                              festival.jouvert && <div className="py-2">
                                  <h3>{festival.name} Jouvert Details {festivalDate.year}</h3>
                                  <div className="py-2" dangerouslySetInnerHTML={{__html: festival.jouvert}}/>
                              </div>
                      }
                  </>
              }
          </div>
      )
    }
    function ChildrenSection(){
      if(!festival || !festivalDate) return <></>
      return (
          <div>
              {((festivalDate.childrenImage && festivalDate.childrenImage.path) || festivalDate.childrenDesc ||
                      (festivalDate.childrenStartD || festivalDate.childrenEndD || festivalDate.childrenParadeAddress) || childrenBand.length > 0
                  ) &&
                  <>
                      <h2>{festival.name} Children Parade {festivalDate.year} </h2>

                      {(festivalDate.childrenImage && festivalDate.childrenImage.path) ?
                          <div className="text-center my-2"><LazyLoadImage className="img-fluid "
                                                                           src={generateAddressImg(festivalDate.childrenImage.path, 720, 405)}/>
                          </div> :
                          <div className="text-center my-2"><LazyLoadImage className="img-fluid "
                                                                           src={generateAddressImg(festival.childrenImage && festival.childrenImage.path, 720, 405)}/>
                          </div>
                      }

                      {(festivalDate.childrenStartD || festivalDate.childrenEndD || festivalDate.childrenParadeAddress) ?
                          <div className="py-2">
                              <h3>When and Where is {festival.name} Children’s Parade</h3>
                              {
                                  (festivalDate.childrenStartD || festivalDate.childrenEndD) ?
                                      <div className="py-2">
                                          <span>Date/Time</span><br/>
                                          {festivalDate.childrenStartD &&
                                              <b>Starts: {festivalDate.childrenStartD} to</b>
                                          }
                                          <br/>
                                          {festivalDate.childrenEndD &&
                                              <b>Ends: {festivalDate.childrenEndD}</b>
                                          }
                                      </div>
                                      : ""

                              }
                              {festivalDate.childrenParadeAddress &&
                                  <div className="py-2">
                                      Location
                                      <br/>
                                      <b>{festivalDate.childrenParadeAddress}</b>
                                  </div>
                              }

                          </div> : ""
                      }
                      <ChildrenBands/>
                      {
                          (festivalDate.childrenDesc) ?
                              <div className="py-2">
                                  <h3>{festival.name} Children Parade Details</h3>
                                  <div className="py-2" dangerouslySetInnerHTML={{__html: festivalDate.childrenDesc}}/>
                              </div> :
                              festival.childrenDesc && <div className="py-2">
                                  <h3>{festival.name} Children Parade Details</h3>
                                  <div className="py-2" dangerouslySetInnerHTML={{__html: festival.childrenDesc}}/>
                              </div>
                      }
                      <hr style={hrStyle}/>
                  </>
              }
          </div>
      )
    }
    function PastYearsSection () {
        if(!festival || !festivalDate || !pastYears || !Array.isArray(pastYears) || !pastYears[0]) return <></>;
        let content = { main: [] };
        for (let y of pastYears) {
            if (!y.bands[0]) continue;
            content.confirmed = []
            content.unconfirmed = []

            for (let b of y.bands) {
                //  building services
                let services = [];
                let arr = [{key: 'isCustomeService', str: 'Adult'},
                    {key: 'isJouvertService', str: 'Jouvert'},
                    {key: 'isChildrenService', str: 'Children'}]
                for (let item of arr) if (b[item.key]) services.push(item.str);
                services = services.join(', ');

                //  creating confirmed and unconfirmed sections
                if (b.confirm) {
                    content.confirmed.push(
                        <li><Link to={"/bands/" + b.slug}>
                            {b.name} - {b.year} {(b.isCustomeService || b.isChildrenService || b.isJouvertService) &&
                            <span>({services})</span>
                        }
                        </Link></li>
                    )
                } else {
                    content.unconfirmed.push(
                        <li><Link to={"/bands/" + b.slug}>
                            {b.name} - {b.year} {(b.isCustomeService || b.isChildrenService || b.isJouvertService) &&
                            <span>({services})</span>
                        }
                        </Link></li>
                    )
                }
            }
            content.main.push(
                <li style={{ color: "#2e86c1" }}>
                    <details>
                        <summary className={"btn-link mb-1 row col-12"}>
                            <span>
                                {y.festival.name} - {y.year}
                                <BsChevronCompactDown className={"ml-2 p-0"}></BsChevronCompactDown>
                            </span>
                        </summary>
                        <div>
                            <h3 style={{color: 'black'}}>{y.festival.name} {y.year} participating bands</h3>
                            {content.confirmed[0] &&
                                <div className={'mt-2'}>
                                <h5 style={{color: 'black'}}>Confirmed Bands: </h5>
                                <ul style={{listStyleType:"disc"}}>{content.confirmed}</ul>
                                </div>
                            }
                            {content.unconfirmed[0] &&
                                <div className={'mt-2 mb-3'}>
                                <h5 style={{color: 'black'}}>Unconfirmed Bands: </h5>
                                <ul style={{listStyleType:"disc"}}>{content.unconfirmed}</ul>
                                </div>
                            }
                        </div>
                    </details>
                </li>
            )
        }
        return (
            <div id={'section-past'}>
                <h2>{festival.name} in the past</h2>
                <ul>{content.main}</ul>
                <hr style={hrStyle}/>
            </div>
        )
    }
    function GallerySection(){

      var content=[]
      if(!festival || !gallery || !gallery[0] ) return <></>
      for(let g of gallery){
        let img=g.imgs && g.imgs[0]
        if(!img) continue;


        let mime=img && img.mime
        if(!mime) continue;


        var images=[]
        for(var media of g.imgs){
          media.img=(media.mime && media.mime.includes('video'))?media.path : generateAddressImg(media && media.path,1120,630)
          media.name=media.text
          images.push(media)
        }

        content.push(
          <div className="my-2">
            <div className='col-sm-12'>
              <h4>{g && g.title}</h4>
              <span>
                {g && g.desc}
              </span>
            </div>
            <div className="my-2 row">
              {images.map((img,index)=>{
                if(index >7)return
                let mime=img.mime
                return(
                  <div key={img && img._id} className="col-sm-4 pointer" onClick={(e)=>{e.preventDefault();setImageSlide(images);handleActionSlide(); setSelectImage(img && img._id);}}>
                    {(mime.includes("video"))?
                      <video className="img-fluid my-1" width='100%' controls> <source src={img && img.path} type={mime}/></video>:
                      <img className='img-fluid my-1' src={img.img}/>}
                  </div>
                )
              })}
            </div>
            <b className="pointer" onClick={(e)=>{e.preventDefault(); setImageSlide(images); setTypeSlide('list'); handleActionSlide();}}>  More Gallery </b>
          </div>
        )
      }
      return(
        <div className='d-flex flex-column' id="section-photos">
            { content &&
                <>
                    <h2>{festival.name} Photo and video Gallery</h2>
                    {content}
                    <hr style={hrStyle}/>
                </>
            }
        </div>
      )
    }
    function ResultSection(){
      if(!festival || awards.length <1) return <></>
      var content=[]
      for(var index  of awards){
        var categories = index ? index.cats : []
        if(categories && categories[0]){
          categories.map((cat)=>content.push(<li key={cat.title}><span className="py-1">{cat.title}&nbsp;{index.name}</span></li> ))
        }
        else content.push( <li key={index.name}><span className="py-1">{index.name}</span></li> )
      }

      return (
        <div id="section-results">
            {content &&
                <>
                    <div className="py-2">
                        <h2 className="text-capitalize">{festival.name} results </h2>
                        <ul key="resultsKey">
                            {content}
                        </ul>
                    </div>
                    <hr style={hrStyle}/>
                </>
            }
        </div>
      )
    }
    function NewsSection(){
      if(listNews.length < 1 || !festival)return <></>
      var content=[]
      for(var index of listNews){
        var href=(index && index.slug)?`/blogs/${index.slug}`: " "
        content.push(<li key={href}><a className="py-1" href={href}>{index.title}</a></li> )
      }

      return (
        <div id="section-news">
            {content &&
                <>
                    <div className="py-2">
                        <h2 className="text-capitalize">
                            {festival.festival && festival['festival'].name} News
                        </h2>
                        <ul key="newsKey">
                            {content}
                        </ul>
                    </div>
                    <hr style={hrStyle}/>
                </>
            }
        </div>
      )
    }

    function Compare(){
      var content=[]
      if(compareBands.length < 1 || !festival) return <></>
        for(var c of compareBands){
          content.push(
            <div className="col-lg-6" >
              <CardCompare coupleBands={c}/>
            </div>
          )
        }
        return(
            <div className="pt-2">
              <h3 className="p">Popular {festival.name} Costume Comparisons</h3>
              <div className="row justify-content-between">
              {content}
              </div>
          </div>
        )
    }

    return (
        <div className="container " onScroll={handleScroll.bind()}>
          {
            (fixNavBar?
              <div style={{backgroundColor:'#00A1AF',position:"fixed",zIndex:"1000",width:`${navWidth}px`}}>
                <div className=" text-white">
                  <div className="d-flex align-items-center">
                    <a onClick={scrollLeft} className="float-left btn d-block d-sm-none " style={{left:'0'}}><i className="fa fa-chevron-left"></i></a>
                    <div className="d-flex align-items-center" style={{overflowX:"auto",height:"40px",overflowY:"hidden"}} ref={menuRef}>
                      <Navbar/>
                    </div>
                    <a className="float-right btn d-block d-sm-none" onClick={scrollRight} style={{right:'0'}}><i className="fa fa-chevron-right"></i></a>
                  </div>
                </div>
              </div>
              :"")
          }
          <div>

            <h1 className="text-capitalize pt-3">{festivalDate && festivalDate.heading}</h1>
            <Advertisement slot="6887070145"/>
            <div className="row">
              <div className="col-12 col-md-6">
                {(festivalDate && festivalDate.cityCode) ? <ReactCountryFlag countryCode={festivalDate &&  festivalDate.cityCode} svg style={{width: '48px', height:'48px'}}/> : ''}
                <h2 className="text-capitalize px-2 my-auto d-inline-block align-middle">{festival && festival.name} {festivalDate &&  festivalDate.year}</h2>
              </div>
              <div className="col-12 col-md-6 text-right">
                <div className="d-inline-block">
                  <RateSection wishlist='true' share collName="festivals" docID={festival && festival._id}
                  link={`/festival/${festival &&  festival.slug}`}
                  text={festival && festivalDate && (festival.name + ' ' + festivalDate.year)}
                  />
                </div>
              </div>
            </div>
            <div className="pt-1">
              <img className="img-fluid d-none d-xl-block" alt={festival && festival.name} src={generateAddressImg(mainImg &&  mainImg['path'],1120,630)}  />
              <img className="img-fluid d-none d-lg-block d-xl-none" alt={festival && festival.name} src={generateAddressImg(mainImg &&  mainImg['path'],960,540)}   />
              <img className="img-fluid d-none d-md-block d-lg-none" alt={festival && festival.name} src={generateAddressImg(mainImg && mainImg['path'],720,405)}  />
              <img className="img-fluid d-none d-sm-block d-md-none" alt={festival && festival.name} src={generateAddressImg(mainImg &&  mainImg['path'],560,315)}  />
              <img className="img-fluid d-block d-sm-none" alt={festival && festival.name} src={generateAddressImg(mainImg && mainImg['path'],560,315)}  />
              <div className=" my-2">
                {/* <h2>{festival.festival && festival.festival['name']}</h2> */}
                {(festivalDate && festivalDate.meta)?
                  <p className="font-italic font-weight-bold">{festivalDate.meta}</p>
                  :
                  <p className="font-italic font-weight-bold">{festival && festival.meta}</p>
                }
                {fDate &&
                <>
                  <b className="text-secondary">Best Dates to Travel for {festival && festival.name} {festivalDate.year}</b>
                  <br/>
                  <span className="font-weight-bold mx-auto">{fDate}</span>
                </>
                }
              </div>
            </div>

            {(festivalDate  && festivalDate.nDaysToStartP >= 0)?
              <Counter  days={festivalDate.nDaysToStartP} time={festivalDate.paradeS}  />
            :''}
            <div className="mt-3" style={{backgroundColor:'#00A1AF'}} ref={navRef}>
              <div className="text-white">
                  <div className="d-flex align-items-center">
                    <a onClick={scrollLeft} className="float-left btn d-block d-sm-none " style={{left:'0'}}><i className="fa fa-chevron-left"></i></a>
                    <div className="d-flex align-items-center" style={{overflowX:"auto",height:"40px",overflowY:"hidden"}} ref={menuRef2}>
                      <Navbar/>
                    </div>
                  <a className="float-right btn d-block d-sm-none" onClick={scrollRight} style={{right:'0'}}><i className="fa fa-chevron-right"></i></a>
                </div>
              </div>
            </div>
            <AboutSection/>
            <GuideSection/>

            {(festivalDate && festivalDate.desc)?
              <>
              <h3>{festival && festival.name} {festivalDate.year} Details</h3>
              <div className="p-2 " dangerouslySetInnerHTML={{__html:festivalDate.desc}}></div>
              <hr style={hrStyle} />
              </> :
              festival && festival.desc &&
              <>
                <h3>{festival && festival.name} {festivalDate && festivalDate.year} Details</h3>
                <div className="p-2 " dangerouslySetInnerHTML={{__html:festival && festival.desc}}></div>
                <hr style={hrStyle} />
              </>
            }
            <FutureFestivalSection/>
            <ParticipatingBands/>
            <AdultSection/>
            <JouvertSection/>
            <ChildrenSection/>
            <EventSection/>
            <PastYearsSection/>
            <GallerySection/>
            <ResultSection/>
            <NewsSection/>
          </div>
          <Slideshow images={imageSlide} open={openSlide} handleAction={handleActionSlide} type={typeSlide} selected={selectImage}/>
        </div>
    )
}


