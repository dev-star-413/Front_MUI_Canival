import RateSection from "../../components/Festival/RateSection";
import { Divider } from "@material-ui/core";

export default function ParadeInfo(props) {
  return (
    <div className="container">
      <RateSection rate like wishlit share />
      <Divider />
      <div className="my-4">
        <span>
          <h6 className="subtitleText font-weight-bold">Date/Time:</h6>
        </span>
        <span>
          <h6 className="subtitleText font-weight-bold">Cost:</h6>
        </span>
        <span>
          <h6 className="subtitleText font-weight-bold">Starts:</h6>
        </span>
        <span>
          <h6 className="subtitleText font-weight-bold">Ends:</h6>
        </span>
      </div>
      <Divider />
      <div>
        <span>
          <h6>Text:</h6>
        </span>
        <span>
          <h6>Text:</h6>
        </span>
        <span>
          <h6>Text:</h6>
        </span>
      </div>
    </div>
  )
}