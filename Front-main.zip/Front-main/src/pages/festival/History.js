import RateSection from "../../components/Festival/RateSection";
import { Divider } from "@material-ui/core";


export default function History(props) {
  return (
    <div className="container">
      <RateSection collection="festival/helpfulhistory" slug={props.slug} helpful share />
      <Divider />
      <p className="text-dark my-4 text-justify">{props.history}</p>   
    </div>
  )
}