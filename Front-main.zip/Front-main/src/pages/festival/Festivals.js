import Flag from "../../components/Flag";
import { getFestivalsData } from "../../functions/api";
import { useEffect, useState } from "react";
import { makeStyles } from "@material-ui/core/styles";
import { Link } from "react-router-dom";
import {useHistory} from "react-router"
import FadeLoader from "react-spinners/FadeLoader";
import {
  Select,
  FormControl,
  MenuItem,
  InputLabel,
  Divider
} from "@material-ui/core";
import { FaRegSadTear } from "react-icons/all";
import FestivalCard from "./FestivalCard";

const useStyles = makeStyles(theme => ({
  formControl: {
    margin: theme.spacing(2),
    minWidth: 119
  },
  selectEmpty: {
    marginTop: theme.spacing(2)
  }
}));

export default function Festivals({year}) {
  const [festivals, setFestivals] = useState(null);
  const [years, setYears] = useState([]);
  const [regions, setRegions] = useState(null);
  const [isLoading, setIsLoading] = useState(true);
  const history = useHistory()

  useEffect(function() {
    loadData();
  },[year]);
  const loadData = async () => {
      year=year?year:"upcoming"
      const data = await getFestivalsData(year);
      var festivals=data && data.festivals
      var allRegions=data && data.regions
      let allYears=data ? data.years : []
      allYears.push("Upcoming")
      allYears=allYears.sort((a,b)=>b - a)
      
      setFestivals(festivals);
      setYears(data && data.years);
      setRegions(allRegions)
      setIsLoading(false)
  };
  const yearItems =years && years.map(function(year) {
    return (
      <MenuItem value={year} key={year}>
        {year}
      </MenuItem>
    );
  });
  const handleChange = async event => {
    setIsLoading(true)
    const year = event.target.value
    if(year!="Upcoming") {
      history.push(`/festivals/${year}`)
    } else {
      history.push("/festivals")
    }
  };
  const classes = useStyles();
  return (
    <div className="container">
      <div className="d-flex flex-row justify-content-between">
        <h1 className="my-auto font-weight-bold">Carnivals</h1>
        <FormControl className={classes.formControl}>
          <InputLabel>Years</InputLabel>
          <Select
            labelId={`yearsLabel`}
            id={`yearsDropdown`}
            value={year?year:"Upcoming"}
            onChange={handleChange}
          >
            {yearItems}
          </Select>
        </FormControl>
      </div>
      <Divider />
      <section className="my-4 ">
        {!isLoading && festivals && festivals.length === 0 && (
          <h3 className="my-5">
            No Festival Found For {year?year:"Upcoming Year"} <FaRegSadTear />
          </h3>
        )}
        {isLoading ? <div style={{position: "fixed", top: "50%", left: "50%", transform: "translate(-50%, -50%)"}}><FadeLoader size={150}/></div> : ""}
        {!isLoading && regions && regions[0] ? 
          <div>
            {regions.map((reg)=>{
              return makeRegion(reg)
            })}
          </div>
        :""}
      </section>
      <div className="mb-5">
        <h3>Festivals By Year</h3>
        <div className="col-12">
          <div className="row">
            {years && years.map(function(year) {
              return (
                <MenuItem key={year} value={year}>
                  <Link to={year!="Upcoming"?`/festivals/${year}`:"/festivals"}>
                    {year} Festivals
                  </Link>
                </MenuItem>
              );
            })}
          </div>
        </div>
      </div>
      <Flag />
    </div>
  );
  function makeRegion(reg){
    var open= (regions && regions[0]==reg)?true:false
    var findFestivals=[]
      findFestivals=festivals.filter((fes)=>fes.region==reg)
      // sort carnivals by festival.name
      findFestivals=findFestivals.sort((a,b)=>{
          let aName=a.festival && a.festival.name
          let bName=b.festival && b.festival.name
          if(aName > bName) return 1
          if(aName < bName) return -1
          return 0
      })
      return(
        <div key={reg}>
          <details open={open}>
            <summary>
              <h2 style={{display:"inline",fontWeight:"bold"}}>Festivals Of {reg} {year}</h2>
            </summary>

            <div className="col-12 row">
              {(findFestivals && findFestivals[0])?findFestivals.map((fes)=><FestivalCard festival={fes} key={fes._id}/>):""}
            </div>
          </details>
        </div>

      )

  }
}
