import TextAndImage from "../../components/Festival/TextAndImage";
import { useEffect, useState } from "react";
import { getNews } from "../../functions/api";

export default function News() {
  const [news, setNews] = useState(null);
  useEffect(function () {
    loadData();
  });
  const loadData = async () => {
    if (!news) {
      setNews(await getNews());
    }
  }
  return (
    <div className="container">
      <TextAndImage type="news" sections={news} />
    </div>
  )
}