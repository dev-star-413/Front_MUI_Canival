export default function About(props) {
    const festival = props.festival;
    return (
        <div className="container">
            <p className="text-dark text-justify"><h5 className="titleText">Carnival Theme:</h5> {festival.type}</p>
            <p className="text-dark text-justify"><h5 className="titleText">Description: </h5>{festival.desc}</p>
        </div>
    )
}