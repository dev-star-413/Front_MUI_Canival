
function GuidesAndReviews() {
  return (
    <div className="container">
      {/* <TextAndImage sections={articles} /> */}
    </div>
  )
}

export default GuidesAndReviews;