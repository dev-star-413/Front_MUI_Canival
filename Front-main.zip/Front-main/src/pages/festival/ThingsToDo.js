import "../../assets/styles/Festival.css";
import ThingsToDoItem from "../../components/Festival/ThingsToDoItem";
import RateSection from "../../components/Festival/RateSection";
import Checkbox from "../../components/CheckBox";
import Button from "@material-ui/core/Button";

export default function ThingsToDo() {
  const filterData = (
    <div className="py-3 px-3">
      <Checkbox label="Attractions" />
      <Checkbox label="Outdoors" />
      <Checkbox label="Eats" />
      <Button variant="contained">Submit</Button>
    </div>
  )
  return (
    <div className="container">
      <RateSection filter={filterData} />
      <ul className="list-group list-group-flush">
        <li className="list-group-item festival-menu-item" data-toggle="collapse" data-target="#eats" >
          Thing 1 (Eats)
        </li>
        <div id="eats" className="container collapse">
          <ThingsToDoItem type="Eats" />
        </div>
        <li className="list-group-item festival-menu-item" data-toggle="collapse" data-target="#foodDrinks">
          Thing 2 (Food/Drinks)
        </li>
        <div id="foodDrinks" className="container collapse">
          <ThingsToDoItem type="Food/Drinks" />
        </div>
        <li className="list-group-item festival-menu-item" data-toggle="collapse" data-target="#attractions">
          Thing 3 (Attractions)
        </li>
        <div id="attractions" className="container collapse">
          <ThingsToDoItem type="Attractions" />
        </div>
      </ul>
    </div>
  )
}