import React,{ useEffect, useState,useRef } from "react";
import "../../assets/styles/Festival.css";
import { getFestival } from "../../functions/api";
import { Link } from "react-router-dom";
import "@fortawesome/fontawesome-free/css/all.css"
import "../../App.css"
import { LazyLoadImage,LazyLoadComponent } from 'react-lazy-load-image-component';
import FadeLoader from "react-spinners/FadeLoader";
import generateAddressImg from "../../functions/generateAddressImg";
import ReactCountryFlag from "react-country-flag"
import CardCompare from "../../components/CardCompare";
const Slideshow = React.lazy(() => import("../../components/SlideShow"));
const Counter =React.lazy(()=>import("../../components/Counter"))
const Map=React.lazy(()=>import('../../components/Map'))
const RateSection = React.lazy(() => import('../../components/Festival/RateSection')); 

export default function Festival({ festivalId }) {
  const [festival, setFestival] = useState(null);
  const [page, setPage]=useState(null)
  const navRef = useRef(null);
  const menuRef=useRef()
  const menuRef2=useRef()
  const [fDate, setFDate]=useState(null)
  const[fixNavBar,setFixNavBar]=useState(false)
  const[navWidth,setNavWidth]=useState(100)
  const [listGuides,setListGuides]=useState([])
  const [listNews,setListNews]=useState([])
  const [listReviews,setListReviews]=useState([])
  const [typeSlide,setTypeSlide]=useState("list")
  const [openSlide,setOpenSlide]=useState(false)
  const [imageSlide,setImageSlide]=useState([])
  const [selectImage,setSelectImage]=useState(null)
  const hrStyle = {
    color: '#292b2c ',
    backgroundColor: '#292b2c ',
  }
  useEffect(function () {
    loadData();
    window.addEventListener('scroll',handleScroll)
    window.addEventListener("hashchange", function () {
      window.scrollTo(window.scrollX, window.scrollY - 100);
  });
  },[]);
    // change title page
    useEffect(()=>
      document.title=(festival && festival.heading)?`${festival.heading} `:"Hello Carnival",[festival])
  useEffect(function(){
    var blogs=festival && festival.blogs
    var guides=[]
    var reviews=[]
    var news=[]
    if(blogs && blogs[0]){
      for(var blog of blogs){
        var cats=blog.cats
        let isGuide= cats &&cats.includes("Guides")
        let isReview=cats && cats.includes("Reviews")
        let isNews=cats && cats.includes("News")
        if(isGuide) guides.push(blog)
        if(isReview) reviews.push(blog)
        if(isNews) news.push(blog)
      }
    }
    setListGuides(guides)
    setListReviews(reviews)
    setListNews(news)
  },[festival])
  useEffect(function (){
    // if start was pass
    var start=festival && festival.bestS
    var end=festival &&festival.bestE
    var SToE=start+' to '+end
    setFDate(SToE)

  },[festival])
  const loadData = async () => {
    if (!festival) {
      let data = await getFestival(festivalId)
      if(Array.isArray(data)) return window.location.href = "/404"
      setFestival(data);
    }
  }
  var changeNavbar=false
  const handleScroll = ({ element ,useWindow})=> {
    var navBarRect=navRef && navRef.current && navRef.current.getBoundingClientRect();
    if(navBarRect && navBarRect.y<53 && !changeNavbar){
      setFixNavBar(true)
      setNavWidth(navBarRect.width)
    }
    else if(navBarRect && navBarRect.y>50 ){
      setFixNavBar(false)
    }
  } 
  function scrollLeft(){
    if(menuRef && menuRef.current) menuRef.current.scrollLeft+=-50
    menuRef2.current.scrollLeft+=-50
  }
  function scrollRight(){
    if(menuRef && menuRef.current) menuRef.current.scrollLeft+=50
    menuRef2.current.scrollLeft+=50
  }
  useEffect(function (){
    if (festival) {
      var page = (
        <div>
          <h1 className="text-capitalize pt-3">{festival.heading}</h1>
          <div className="row">
            <div className="col-12 col-md-6">
              {(festival.cityCode) ? <ReactCountryFlag countryCode={festival.cityCode} svg style={{width: '48px', height:'48px'}}/> : ''}
              <h2 className="text-capitalize px-2 my-auto d-inline-block align-middle">{festival.festival && festival.festival['name']} {festival.year}</h2>
            </div>
            <div className="col-12 col-md-6 text-right">
              <div className="d-inline-block">
                <RateSection wishlist='true' share collName="dates" docID={festival._id} 
                link={`/festivals/${festival.slug}`}
                text={festival.festival && (festival.festival.name + ' ' + festival.year)}
                />
              </div>
            </div>
          </div>
          <div className="pt-1">
            {/* <div className='text-center d-flex justify-content-center align-items-end'
              style={{ backgroundImage: `url("${festival.img && festival.img['path']}")`,
              backgroundSize: 'contain',backgroundRepeat:"no-repeat",
              backgroundPosition:'center',height:'70vh'
              }} >
            </div> */}
            {festival.img && festival.img['path'] &&
              <>
                <img className="img-fluid d-none d-xl-block" alt={festival.festival && festival.festival['name']} src={generateAddressImg(festival.img && festival.img['path'],1120,630)}  />
                <img className="img-fluid d-none d-lg-block d-xl-none" alt={festival.festival && festival.festival['name']} src={generateAddressImg(festival.img && festival.img['path'],960,540)}   />
                <img className="img-fluid d-none d-md-block d-lg-none" alt={festival.festival && festival.festival['name']} src={generateAddressImg(festival.img && festival.img['path'],720,405)}  />
                <img className="img-fluid d-none d-sm-block d-md-none" alt={festival.festival && festival.festival['name']} src={generateAddressImg(festival.img && festival.img['path'],560,315)}  />
                <img className="img-fluid d-block d-sm-none" alt={festival.festival && festival.festival['name']} src={generateAddressImg(festival.img && festival.img['path'],560,315)}  />
                <i className="text-center d-flex justify-content-center">
                  {festival.imgTitle}
                </i>
              </>
            }
            <div className=" my-2">
              {/* <h2>{festival.festival && festival.festival['name']}</h2> */}
              {festival && festival.meta &&
                <p className="font-italic font-weight-bold">{festival.meta}</p>
              }
              {fDate && 
              <>
                <b className="text-secondary">Best Dates to Travel for {festival.festival && festival['festival'].name} {festival.year}</b>
                <br/>
                <span className="font-weight-bold mx-auto">{fDate}</span>
              </>
              }
            </div>
          </div>

          {(festival  && festival.nDaysToStartP >= 0)?
            <Counter  days={festival.nDaysToStartP} time={festival.paradeS}  />
          :''}
          <div className="mt-3" style={{backgroundColor:'#00A1AF'}} ref={navRef}>
            <div className="text-white">
                <div className="d-flex align-items-center">
                  <a onClick={scrollLeft} className="float-left btn d-block d-sm-none " style={{left:'0'}}><i className="fa fa-chevron-left"></i></a>
                  <div className="d-flex align-items-center" style={{overflowX:"auto",height:"40px",overflowY:"hidden"}} ref={menuRef2}>
                  {createNavbar()}
                </div>
                <a className="float-right btn d-block d-sm-none" onClick={scrollRight} style={{right:'0'}}><i className="fa fa-chevron-right"></i></a>
              </div> 
            </div>
          </div>
          {(festival.theme || festival.intro) && 
          <>
          <div id="section-about">
              <div className="pt-3 pb-1">
                {(festival.theme || (festival && festival.intro)) &&
                  <>
                    <h2 className="text-capitalize">About {festival.festival && festival['festival'].name} {festival.year}
                    </h2>
                    {festival.theme &&
                        <div className="col-12 pb-1">
                          <span className="text-capitalize"> Carnival Theme: {festival.theme}</span>
                        </div>
                    }
                    {festival && festival.intro &&
                        <div className="col-12 pt-1">
                          <span>{festival.intro}</span>
                        </div>
                    }
                  </>
                }
              </div>
            </div>
            <hr style={hrStyle} />
          </>
          }
          {(festival.guide || listGuides[0]) &&
            <>
            <div id="section-guides">
              <div className="py-2">
                <h3 className="text-capitalize">
                  {festival.festival && festival['festival'].name} {festival.year}  Guides 
                </h3>
                <div className="col-12" dangerouslySetInnerHTML={{__html:festival.guide}}></div>
                {linkGuides(listGuides)}
              </div>
            </div>
            <hr style={hrStyle} />
            </>
          }
          {festival && festival.desc &&
          <>
          <h3>{festival.festival && festival['festival'].name} {festival.year} Details</h3>
          <div className="p-2 " dangerouslySetInnerHTML={{__html:festival.desc}}></div>
          <hr style={hrStyle} />
          </>
          }
          {/* <div id="section-whereToStay">
            <div className="container py-2">
              <h2>Where to stay during {festival.festival && festival['festival'].name} {festival.year}?
               </h2>
                <div className="col-12 py-2" dangerouslySetInnerHTML={{__html:festival.whereToStay}}></div>
              </div>
          </div> */}
          {/* <hr style={hrStyle} /> */}

         
          <div id="section-parade">
            {(festival.paradeS || festival.paradeE || festival.price || (festival.pImg && festival.pImg.path)) &&
              <div className="py-2">
                <h2 className="text-capitalize">
                  {festival.festival && festival['festival'].name} {festival.year} Parade Info
                </h2>
                <div className="col-12">
                  {festival.paradeS && <span>Starts: {festival.paradeS}</span>}
                  <br/>
                  {festival.paradeE && <span>Ends: {festival.paradeE}</span>}
                  <br/>
                  {festival.price && <span>Pricing: {festival.price}</span>}
                  <div className="d-flex justify-content-center align-items-center">
                    {(festival.pImg && festival.pImg.path) ?
                        <>
                          <LazyLoadImage className="img-fluid d-none d-xl-block " alt="Parade"
                                         src={generateAddressImg(festival.pImg && festival.pImg['path'], 1120, 630)}/>
                          <LazyLoadImage className="img-fluid d-none d-lg-block d-xl-none" alt="Parade"
                                         src={generateAddressImg(festival.pImg && festival.pImg['path'], 960, 540)}/>
                          <LazyLoadImage className="img-fluid d-none d-md-block d-lg-none" alt="Parade"
                                         src={generateAddressImg(festival.pImg && festival.pImg['path'], 720, 405)}/>
                          <LazyLoadImage className="img-fluid d-none d-sm-block d-md-none" alt="Parade"
                                         src={generateAddressImg(festival.pImg && festival.pImg['path'], 560, 315)}/>
                          <LazyLoadImage className="img-fluid d-block d-sm-none" alt="Parade"
                                         src={generateAddressImg(festival.pImg && festival.pImg['path'], 560, 315)}/>
                        </>
                        : ""}
                  </div>
                  <div className="py-2" dangerouslySetInnerHTML={{__html: festival.paradeDesc}}>
                  </div>
                </div>
                <hr style={hrStyle} />
              </div>
            }
          </div>
          <div id="section-map">
            {festival.paradeGeo &&
              <div className="py-2">
                <h2 className="text-capitalize">{festival['festival'] && festival['festival'].name}
                  {festival.year} Parade Route</h2>
                <React.Suspense fallback={<div
                    style={{position: "fixed", top: "50%", left: "50%", transform: "translate(-50%, -50%)"}}><FadeLoader
                    size={150}/></div>}>
                  <LazyLoadComponent>
                    <Map paradeGeo={festival.paradeGeo} city={festival && festival.cityLatlng}/>
                  </LazyLoadComponent>
                </React.Suspense>
                <hr style={hrStyle} />
              </div>
            }
          </div>
          <div id="section-costumes">
            {((festival.costume && festival.costume.length > 0) || (festival.compares && festival.compares[0]))
                || (festival.bands && festival.bands.filter((b)=>b.isCustomeService).length > 0) &&
              <div className="py-2 ">
                <h2 className="text-capitalize">
                  Costume Bands at {festival.festival && festival['festival'].name} {festival.year}
                </h2>
                <div className="col-12">
                  <div dangerouslySetInnerHTML={{__html: festival.costume}}>
                    {/* <p>Plenty of planning and design goes into the production of floats for the Carnival. The floats being one of the biggest attractions at the parade, the costumes too are intricately designed. Participants are required to learn the samba song too. Only visitors who are serious about parading in the float are considered by the samba schools since they are concerned about losing points if participants fail to turn up for the parade.</p> */}
                  </div>
                  {bands(festival.bands || [], festival.festival && festival['festival'].name, festival.year)}
                  {festival.compares && festival.compares[0] &&
                      <>
                        <h3 className="pt-2">Popular Comparisons</h3>
                        {compare(festival.compares)}
                      </>
                  }
                </div>
                <hr style={hrStyle} />
              </div>
            }
          </div>
          
          
          <div id="section-jouvert" className="pt-2">
            {(festival.jouvert || festival.jouvertStartDate || festival.jouvertEndDate || festival.jouvertAddress) &&
                <>
                  <div>
                    <h2 className="text-capitalize">
                      Jouvert at {festival.festival && festival['festival'].name} {festival.year}
                    </h2>
                    {festival && festival.jImg && festival.jImg.path &&
                        <LazyLoadImage className="img-fluid d-none d-xl-block my-2" alt="Jouvert"
                                       src={generateAddressImg(festival.jImg && festival.jImg['path'], 1120, 630)}/>
                    }
                    <div className="col-12">
                      {festival && festival.jouvert &&
                          <h3>About</h3>
                      }

                      {festival && festival.jouvertStartDate &&
                          <>
                            <span>Starts: {festival.jouvertStartDate}</span>
                            <br/>
                          </>
                      }

                      {festival && festival.jouvertEndDate &&
                          <>
                            <span>Ends: {festival.jouvertEndDate}</span>
                            <br/>
                          </>
                      }

                      {festival && festival.jouvertAddress &&
                          <>
                            <span>Where: {festival.jouvertAddress}</span>
                            <br/>
                          </>
                      }
                      <div dangerouslySetInnerHTML={{__html: festival.jouvert}}></div>
                    </div>
                  </div>
                  {festival && festival.bands && festival.bands[0] &&
                      jouverts(festival.bands, festival.festival && festival['festival'].name, festival.year)
                  }
                </>
            }
          </div>

          {((festival.dateEvents && festival.dateEvents.length>0) || festival.event) &&
          <>
          <div id="section-events" >
            <div className="py-2">
              <h2 className="text-capitalize">
                {festival.festival && festival['festival'].name} {festival.year} Events Gallery
              </h2>
              <div  dangerouslySetInnerHTML={{__html:festival.event}}></div>
              {events(festival ? festival.dateEvents : [])}
            </div>
          </div>
          <hr style={hrStyle} />
          </>
          }
          {festival.galleries && festival.galleries.length>0 &&
          <>
          <div id='section-photos'>
            <div className='py-2'>
              <h2 className="text-capitalize">
              Photo and Video Gallery {festival.festival && festival['festival'].name} {festival.year}</h2>
              <div className="col-12">
                {gallery(festival.galleries)}
              </div>
            </div>
          </div>
          <hr style={hrStyle} />
          </>
          }
          {(listReviews.length>0 || festival.review) &&
          <>
          <div id="section-reviews">
            <div className="py-2">
              <h2 className="text-capitalize">{/*festival.year*/} {festival.festival && festival['festival'].name} {festival.year}   Reviews 
               </h2>
                {/* {festival.tsk && Array.isArray(festival.tsk) && festival.tsk.map(tsk => <div className="col-12 py-2" dangerouslySetInnerHTML={{__html: tsk}} />)} */}
                <div className="col-12" dangerouslySetInnerHTML={{__html:festival.review}}></div>
                {linkReviews(listReviews)}
              </div>
          </div>
          <hr style={hrStyle} />
          </>
          }
          {((festival.awards && festival.awards.length>0) || festival.result) &&
          <>
          <div id="section-results">
            <div className="py-2">
              <h2 className="text-capitalize">{festival.festival && festival['festival'].name} {festival.year}  results </h2>
              {/* {result(festival.awards)} */}
              <div className="col-12" dangerouslySetInnerHTML={{__html:festival.result}}></div>
              {linkResults(festival.awards)}
            </div>
          </div>
          <hr style={hrStyle} />
          </>
          }
          {listNews.length>0 &&
          <>
          <div id="section-news">
            <div className="py-2">
              <h2 className="text-capitalize">
                {festival.festival && festival['festival'].name} News 
              </h2>
              {linkNews(listNews)}
            </div>
          </div>
          <hr style={hrStyle} />
          </>
          }
          {festival.pastDates && festival.pastDates[0] &&
          <>
          <div id="section-past">
            <div className="py-2">
              <h2 className="text-capitalize">{festival.festival && festival['festival'].name} in The Past</h2>
              {linkPastFestivals(festival.pastDates)}
            </div>
          </div>
          <hr style={hrStyle} />
          </>
          }
          {festival.pastDates && festival.pastDates[0] &&
          <>
          <div id="section-yearOtherFestivals">
            <div className="py-2">
              <h2 className="text-capitalize">{festival.year} Other Festivals</h2>
              {linkYearOtherFestivals(festival.pastDates)}
              <ul key="findMore">
                <li style={{listStyle: "none"}}>
                  Find more <Link to={`/festivals/${festival.year}`}>{festival.year} Festivals</Link>
                </li>
              </ul>
            </div>
          </div>
          </>
          }
        </div>
      )
      setPage(page)
    }
  },[festival,listGuides,listReviews,fDate])

  function handleActionSlide(){
    setOpenSlide(!openSlide)
  }
  function createNavbar() {
    return <>
      {/* <a className="p-3 " href="#section-more">History</a><span className="text-secondary">|</span> */}
      {(festival.theme || festival.intro) && <><a className="p-3 text-white" href="#section-about">About</a><span className="text-secondary">|</span></>}
      {/* <a className="p-3 " href="#section-whereTostay">Where to stay</a><span className="text-secondary">|</span> */}
      {(festival.paradeS || festival.paradeE || festival.price || (festival.pImg && festival.pImg.path)) &&
          <><a className="p-3 text-white" href="#section-parade">Parade</a><span className="text-secondary">|</span></>
      }
      {((festival.costume && festival.costume.length > 0) || (festival.compares && festival.compares[0]))
          || (festival.bands && festival.bands.filter((b) => b.isCustomeService).length > 0) &&
          <><a className="p-3 text-white" href="#section-costumes">Costumes</a><span className="text-secondary">|</span></>
      }
      {(festival.jouvert || festival.jouvertStartDate || festival.jouvertEndDate || festival.jouvertAddress) &&
          <><a className="p-3 text-white" href="#section-jouvert">Jouvert</a><span className="text-secondary">|</span></>
      }
      {((festival.dateEvents && festival.dateEvents.length>0) || festival.event) && <><a className="p-3 text-white" href="#section-events">Events</a><span className="text-secondary">|</span></>}
      {((festival.awards && festival.awards.length>0) || festival.result) &&<><a className="p-3 text-white" href="#section-results">Results</a><span className="text-secondary">|</span></>}
      {festival.galleries && festival.galleries.length>0 && <><a className="p-3 text-white" href="#section-photos">Photos</a><span className="text-secondary">|</span></>}
      {listNews.length>0 && <><a className="p-3 text-white" href="#section-news">News</a><span className="text-secondary">|</span></>}
      {festival.pastDates && festival.pastDates[0] && <><a className="p-3 text-white" href="#section-past">Past</a><span className="text-secondary">|</span></>}
      {festival.pastDates && festival.pastDates[0] && <><a className="p-3 text-white text-nowrap" href="#section-yearOtherFestivals">{festival.year} Festivals</a></>}
    </>
  }
  return (
      <div className="container " onScroll={handleScroll.bind()}>
        {
          (fixNavBar?
            <div style={{backgroundColor:'#00A1AF',position:"fixed",zIndex:"1000",width:`${navWidth}px`}}>
              <div className=" text-white">
                <div className="d-flex align-items-center">
                  <a onClick={scrollLeft} className="float-left btn d-block d-sm-none " style={{left:'0'}}><i className="fa fa-chevron-left"></i></a>
                  <div className="d-flex align-items-center" style={{overflowX:"auto",height:"40px",overflowY:"hidden"}} ref={menuRef}>
                    {createNavbar()}
                  </div>
                  <a className="float-right btn d-block d-sm-none" onClick={scrollRight} style={{right:'0'}}><i className="fa fa-chevron-right"></i></a>
                </div> 
              </div> 
            </div> 
            :"")
        }
        {page}
        <Slideshow images={imageSlide} open={openSlide} handleAction={handleActionSlide} type={typeSlide} selected={selectImage}/>

      </div>
  )
  function gallery(all) {
    var content=[]
    if(!all || !all[0] ) return
    for(let g of all){
      let img=g.imgs && g.imgs[0]
      if(!img) {
        continue;
      }

      let mime=img && img.mime
      if(!mime) {
        continue;
      }
      
      var images=[]
      if(g.imgs && g.imgs[0]){
        g.imgs.map((media)=>{
          media.img=(media.mime && media.mime.includes('video'))?media.path : generateAddressImg(media && media.path,1120,630)
          media.name=media.text
          images.push(media)
        })
      }
      content.push(
        <div>
   
          <div className='col-sm-12'>
            <h4>{g && g.title}</h4>
            <span>
              {g && g.desc}
            </span>
          </div>
          <div className="my-2 row">
            {images.map((img)=>{
              let mime=img.mime
              return(
                <div key={img._id} className="col-sm-4 pointer" onClick={(e)=>{e.preventDefault();setImageSlide(images);handleActionSlide(); setSelectImage(img._id);}}>
                  {(mime.includes("video"))?
                    <video className="img-fluid my-1" width='100%' controls> <source src={img && img.path} type={mime}/></video>:
                    <img className='img-fluid my-1' src={img.img}/>}
                </div>
              )
            })}
          </div>
          <b className="pointer" onClick={(e)=>{e.preventDefault(); setImageSlide(images); setTypeSlide('list'); handleActionSlide();}}>  View Gallery </b> 
        </div>
      )
    }
    return(
      <div className='d-flex flex-column'>
        {content}
      </div>
    )
  }

  function linkYearOtherFestivals() {
    let content = [];
    if(festival && festival.yearOtherFestivals && festival.yearOtherFestivals[0]) {
      for(let otherYearF of festival.yearOtherFestivals) {
        content.push(
          <li key={otherYearF.id}>
            <a className="py-1" href={`/festivals/${otherYearF.slug}`}>
              {otherYearF.festival.name} {otherYearF.year} ({otherYearF.region})
            </a>
          </li>
        )
      }
    }
   
    return(
      <ul key="otherFestivalYear">
        {content}
      </ul>
    )
  }
}
function bands(allBands,festivalName,year){
  var content=[]
  var costumBands=allBands.filter((b)=>b.isCustomeService)

  for (let i in costumBands){
    let slug = (costumBands &&  costumBands[i]) ? costumBands[i].slug : ''
    content.push(
      <Link to={'/bands/'+slug}  key={i} className="col-lg-6 col-md-6 col-sm-12 col-12 my-2" >
        {/* <div className="col-12 my-2 "> */}
          <div className="row">
            {/* <div className="col-5" style={{backgroundImage:`url('${bands && bands[i].imgs && bands && bands[i].imgs[0] && bands[i].imgs[0].path}')`,
              backgroundPosition:"center",
              backgroundSize:"contain",backgroundRepeat:"no-repeat"}}>
            </div> */}
            <div className="col-5">
              <LazyLoadImage className="img-fluid" src={generateAddressImg(costumBands && costumBands[i].mainImg && costumBands[i].mainImg.path,208,117)} />
            </div>
            <div className="col-7 " >
              <div className="text-dark" >
                <h5 className='pt-2'>
                  {costumBands && costumBands[i].name} {costumBands && costumBands[i].year}
                </h5>
                <span >{costumBands && costumBands[i].theme}</span>  
              </div>
            </div>
          </div>
        {/* </div> */}
      </Link>
    )
  }

  return (
    <>
      <div className="row">
        {content}
      </div>
      
    </>
  )
}

function jouverts(allBands , festivalName, festivalYear) {
  var jouverContent=[]
  if(!allBands || !allBands[0]) return null
  var jouverBands=allBands.filter((j)=>j.isJouvertService)
  for (let i in jouverBands){
    let slug= (jouverBands && jouverBands[i]) ? jouverBands[i].slug : ''
    jouverContent.push(
      <Link to={'/bands/'+slug}  key={i} className="col-lg-6 col-md-6 col-sm-12 col-12 my-2" >
          <div className="row">
            <div className="col-5">
              <LazyLoadImage className="img-fluid" src={generateAddressImg(jouverBands && jouverBands[i].mainImg &&  jouverBands[i].mainImg.path,208,117)} />
            </div>
            <div className="col-7 " >
              <div className="text-dark" >
                <h5 className='pt-2'>
                  {jouverBands && jouverBands[i].name} {jouverBands && jouverBands[i].year} 
                </h5>
                <span >{jouverBands && jouverBands[i].theme}</span>  
              </div>
            </div>
          </div>
      </Link>
    )
  }
  if(jouverContent && jouverContent[0]){
    return (
      <div className="col-12 pt-2">
        <h3 className="text-capitalize">{festivalName}  Jouvert Bands {festivalYear}</h3>
        <div className="row">
          {jouverContent}
        </div>
      </div>
    )
  }
  else return null

  
}
function events(events){
  var content=[]
  events=events && events[0]?events:[]
  for(var event of events){
    var href=(event && event.slug)?`/events/${event.slug}`: " "
    content.push(
      <li key={event.name}>
        <a href={href}>
          {event && event.name} {(event && event.price)? '$'+event.price+ ' USD' : '' }  - {event && event.sDate} @ {event && event.vName}
        </a>
      </li>
    )
  }
  return (
    <ul key="eventsKey">
      {content}
    </ul>
  )
}

function compare(compares){
  var content=[]
  if(compares && compares[0]){
    for(var c of compares){
      content.push(
        <div className="col-lg-6" >
          <CardCompare coupleBands={c}/>
        </div>
      )
    }
  }
  return(
    <div className="row justify-content-between">          
      {content}
    </div>
  )
}

function linkGuides(listGuides){
  var content=[]
  if(listGuides && listGuides[0]){
    listGuides.map((index)=>{
      var href=(index && index.slug)?`/blogs/${index.slug}`: " "
      content.push(
        <li key={href}><a className="py-1" href={href}>{index.title}</a></li>
      )
    })
  }
  return(
    <ul key="guidesKey">
      {content}
    </ul>
    
  )
}
function linkReviews(listReviews) {
  var content=[]
  if(listReviews && listReviews[0]){
    listReviews.map((index)=>{
      content.push(
        <li key={index.slug}><a className="py-1" href={"/blogs/"+index.slug}>{index.title}</a></li>
      )
    })
  }
  return(
    <ul key="reviewsKey">
      {content}
    </ul>
    
  )
}
function linkNews(news){
  var content=[]
  if(news && news[0]){
    news.map((index)=>{
      var href=(index && index.slug)?`/blogs/${index.slug}`: " "
      content.push(
        <li key={href}><a className="py-1" href={href}>{index.title}</a></li>
      )
    })
  }
  return(
    <ul key="newsKey">
      {content}
    </ul>
    
  )
}
function linkResults(awards){ // list awards
  var content=[]
  if(awards && awards[0]){
    awards.map((index)=>{
      var href=(index && index.slug)?`/awards/${index.slug}`: " "
      var categories = index ? index.cats : []
      if(categories && categories[0]){
        categories.map(function(cat){
          content.push(
            <li key={cat.title}><a className="py-1" href={href}>{cat.title}&nbsp;{index.name}</a></li>
           )
        })
      }
      else {
        content.push(
          <li key={index.name}><a className="py-1" href={href}>{index.name}</a></li>
        )
      }
    })
  }
  return(
    <ul key="resultsKey">
      {content}
    </ul> 
  )
}
function linkPastFestivals(dates){
  var content=[]
  if(dates && dates[0]){
    dates.map((index)=>{
      var href=(index && index.slug)?`/festivals/${index.slug}`: " "
      content.unshift(
        <li key={index._id}>
          <a className="py-1" href={href}>{index.festival && index.festival.name}&nbsp;{index.year}</a>
        </li>
      )
    })
  }
  return(
    <ul key="pastFestivalsKey">
      {content}
    </ul>
  )
}

