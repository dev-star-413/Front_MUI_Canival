import Title from "../../components/Festival/FestivalTitle";
import RateSection from "../../components/Festival/RateSection";

export default function CanceledResult() {
    const hr = {
        color: '#292b2c ',
        backgroundColor: '#292b2c ',
        height: 1,
    }
    return (
        <div>
            <Title page="[Year] [FestivalName] [Category] Results" />
            <RateSection category="A" />
            <hr style={hr} />
            <p>Description text of results</p>

        </div>
    )
}