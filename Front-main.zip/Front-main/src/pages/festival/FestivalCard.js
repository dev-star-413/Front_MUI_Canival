import { Link } from "react-router-dom";
import { IoLocation,FaCalendarAlt } from "react-icons/all";
import generateAddressImg from "../../functions/generateAddressImg";
import ReactCountryFlag from "react-country-flag"
export default function FestivalCard({ festival }) {
  return (
    <div  key={festival.bestS} className="col-md-4 col-sm-6 my-3">
      <div
        style={{minHeight:"45vh"}}
        className="linkCard card shadow-sm text-left"
        // to={`/festivals/${festival.slug}`}
      >
        {/* <div
          className="cardImage"
          style={{
            backgroundImage: `url('${festival.img && festival.img.path}')`
          }}
        /> */}
        <img className="img-fluid" src={generateAddressImg(festival.img && festival.img.path,330,440)} />
        <div className="px-2 d-flex flex-row align-items-center">
          <ReactCountryFlag countryCode={festival.cityCode} svg style={{width: '48px', height:'48px'}}/>
          <h3 className="px-2">
            {festival && festival.festival && festival.festival.name}
          </h3>
          {/* <p>{TruncateText(festival.meta, 100)}</p> */}
        </div>
        <div className="px-2">
          {/* <i className="fa fa-calendar fa-lg text-secondary"></i> */}
          <IoLocation className="mr-2 text-secondary" size={20} />
          <span> Parade: <b>{festival && festival.paradeS}</b></span>
        </div>
        <div className="px-2">
          {/* <i className="fa fa-map-marker fa-lg text-secondary" aria-hidden="true"></i> */}
          <FaCalendarAlt className="mr-2 text-secondary" size={20} />
          <span style={{maxWidth:"100%",}}> Where: <b>{festival && festival.cityName} , {festival && festival.country}</b></span>
        </div>
      </div>
    </div>
  );
}
