import RateSection from "../../components/Festival/RateSection";
import { Divider } from "@material-ui/core";

export default function TravelersShouldKnow(props) {

  return (
    <div className="container">
      <RateSection helpful collection="festival/helpfultravelers" slug={props.slug} share />
      <Divider />
      <h6>Text:</h6>
    </div>
  )
}