import RateSection from "../../components/Festival/RateSection";
import TextAndImage from "../../components/Festival/TextAndImage";
import "../../assets/styles/Festival.css";
import { Divider } from "@material-ui/core";

export default function CostumeBand(props) {
  return (
    <div className="container">
      <RateSection rate like collection="band" slug={props.slug} wishlist compare share />
      <Divider />
      {/* <TextAndImage sections={bands} /> */}
    </div>
  )
}