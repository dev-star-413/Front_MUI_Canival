import { useEffect } from "react"
import {getListFestivals} from '../../functions/api'
import { useState } from "react"
import { Button } from "react-bootstrap"
import Advertisement from "../../components/Advertisement"
export default function List(props) {
    const [festivals,setFestivals]=useState([]) 
    const [years,setYears]=useState([])
    const [selectedYear,setSelectedYear]=useState()
    const ACTIVE='Active'
    useEffect(()=>{
        const year=new Date().getFullYear()
        setSelectedYear(year)
        getList()
    },[])
    const handleOnClickYear=(y)=>{
        setSelectedYear(y)
    }

    const getList=async ()=>{
        var data=await getListFestivals()
        if(data.code!=0) return alert(data.msg)
        var all=data.data
        if(!all || !all[0]) return setYears([])
        setFestivals(all)
        var y=new Set()
        all.forEach((el)=>el.year && y.add(el.year))
        y=Array.from(y) 
        setYears(y) 
    }

    const NavbarYears=()=>{
        var selected=selectedYear
        if(!selected) selected=new Date().getFullYear()
        if(!years || !years[0]) {
            console.log("not exist years ")
            return <>not exist</>
        }
        var content=[]
        years.forEach((y)=>{
            if(y==selected) {
                content.push(
                <Button  className="p-1 btn" variant="link" key={'year-'+y} onClick={()=>handleOnClickYear(y)}>
                    <b>{y}</b>
                </Button>
                )
            }
            else content.push(<Button className="p-1 btn text-dark" variant="link" key={'year-'+y} onClick={()=>handleOnClickYear(y)} >{y}</Button>)
        })
        return (
            <nav className="d-flex flex-row">
                {content}
            </nav>
        )
    }

    const FestivalsYear=()=>{
        var selected=selectedYear
        if(!selected) selected=new Date().getFullYear()
        var data=festivals.filter((f)=>f.year==selected)
        var content=[]
        data.forEach((el,index) => {
            if(index%4==0){
                content.push(
                    <div className="py-3" key={'space-'+index}></div>
                )
            }
            content.push(
                <div key={el.slug}>
                <a className="py-1 col-12" href={'festival/'+el.slug}> 
                <b>{el.festival && el.festival.name}</b>   {(el.paradeS)?el.paradeS:<span style={{color:"gray"}}>Date N/A</span>}</a>
                </div>
            )
        });
        return(
            <div className="d-flex flex-column">
                {content}
            </div>
        )
    }

    return (
      <div className="container d-flex flex-column">
        <NavbarYears/>
        <h1 className="py-2">{selectedYear} Global Caribbean Carnival Parade Dates</h1>
        <Advertisement slot="6887070145"/>
        <FestivalsYear/>
      </div>
    )
  }