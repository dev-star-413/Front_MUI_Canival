import React, { useState, useEffect } from "react";
import { getResult, updateAwardReviews } from "../../functions/api";
import RateSection from "../../components/Festival/RateSection";
import { AiOutlineLike, AiOutlineDislike, RiEmotionNormalLine } from "react-icons/all";
import { Divider, Button } from "@material-ui/core";
import { Link } from "react-router-dom";
import CommentPicker from "../../components/CommentPicker";
import { useCookies } from "react-cookie";
import { animateScroll as scroll } from 'react-scroll';
import generateAddressImg from '../../functions/generateAddressImg'

export default function Results({ match }) {
  const [result, setResult] = useState({
    cats: [],
    _id: '',
    name: '',
    dId: '',
    fDate: {
      name: '',
      year: '',
    },
    slug: '',
  });
  const [pastYears, setPastYears] = useState([]);
  const [uniqueId, setUniqueId] = useCookies(['uniqueId']);
  useEffect(function () {
    loadData();
  }, [match.params.slug]);
  const loadData = async () => {
    if (!result || result.slug !== match.params.slug) {
      const data = await getResult(match.params.slug);
      if(!data || !data.award) return window.location.href = "/404"
      setResult(data.award);
      let pastAwards=data.pastYearAwards
      if(pastAwards && Array.isArray(pastAwards) && pastAwards[0]){
        pastAwards=pastAwards.sort((a,b)=>{
          let y1=a.year;let y2=b.year
          return y2-y1
        })
      }
      setPastYears(pastAwards);
      scroll.scrollToTop()
    }
  }
  return (
    <section className="container py-2">
      {(result && result.fDate) ?
        <>
          <h1>{result.name}</h1>
          <RateSection 
            share 
            category={`${result.fDate.name} ${result.fDate.year}`} 
            slug={`${result && result.fDate && result.fDate.slug}`} 
            link={'/awards/'+result.slug}
          />
          <Divider className="my-3" />
          <small className="text-secondary"> Table of contents</small>
          <div className="d-flex flex-column">
            <a className="my-1" href={`#about`}>About this Award</a>
            {result.cats.map(cat => <a key={cat.title} className="my-1" href={`#category-${cat.title}`}>{cat.title}</a>)}
          </div>
          <h2 className="mt-2">About  {result.name}</h2>
          <p id="about" className="mb-4" dangerouslySetInnerHTML={{ __html: result.desc }} />
          {result.cats.map((category, index) => <Category key={index} category={category} awardId={result._id} index={index} uniqueId={uniqueId.uniqueId} setUniqueId={setUniqueId} />)}
          {pastYears.length > 0 &&
            <>
              <h2>Past Years Results</h2>
              {pastYears.map(award => (
                <Link key={award.slug} to={`/awards/${award.slug}`}>
                  <h5 className="titleText">{award.name} {award.year} Results</h5>
                </Link>
              ))}
            </>
          }
        </> : null}
    </section>
  )
}

function PositionNumber({ number }) {
  return (
    <div className="d-flex" style={{ backgroundColor: '#222222' }}>
      <h1 className="text-light mx-auto my-auto py-2 font-weight-bold">{number}</h1>
    </div>
  )
}

function Winner({  category, winner, index, awardId, updateReviews, uniqueId, setUniqueId }) {
  async function handleScoreReviewClick(type) {
    const res = await updateAwardReviews({
      type, awardId, index, uniqueId
    });
    if (res && res.code == 1 && res.data) {
      setUniqueId('uniqueId', res.data.uniqueId, { path: '/' });
      updateReviews(res.data.category.agree, res.data.category.disagree, res.data.category.notsure);
    }
  }
  
  return (
    <div className="mb-4">
      <PositionNumber number={winner.position} />
      <div className="d-flex justify-content-center">
        {winner.img && 
        // <div className="winnerImage w-100" style={{ backgroundImage: `url(${winner.img.path})` }} />
        <img className=" img-fluid" src={generateAddressImg(winner.img.path,1120,630)} />
        }
      </div>
      <h3 className="subtitleText font-weight-bold mt-3">{winner.name}</h3>
      {winner.text ? <h5>{`${winner.text}`}</h5> : ''}
      <p className="text-dark">{winner.bands.map((band, index) => {
        return <React.Fragment key={index}><Link to={`/bands/${band.slug}`}> {band.name} </Link> {(index !== winner.bands.length-1) ? "," : ""}</React.Fragment>
      })}</p>
      {winner.position == 1 &&
      <div className="p-2"  style={{backgroundColor:" rgb(222, 222, 222)"}}>
      <h4 >Award {category && category.title} Survey</h4> 
        <div className="d-flex d-flex-row justify-content-between m-2 p-2 bg-white">
          <Button onClick={() => handleScoreReviewClick('agree')} variant="outlined" color="primary" className="align-items-center col-3">
            <span className="h3 py-2"><AiOutlineLike /><br />Agree</span>
          </Button>
          <Button onClick={() => handleScoreReviewClick('notsure')} variant="outlined" color="default" className="align-items-center col-4" >
            <span className="h3 py-2"><RiEmotionNormalLine /><br />Not sure</span>
          </Button>
          <Button onClick={() => handleScoreReviewClick('disagree')} variant="outlined" color="secondary" className="align-items-center col-3"> 
            <span className="h3 py-2"><AiOutlineDislike /><br />Disagree</span>
          </Button>
        </div>
        <a href="#review"> See survey results and leave a comment below. </a>
      </div>
      }
    </div>
  )
}

function Category({ awardId, category, index, uniqueId, setUniqueId }) {
  const [agrees, setAgrees] = useState(category && category.agree);
  const [notsures, setNotsures] = useState(category && category.notsure);
  const [disagrees, setDisagrees] = useState(category && category.disagree);
  if (!category || !awardId) {
    return <small>Category data is not complete.</small>;
  }
  const hasReviews = category.positions.find(position => position.position == 1);
  const updateReviews = (agree, disagree, notsure) => {
    setAgrees(agree);
    setDisagrees(disagree);
    setNotsures(notsure);
  }
  return (
    <div id={`category-${category.title}`} className="mt-3 mb-5">
      <h2>{category.title}</h2>
      {category.positions.map((position, index) => <Winner key={index} category={category} updateReviews={updateReviews} winner={position} index={index} awardId={awardId} uniqueId={uniqueId} setUniqueId={setUniqueId} />)}
      <p dangerouslySetInnerHTML={{ __html: category.desc }} />
      <div id="review" style={{backgroundColor:" rgb(222, 222, 222)"}}>
        <h3>Survey Results > Comment below</h3>
      {hasReviews &&
        <div className="d-flex flex-row justify-content-around mt-5 align-items-center">
          <h4>Agree <b>{Math.round(agrees)}%</b></h4>
          <h4>Not sure <b>{Math.round(notsures)}%</b></h4>
          <h4>Disagree <b>{Math.round(disagrees)}%</b></h4>
        </div>
      }
      </div>
      <CommentPicker hasText docID={awardId} collName="award" comments={category.comments} index={index} />
    </div>
  )
}