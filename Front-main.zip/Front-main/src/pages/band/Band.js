import React , { useEffect ,useState,useRef} from "react";
import {getBandBySlug} from "../../functions/api"
import { LazyLoadImage } from 'react-lazy-load-image-component';
import { Link } from "react-router-dom";
import generateAddressImg from "../../functions/generateAddressImg"
import {FadeLoader} from "react-spinners";
import LoadingOverlay from 'react-loading-overlay';
import { GrStar } from "react-icons/all";
import { Divider, Button } from "@material-ui/core";
import profilePicture from "../../assets/imgs/image-not-found.jpg";
import ordinal from "ordinal";
import "@fortawesome/fontawesome-free/css/all.css"
const Slideshow = React.lazy(() => import("../../components/SlideShow"));

const RateSection = React.lazy(() => import('../../components/Festival/RateSection')); 

export default function Band({ match }){
    const [band, setBand] = useState(null); 
    const [totalScore,setTotalScore]=useState()
    const [totalUR,setTotalUR]=useState() // user review
    const userExists = Boolean(localStorage.token);
    const [loading, setLoading]=useState(true)
    const [fixNavBar, setFixNavBar] = useState(false)
    const navRef = useRef(null);
    const [navWidth, setNavWidth] = useState(100)
    const menuRef = useRef()
    const menuRef2 = useRef()
    const [openSlide,setOpenSlide]=useState(false)
    const [imageSlide,setImageSlide]=useState([])
    const [selectImage,setSelectImage]=useState(null)
    const [typeSlide,setTypeSlide]=useState("list")

    useEffect(function () {
        window.addEventListener('scroll', handleScroll)
    }, [])
    useEffect(async ()=>{
        setLoading(true)
        try {
            var res=await getBandBySlug(match.params.slug)
            if(res && res.code==0) setBand(res.band)
            else alert("Something is wrong. Please try again")
        } catch (error) {
            console.log(error)
        }finally{
            setInterval(()=>{
                setLoading(false)
            },20)
        }

    },[match.params.slug])

    useEffect(()=>{
        var bandDates=band?.bandDates || []
        var sumScore=0
        var sumUR=0
        var lengthSC=0
        var lengthUR=0
        if(bandDates && bandDates[0]){
            for(var date of bandDates){
                if(date.score && date.score>0){
                    lengthSC++;
                    sumScore+=Number(date.score)
                }
                if(date.avgScore && date.avgScore>0){
                    sumUR+=Number(date.avgScore)
                    lengthUR++;
                }
                
            }   
        }
        setTotalScore((sumScore >0)? sumScore/lengthSC : 0)
        setTotalUR((sumUR>0)? sumUR/lengthUR : 0)
        contentResults()
    },[band])
    
    const handleScroll = ({ element, useWindow }) => {
        var navBarRect = navRef && navRef.current && navRef.current.getBoundingClientRect();
        if (navBarRect && navBarRect.y < 53 ) {
            setFixNavBar(true)
            setNavWidth(navBarRect.width)
        }
        else if (navBarRect && navBarRect.y > 50) {
            setFixNavBar(false)
        }
    }

    const contentResults=()=>{
        if(!band) return
        var {results,bandDates}=band
        if(!bandDates || !bandDates[0]) return
        if(!results || !bandDates[0]) return
        var content=[]
        if(results && results[0]){
            results.map((award)=>{
            var href=(award && award.slug)?`/awards/${award.slug}`: " "
            var categories = award ? award.cats : []
            if(categories && categories[0]){
              categories.map(function(cat){
                var positions=cat.positions || []
                for(let position of positions){
                    let bands=position.bands || []
                    for(var pb of bands){
                        var find=bandDates.find((b)=>b._id ==pb._id)
                        if(find){
                            content.push(
                                {
                                    position:position.position,
                                    content:(
                                        <li key={cat.title} className="list-group">
                                            <a className="py-1" href={href}>
                                            {ordinal(parseInt(position.position))} | {cat.title} at {award.name}
                                            </a>
                                        </li>
                                    )
                                }
                            )
                        }
                    }
                }
              })
            }
          })
        }
        content=content.sort((a,b)=>a.position  -b.position)
        content=content.map(c=>c.content)
        if(content[0]){
            return(
                <section id="section-results" className="py-2">
                    <h4>{band.name} Results</h4>
                    <div className="col-12 mt-2" >
                        <ul key="resultsKey" >
                        {content}
                        </ul>
                    </div>
    
                </section>
    
            )
        }
    }

    const contentNews=()=>{
        const news=band?.news || []
        const content=[]
        for(var nws of news){
            content.push(
                <div>
                    <Link key={nws.slug} to={'/blogs/'+nws.slug}>{nws.title}</Link>
                </div>
            )
        }
        if(content[0]){
            return(
                <div id='section-news' className="my-2">
                    <h4>News</h4>
                    <div className="col-12  mt-2">
                        {content}
                    </div>
                </div>
            )
        }
    }

    const createNavbar=()=> {
        return <>
          {band && band.bandDates && band.bandDates[0] && <><a className="p-3 text-white menuButton font-weight-bold" href="#section-bandDates">Past Years</a><span className="text-secondary">|</span></>}
          {band && band.gallery && band.gallery[0] && <><a className="p-3 text-white menuButton font-weight-bold" href="#section-gallery">Photos</a><span className="text-secondary">|</span></>}
          {band && band.results && band.results[0] && <><a className="p-3 text-white menuButton font-weight-bold" href="#section-results">results</a><span className="text-secondary">|</span></>}
          {band && band.news && band.news[0] && <><a className="p-3 text-white menuButton font-weight-bold" href="#section-news">News</a><span className="text-secondary">|</span></>}
          {band && band.about && <><a className="p-3 text-white menuButton font-weight-bold" href="#section-about">About</a><span className="text-secondary">|</span></>}
          {band && band.contactEmail && <><a className="p-3 text-white menuButton font-weight-bold" href="#section-contact">Contact</a><span className="text-secondary">|</span></>}
        
        </>
    }

    function scrollLeft() {
        if (menuRef && menuRef.current) menuRef.current.scrollLeft += -50
        menuRef2.current.scrollLeft += -50
    }

    function scrollRight() {
        if (menuRef && menuRef.current) menuRef.current.scrollLeft += 50
        menuRef2.current.scrollLeft += 50
    }
    function contentGallery(){
        var all =band && band.gallery
        var content=[]
        if(!all || !all[0] ) return
        for(let g of all){
            let img=g.imgs && g.imgs[0]
            if(!img) {
            continue;
            }
    
            let mime=img && img.mime
            if(!mime) {
            continue;
            }
            
            var images=[]
            if(g.imgs && g.imgs[0]){
            g.imgs.map((media)=>{
                media.img=(media.mime && media.mime.includes('video'))?media.path : generateAddressImg(media && media.path,1120,630)
                media.name=media.text
                images.push(media)
            })
            }
            content.push(
            <div>
                <div className='col-sm-12'>
                <h5>{g && g.title}</h5>
                <span>
                    {g && g.desc}
                </span>
                </div>
                <div className="my-2 row">
                {images.map((img)=>{
                    let mime=img.mime
                    return(
                    <div key={img._id} className="col-sm-4 pointer" onClick={(e)=>{e.preventDefault();setImageSlide(images);handleActionSlide(); setSelectImage(img._id);}} >
                        {(mime.includes("video"))?
                        <video className="img-fluid my-1" width='100%' controls> <source src={img && img.path} type={mime}/></video>:
                        <img className='img-fluid my-1' src={img.img}/>}
                    </div>
                    )
                })}
                </div>
                <b className="pointer" onClick={(e)=>{e.preventDefault(); setImageSlide(images); setTypeSlide('list'); handleActionSlide();}}>  View Gallery </b> 
            </div>
            )
        }
        if(content && content[0]){
            return(
                <section id="section-gallery" className="py-2" >
                    <h4>Photos and Video Gallery</h4>
                    <div className='d-flex flex-column mt-2'>
                        {content}
                    </div>
                </section>
            )
        } 
    }
    function handleActionSlide(){
        setOpenSlide(!openSlide)
    }
    

    return (
        <React.Suspense fallback={<div style={{position: "fixed", top: "50%", left: "50%", transform: "translate(-50%, -50%)"}}>
            <FadeLoader size={150}/></div>}>
            <LoadingOverlay  
                active={loading}
                spinner={<FadeLoader/>}
                fadeSpeed={200}
                styles={{ wrapper: { width: "100%", height: "100%" } }} 
            >

            <div className="container">
                {fixNavBar ?
                    <div style={{ backgroundColor: '#00A1AF', position: "fixed", zIndex: "1000", width: `${navWidth}px` }}>
                        <div className=" text-white">
                            <div className="d-flex align-items-center">
                                <a onClick={scrollLeft} className="float-left btn d-block d-sm-none " style={{ left: '0' }}><i className="fa fa-chevron-left"></i></a>
                                <div className="d-flex align-items-center" style={{ overflowX: "auto", height: "40px", overflowY: "hidden" }} ref={menuRef}>
                                    {createNavbar()}
                                </div>
                                <a className="float-right btn d-block d-sm-none" onClick={scrollRight} style={{ right: '0' }}><i className="fa fa-chevron-right"></i></a>
                            </div>
                        </div>
                    </div> : ''
                }
                <h1 className="text-dark font-weight-bold py-3">{band && band.name}</h1>
                {band && 
                    <RateSection
                    score={totalScore}
                    ur={totalUR}
                    wishlist={userExists}
                    share={true}
                    link={`/band/${ band.slug}`}
                    text={`${band.name}`}
                    collName="Band"
                    docID={ band._id}
                    />
                }
                <div>
                    <Divider style={{ backgroundColor: "rgba(255, 255, 255, 0.68)" }} />
                    <div className="mt-3" style={{ backgroundColor: '#00A1AF' }} ref={navRef}>
                        <div className="text-white">
                            <div className="d-flex align-items-center">
                                <a onClick={scrollLeft} className="float-left btn d-block d-sm-none " style={{ left: '0' }}><i className="fa fa-chevron-left"></i></a>
                                <div className="d-flex align-items-center" style={{ overflowX: "auto", height: "40px", overflowY: "hidden" }} ref={menuRef2}>
                                {createNavbar()}
                                </div>
                                <a className="float-right btn d-block d-sm-none" onClick={scrollRight} style={{ right: '0' }}><i className="fa fa-chevron-right"></i></a>
                            </div>
                        </div>
                    </div>
                </div>
                <div className="my-2">
                    {band && band.bandDates && band.bandDates[0] && 
                        <h4>Past Years</h4>
                    }
                    <ul className="list-group list-group-flush mt-2" id="section-bandDates">
        
                        {band && band.bandDates && band.bandDates[0] &&  band.bandDates.map((band, index) => (
                            <li className="list-group py-2"  key={band &&  band.slug +'-'+index}>
                                <div className="row" >
                                    <Link to={`/bands/${band.slug}`} className="col-3">   
                                    <LazyLoadImage
                                        src={(band.mainImg  && band.mainImg.path)?generateAddressImg(band.mainImg.path,560,315):profilePicture}
                                        className="img-fluid"
                                    />      
                                    </Link>
                                    
                                    <div className="col-9">
                                        <Link to={`/bands/${band.slug}`}>
                                            <h3 className="">
                                                {band.name} {band.year} 
                                            </h3>
                                        </Link>
                                        <div>
                                        <span>{band.dateName}  {(band.theme)?' > '+band.theme :''}</span>
                                        </div>
                                        <div>
                                            <span>
                                                {(band.score)?'Score: '+ band.score+'/10':""} 
                                                {
                                                (band.avgScore)?
                                                    (band.score)?' | UR ' + band.avgScore:'UR '+ band.avgScore
                                                :""} 
                                                {(band.avgScore)?
                                                        <GrStar size={25} style={{ color: '#ffeb3b', verticalAlign:"middle"}} />
                                                :""}
                                            </span>
                                        </div>
                                        
                                    </div>
                                </div>
                            </li>
                        ))}
                        {contentGallery()}
                        {contentResults()}
                        {contentNews()}

                        {(band && band.about)?
                            <div className=" pt-3" id='section-about'>
                                <h4>About {band && band.name}</h4>
                                {band && band.img && band.img.path &&
                                    <>
                                        <img className="img-fluid d-none d-xl-block" alt={band.name} src={generateAddressImg(band && band.img && band.img.path,1120,630)} width="100%" height="auto" />
                                        <img className="img-fluid d-none d-lg-block d-xl-none" alt={band.name} src={generateAddressImg(band && band.img && band.img.path,960,540)} width="100%" height="auto" />
                                        <img className="img-fluid d-none d-md-block d-lg-none" alt={band.name} src={generateAddressImg(band && band.img && band.img.path,720,405)} width="100%" height="auto" />
                                        <img className="img-fluid d-none d-sm-block d-md-none" alt={band.name} src={generateAddressImg(band && band.img && band.img.path,560,315)} width="100%" height="auto" />
                                        <img className="img-fluid d-block d-sm-none" alt={band.name} src={generateAddressImg(band && band.img && band.img.path,560,315)} width="100%" height="auto" />
                                    </>
                                }
                                <div className="col-12 mt-3" dangerouslySetInnerHTML={{ __html:band && band.about }} />
                            </div>:
                        ""}
                        {
                            (band && (band.contactEmail || band.contactPhone))?
                            <section id="section-contact" className="py-2">
                                <h4>{band.name} Contact info</h4>
                                <div className="col-12 mt-2">
                                    <div className="col-12 py-1">
                                        <a  href={'mailto:'+band.contactEmail}>
                                            <i class="fa fa-envelope" aria-hidden="true"></i>
                                            &nbsp;{band.contactEmail}
                                        </a>
                                    </div>
                                    <div className="col-12 py-1">
                                        <a   href={'tel:'+band && band.contactPhone}>
                                            <i class="fa fa-phone" aria-hidden="true"></i>
                                            &nbsp;{band.contactPhone}
                                        </a>
                                    </div>

                                </div>
                            </section>
                            :""
                        }
                    </ul>
                </div>
            </div>
            <Slideshow images={imageSlide} open={openSlide} handleAction={handleActionSlide} type={typeSlide} selected={selectImage}/>

            </LoadingOverlay>
        </React.Suspense>
    )
}

