import { useEffect, useState } from "react";
import { searchBand} from "../../functions/api";
import { Link } from "react-router-dom";
import generateAddressImg from "../../functions/generateAddressImg"
import { LazyLoadImage } from 'react-lazy-load-image-component';
import AwesomeDebouncePromise from 'awesome-debounce-promise';
import {TextField, Radio, RadioGroup, FormControlLabel, FormControl, FormLabel } from "@material-ui/core";
import profilePicture from "../../assets/imgs/image-not-found.jpg";
import { MdSort } from "react-icons/all"
import Popover from "../../components/Popover";


const searchAPIDebounced = AwesomeDebouncePromise(searchBand, 500);
export default function Bands() {
    const [bands, setBands] = useState([]);
    const [search, setSearch] = useState("");
    const [sort, setSort] = useState("year");
    const [sortsOpen, setSortsOpen] = useState(false);


    useEffect(()=> {
        loadData()
    }, []);

    async function loadData(){
        let params = new URLSearchParams(window.location.search);
        let newSearch = params.get("q") || "";
        let newSort = params.get("sort") || "year";
        setSearch(newSearch)
        setSort(newSort)
        let find=await searchBand(newSearch,newSort)
        setBands(find  || [])
    }

    async function handleChangeSearch(e){  
        setSearch(e.target.value)
        let find=await searchAPIDebounced(e.target.value,sort)
        setBands(find  || [])
        updateUrl(sort,e.target.value)
    }

    async function handleChangeSort(e){
        var val=e.target.value
        let find=await searchBand(search,val)
        setBands(find  || [])
        setSort(val)     
        setSortsOpen(false);
        updateUrl(e.target.value,search)   
    }
    function updateUrl(newSort,newSearch){
        console.log("updateUrl: ",newSort,newSearch)
        let queryString = new URLSearchParams({sort:newSort, q: newSearch}).toString();
        let url = window.location.protocol + "//" + window.location.host + window.location.pathname + "?" + queryString;
        window.history.pushState({path:url},'', url);
    }
    const sortContent = <FormControl component="fieldset">
        <ul className="list-group list-group-flush">
        <li className="list-group-item">
            <FormLabel className="pt-3" component="legend">Sort designers</FormLabel>
        </li>
        <li className="list-group-item">
            <RadioGroup name="sort" value={sort} onChange={handleChangeSort}>
            <FormControlLabel value="year" control={<Radio color="primary" />} label="Recent years at the top" />
            <FormControlLabel value="az" control={<Radio color="primary" />} label="A-Z" />
            </RadioGroup>
        </li>
        </ul>
    </FormControl>
    return (
        <div className="container">
            <h1 className="text-dark font-weight-bold py-3">Costume Bands</h1>
            <div className="d-flex flex-row justify-content-between align-items-center flex-wrap">
                <TextField  id="search-band" value={search || ""} placeholder="Search Mas Bands" label="Search Mas Bands"
                    variant="outlined" size="small" onChange={handleChangeSearch} />
                <Popover handleOpen={() => setSortsOpen(true)} handleClose={() => setSortsOpen(false)} open={sortsOpen}
                item={<span className="rateSectionItem"><MdSort />&nbsp;Sort</span>} id="sort" content={sortContent} />
            </div>
            <ul className="list-group list-group-flush mt-3">
                {bands && bands[0] && bands.map((band, index) => (
                    <li className="list-group-item" key={band.slug +'-'+index}>
                        <div className="row" to={`/bands/${band.slug}`}>
                            {(band.img && band.img.path)?
                            <Link to={`/band/${band.slug}`} className="col-3">
                                <LazyLoadImage
                                    src={generateAddressImg(band.img.path,560,315)}
                                    className="img-fluid"
                                />
                            </Link>:
                             <LazyLoadImage
                                src= {profilePicture}
                                className="img-fluid col-3"
                                />
                            }
                            
                            <div className="col-9">
                                <Link to={`/band/${band.slug}`}>
                                    <h3>
                                        {band.name}
                                    </h3>
                                </Link>
                                <div className="col-12 ">
                                    {band.bandDates && band.bandDates[0] && band.bandDates.map((date)=>{
                                        return (
                                            <div className="py-1">
                                                <Link key={date.slug} to={`/bands/${date && date.slug}`}>  {date.name} {date.year}</Link>
                                            </div>
                                        )
                                    })}
                                    <Link className="py-1" to={`/band/${band.slug}`}> more</Link>
                                </div>
                                
                            </div>
                        </div>
                    </li>
                ))}
            </ul>
        </div>
    )
}