import { useEffect, useState } from "react";
import { getAwards } from "../functions/api";
import { Link } from "react-router-dom";

export default function Award() {
    const [awards, setAwards] = useState(null);
    useEffect(function () {
        loadData();
    });
    const loadData = async () => {
        if (!awards) {
            setAwards(await getAwards());
        }
    }
    return (
        <div className="container">
            <h1 className="font-weight-bold text-dark py-3">Awards + Results</h1>
            <ul className="row list-group list-group-flush">
                {awards && awards[0] ? awards.map(award => (
                    <li className="list-group-item">
                        <h4 className="my-3 text-primary">{award.dateName} {award.year} Results</h4>
                        <Link to={`/awards/${award.slug}`}>More...</Link>
                    </li>
                )):<h5 className="mt-5">No award found</h5>}
            </ul>
        </div>
    )
}