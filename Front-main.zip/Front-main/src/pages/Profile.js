import React, { useEffect, useState } from 'react';
import PropTypes from 'prop-types';
import SwipeableViews from 'react-swipeable-views';
import { useTheme } from '@material-ui/core/styles';
import "../assets/styles/Profile.css";
import { useHistory } from "react-router-dom";
import {
    Button, Collapse, Divider, IconButton, InputLabel,
    Popover, Table, TableBody, TableCell, TableHead, TableRow, TextField, Box,
    Typography, Tab, Tabs, AppBar, Checkbox
} from '@material-ui/core';
import { AiOutlinePlus, TiTickOutline, BiLogOut,AiFillCamera } from "react-icons/all";
import { Link } from "react-router-dom";
import {  getProfile, updateProfile, getWatchList, removeWatchList ,searchBand,uploadProfilePicture,removeProfilePicture,logout} from '../functions/api';
import profilePicture from "../assets/imgs/profile.png";
import { Alert, AlertTitle } from '@material-ui/lab';
import CloseIcon from '@material-ui/icons/Close';
import * as moment from "moment"
import {getNames} from 'country-list'
import AwesomeDebouncePromise from 'awesome-debounce-promise';
import "react-widgets/styles.css";
import Combobox from "react-widgets/Combobox";
import Multiselect from "react-widgets/Multiselect";
import generateAddressImg from "../functions/generateAddressImg"
import Jimp from 'jimp'
import SaveIcon from '@material-ui/icons/Save';
function TabPanel(props) {
    const { children, value, index, ...other } = props;
    return (
        <div
            role="tabpanel"
            hidden={value !== index}
            id={`full-width-tabpanel-${index}`}
            aria-labelledby={`full-width-tab-${index}`}
            {...other}
        >
            {value === index && (
                <Box p={3}>
                    <Typography>{children}</Typography>
                </Box>
            )}
        </div>
    );
}

TabPanel.propTypes = {
    children: PropTypes.node,
    index: PropTypes.any.isRequired,
    value: PropTypes.any.isRequired,
};

function a11yProps(index) {
    return {
        id: `full-width-tab-${index}`,
        'aria-controls': `full-width-tabpanel-${index}`,
    };
}
const searchAPIDebounced = AwesomeDebouncePromise(searchBand, 500);
export default function Profile() {
    const [profile, setProfile] = React.useState({
        _id: "",
        name: "",
        dName: "",
        insta: "",
        email: "",
        bDate: "",
        pic: "",
        desc: "",
        loaded: false,
        countries:[],
        web:"",
        facebook:"",
        twitter:"",
        organizeBand:null,
        img:null
    })
    const [eventTemps, setEventTemps] = useState([{
        _id: "",
        name: "",
        pitch: "",
        at: "",
        type: "",
    }])
    const [bandTemps, setBandTemps] = useState([{
        _id: "",
        name: "",
        desc: "",
        dateName: "",
        at: "",
    }])
    const [watchList, setWatchList] = useState([{
        _id: "",
        slug: "",
        name: "",
        type: "",
        prefix: "",
    }])
    const [alert, setAlert] = useState({
        serverity: "",
        title: "",
        message: "",
        open: false
    })
    const [value, setValue] = React.useState(0)
    const [anchorEl, setAnchorEl] = React.useState(null);
    const [wishs, setWishs] = useState([])
    const [organizeBand, setOrganizeBand] = useState({})
    const [isOrganizer, setIsOrganizer] = useState(false)
    const [organizeMsg,setOrganizeMsg]=useState({
        show:false,
        msg:"Bnad is not valid."
    })
    const [countries, setCountries] = useState([])
    const [loading, setLoading] = useState()
    const [avatar, setAvatar] = useState(profilePicture)
    const [bands, setBands] = useState([])
    const history = useHistory()
    const theme = useTheme()
    const open = Boolean(anchorEl);

    useEffect(async () => {
        if (!wishs || !wishs[0]) {
            var response = await getWatchList()
            if (response && response.code == 0) setWishs(response.data)
        }
    }, [])
    useEffect(async ()=>{
        if (!profile.loaded) {
            const data = await getProfile()
            if(!data || !data.user) return  // show msg 
            setProfile({
                ...data.user,
                bDate: data.user && data.user.bDate ? new Date(data.user.bDate).toISOString().substring(0, 10) : "",
                loaded: true
            })
            if(data.user && data.user.organizeBand && data.user.organizeBand._id) {
                setIsOrganizer(true)
            }
            let pic=(data.user && data.user.img && data.user.img.path)? generateAddressImg(data.user.img.path,300,300):(data.user.pic||profilePicture)
            setAvatar(pic)
            setCountries(data&& data.user && data.user.countries)
            setBandTemps(data.bandTemps)
            setEventTemps(data.eventTemps)
            setWatchList(data.watchList)
            setOrganizeBand(data.user.organizeBand)
        }
    },[localStorage.token])

    async function submitProfileForm() {
        if (profile.name && profile.dName && profile.email) {
            if(isOrganizer){
                if(!organizeBand || !organizeBand._id){
                    // show message not valid band
                    setOrganizeMsg({...organizeMsg,show:true})
                    return
                }                
            }
            var oBand=organizeBand && organizeBand._id
            setOrganizeMsg({...organizeMsg,show:false})
            const res = await updateProfile({...profile,countries,organizeBand:oBand})
            if (res) {
                switch (res.code) {
                    case -1:
                        setAlert({
                            serverity: "error",
                            title: "Error",
                            message: res.msg,
                            open: true
                        })
                        break;
                    case 0:
                        setAlert({
                            serverity: "success",
                            title: "Success",
                            message: res.msg,
                            open: true
                        })
                        break;
                    case 1:
                        setProfile(res.data)
                        setAlert({
                            serverity: "warning",
                            title: "Warning",
                            message: res.msg,
                            open: true
                        })
                        break;
                    default:
                        break;
                }
            } else {
                setAlert({
                    serverity: "error",
                    title: "Error",
                    message: "Internal Server Error. Please try again later.",
                    open: true
                })
            }
        } else {
            setAlert({
                serverity: "warning",
                title: "Warning",
                message: 'Some of parameters have been missed.',
                open: true
            })
        }
        setTimeout(()=>{setAlert({open: false})},6000)
        window.scrollTo(0, 0)
    }

    const handleChange = (event, newValue) => {
        setValue(newValue);
    };
    const editProfile = (event) => {
        setProfile({ ...profile, [event.target.name]: event.target.value })
    }
    const handleChangeIndex = (index) => {
        setValue(index);
    };
    const openPopover = (event) => {
        setAnchorEl(event.currentTarget);
    }
    const handleClose = () => {
        setAnchorEl(null);
    }
    async function deleteWatchList(id) {
        const res = await removeWatchList(id);
        if (res && res.code === 1) {
            let watchListTemp = watchList.filter((w)=>w._id!=id);            
            setWatchList(watchListTemp);
        }
    }

    async function logoutAcc() {
        const res = await logout()
        if (res && res.code === 1) {
            window.location.reload();
        }
    }
    function handleChangeTagCountries(country){
        setCountries(country)
    }
    function handleChangeIsOrganizer(){
        setIsOrganizer(!isOrganizer)
    }    
    async function handleChangeOrganizeBand(band){  
        setOrganizeBand(band)
        if( typeof band === 'string'){
            let find=await searchAPIDebounced(band)
            setBands(find  || [])
        }
    }
    async function uploadProfileImage(ev){
        try{
            var file=ev.target.files[0]
            if(!file && !file.type) return
            var readFile= new FileReader()
            readFile.readAsArrayBuffer(file);
            setLoading("Uploading...")
            readFile.onloadend =  function (evt) {
                if (evt.target.readyState == FileReader.DONE) {
                   var arrayBuffer = evt.target.result; 
                   Jimp.read(arrayBuffer, (err,picture)=>{
                        if(err) {
                            window.alert("Something went wrong. try again.")
                            setLoading("")
                        } else{
                            picture.cover(400,400,Jimp.HORIZONTAL_ALIGN_CENTER | Jimp.VERTICAL_ALIGN_MIDDLE)
                            picture.getBase64(file.type,async (error,base64)=>{
                                const { type, size, name } = file;
                                let res=await uploadProfilePicture({ name, type, size, base64: base64.split('base64,').pop() })
                                if(res && res.data && res.data.img && res.data.img.path){
                                    setProfile({...profile,img:res.data.img})
                                    setAvatar(generateAddressImg(res.data.img.path,300,300))
                                }   
                                setLoading("")
                            })  
                        }
                    })
                }
            }
        }
        catch(err){
            window.alert("Something went wrong. try again.")
            setLoading("")
        }
    }
    
    async function removeTheProfilePicture () {
        try{
            const confirmed = window.confirm("Are you sure?")
            if(confirmed) {
                setLoading("wait...")
                let res=await removeProfilePicture()
                if (res.code==0){
                    let pic=res.data.pic||profilePicture
                    setAvatar(pic)
                }else{
                    alert(res.msg)
                }
                setLoading("")
            }
        }
        catch(err){
            window.alert("Something went wrong ... try again.")
        }
    }
    return (
        <div className="container">
            {
                localStorage.token ?
                    <div className="my-4 shadow-lg rounded">
                        <AppBar position="static" color="default">
                            <Tabs
                                value={value}
                                onChange={handleChange}
                                indicatorColor="primary"
                                textColor="primary"
                                variant="fullWidth"
                                aria-label="full width tabs example"
                            >
                                <Tab label="Information" {...a11yProps(0)} />
                                <Tab label="Posts" {...a11yProps(1)} />
                                <Tab label="Watch List" {...a11yProps(2)} />
                            </Tabs>
                        </AppBar>
                        <SwipeableViews
                            axis={theme.direction === 'rtl' ? 'x-reverse' : 'x'}
                            index={value}
                            onChangeIndex={handleChangeIndex}
                        >
                            <TabPanel value={value} index={0} dir={theme.direction}>
                                <div id="profileInfo" className="d-flex flex-row flex-wrap">
                                    <div className="col-12 mb-4">
                                        <Collapse in={alert.open}>
                                            <Alert severity={alert.serverity || "info"} action={
                                                <IconButton aria-label="close" color="inherit" size="small"
                                                    onClick={() => setAlert({ ...alert, open: !alert.open })}>
                                                    <CloseIcon fontSize="inherit" />
                                                </IconButton>
                                            }>
                                                <AlertTitle>{alert.title}</AlertTitle>
                                                {alert.message}
                                            </Alert>
                                        </Collapse>
                                    </div>
                                    <div className="col-lg-3 col-12 text-center">
                                        {/* <div className="profileAvatar mx-auto mb-4 rounded-circle" alt="Profile Picture"
                                            title="Profile Picture"
                                            style={{ backgroundImage: profile.pic ? `url(${profile.pic})` : `url${profilePicture}` }} /> */}
                                        <img className="img-fluid profileAvatar  rounded-circle" src={avatar}/>
                                       <div className='col-12 text-center'>
                                            <label className='pointer' for="profileImg">
                                                    <AiFillCamera size={28} />
                                                    <IconButton aria-label="close" color="inherit" size="small"
                                                        onClick={() => removeTheProfilePicture()}>
                                                        <CloseIcon fontSize="inherit" />
                                                    </IconButton>
                                            </label>
                                            <div>{loading}</div>
                                            <input className='d-none' type='file' id="profileImg" onChange={uploadProfileImage} />
                                       </div>
                                    </div>
                                    <div className="col-lg-8 col-12 my-sm-4 my-md-0 d-flex flex-column">
                                        <div className="mb-4">
                                            <InputLabel>Display Name</InputLabel>
                                            <TextField dir="auto" variant="outlined" fullWidth placeholder="Display Name" name="dName" type="text" value={profile.dName} onChange={editProfile} />
                                        </div>
                                        <div className="mb-4">
                                            <InputLabel>Full Name</InputLabel>
                                            <TextField dir="auto" required variant="outlined" fullWidth placeholder="Name" name="name" type="text" value={profile.name} onChange={editProfile} />
                                        </div>
                                        <div className="mb-4">
                                            <InputLabel>Date of Birth</InputLabel>
                                            <TextField variant="outlined" name="bDate" fullWidth value={profile.bDate} onChange={editProfile} type="date" />
                                        </div>
                                        <div className='mb-4'>
                                            <InputLabel>Cultural Identity (Where are you/family from?)</InputLabel>
                                            <Multiselect
                                                onChange={handleChangeTagCountries}
                                                name='countries'
                                                value={countries}
                                                data={getNames()}
                                                placeholder='Where are you/family from?'
                                            />
                                        </div>
                                        <div className="mb-4">
                                            <InputLabel>Instagram</InputLabel>
                                            <TextField placeholder="Instagram ID" value={profile.insta} type="text" fullWidth name="insta" variant="outlined" color="primary" onChange={editProfile} />
                                        </div>
                                        <div className="mb-4">
                                            <InputLabel>Web</InputLabel>
                                            <TextField placeholder="web Address" value={profile && profile.web} type="text" fullWidth name="web" variant="outlined" color="primary" onChange={editProfile} />
                                        </div>
                                        <div className="mb-4">
                                            <InputLabel>Twitter</InputLabel>
                                            <TextField placeholder="Twitter ID" value={profile && profile.twitter} type="text" fullWidth name="twitter" variant="outlined" color="primary" onChange={editProfile} />
                                        </div>
                                        <div className="mb-4">
                                            <InputLabel>Facebook</InputLabel>
                                            <TextField placeholder="Facebook ID" value={profile && profile.facebook} type="text" fullWidth name="facebook" variant="outlined" color="primary" onChange={editProfile} />
                                        </div>
                                        <div className="mb-4 ">
                                            <InputLabel>About you</InputLabel>
                                            <TextField dir="auto" placeholder="Write your story" value={profile && profile.desc} type="text" multiline fullWidth name="desc" variant="outlined" color="primary" onChange={editProfile} />
                                        </div>
                                        <div className='mb-4'>
                                            <InputLabel>
                                                <Checkbox checked={isOrganizer} onChange={handleChangeIsOrganizer} style={{paddingInline: "0px"}}>
                                                </Checkbox> I am band organizer
                                            </InputLabel>
                                            {isOrganizer?
                                            <>
                                                <InputLabel>Band: </InputLabel>
                                                <Combobox
                                                    hideCaret
                                                    hideEmptyPopup
                                                    data={bands}
                                                    defaultValue={profile.organizeBand}
                                                    textField='name'
                                                    placeholder="Search for a band"
                                                    onChange={handleChangeOrganizeBand}
                                                    required
                                                    name='organizeBand'
                                                />
                                                {
                                                (organizeMsg.show)?
                                                    <small className="text-danger">{organizeMsg.msg}</small>:""
                                                }
                                                {
                                                (profile && profile.organizeBand && profile.organizeBand.isVerify && (profile.organizeBand._id==organizeBand._id))?
                                                    <small className="text-success">Verified</small>:""
                                                }
                                                {
                                                (profile && profile.organizeBand && !profile.organizeBand.isVerify && (profile.organizeBand._id==organizeBand._id))?
                                                    <small className="text-warning">Not Verified Yet</small>:""
                                                }
                                            </>
                                            :""}
                                        </div>
                                    </div>
                                    <div className="my-3 col-12 d-flex flex-row justify-content-between">
                                        <Button variant="outlined" color="secondary" onClick={logoutAcc}>
                                          <BiLogOut style={{marginRight: "5px", fontSize: "20px"}}/> Sign out
                                        </Button>
                                        <Button variant="outlined" color="primary" onClick={submitProfileForm}>
                                          <SaveIcon style={{marginRight: "5px", fontSize: "20px"}}/> Submit
                                        </Button>
                                    </div>
                                    <Divider flexItem orientation="horizontal" />
                                </div>
                            </TabPanel>
                            <TabPanel value={value} index={1} dir={theme.direction}>
                                <div>
                                    <Button variant="contained" color="primary" onClickCapture={openPopover}><AiOutlinePlus />Add Your</Button>
                                    <Popover
                                        id="postType"
                                        open={open}
                                        anchorEl={anchorEl}
                                        onClose={handleClose}
                                        anchorOrigin={{
                                            vertical: 'bottom',
                                            horizontal: 'center',
                                        }}
                                        transformOrigin={{
                                            vertical: 'top',
                                            horizontal: 'center',
                                        }}>
                                        <ul className="list-group list-group-flush mx-4 my-2 text-center">
                                            <Link to="/event/form" className="list-group-item">Event</Link>
                                            {/* <Link to="/band/form" className="list-group-item">Costume</Link> */}
                                        </ul>
                                    </Popover>
                                    <Divider className="my-4" />
                                    <h3>Recent Events</h3>
                                    <Table>
                                        <TableHead>
                                            <TableRow>
                                                <TableCell className="font-weight-bold">Name</TableCell>
                                                <TableCell className="font-weight-bold">Type</TableCell>
                                                <TableCell className="font-weight-bold">Pitch</TableCell>
                                                <TableCell className="font-weight-bold">At</TableCell>
                                            </TableRow>
                                        </TableHead>
                                        <TableBody>
                                            {eventTemps.map(event => (
                                                <TableRow key={event.name}>
                                                    <TableCell>{event.name}</TableCell>
                                                    <TableCell>{event.type}</TableCell>
                                                    <TableCell dangerouslySetInnerHTML={{ __html: event.pitch }} />
                                                    <TableCell>{moment(event.at).utc().format('dddd MMMM DD, YYYY')}</TableCell>
                                                </TableRow>
                                            ))}
                                        </TableBody>
                                    </Table>
                                    <Divider flexItem className="my-4" />
                                    <h3>Recent Bands</h3>
                                    <Table>
                                        <TableHead>
                                            <TableRow>
                                                <TableCell className="font-weight-bold">Name</TableCell>
                                                <TableCell className="font-weight-bold">Festival</TableCell>
                                                <TableCell className="font-weight-bold">Description</TableCell>
                                                <TableCell className="font-weight-bold">At</TableCell>
                                            </TableRow>
                                        </TableHead>
                                        <TableBody>
                                            {bandTemps.map(band => (
                                                <TableRow key={band.name}>
                                                    <TableCell>{band.name}</TableCell>
                                                    <TableCell>{band.dateName}</TableCell>
                                                    <TableCell dangerouslySetInnerHTML={{ __html: band.desc }} />
                                                    <TableCell>{moment(band.at).utc().format('dddd MMMM DD, YYYY')}</TableCell>
                                                </TableRow>
                                            ))}
                                        </TableBody>
                                    </Table>
                                </div>
                            </TabPanel>
                            <TabPanel value={value} index={2} dir={theme.direction}>
                                <div className="my-4">
                                    <h3 className="font-weight-bold text-dark">Watch list {watchList && watchList.length === 0 && 'is empty'}</h3>
                                    <Table>
                                        <TableHead>
                                            <TableRow>
                                                <TableCell className="font-weight-bold">Type</TableCell>
                                                <TableCell className="font-weight-bold">Name</TableCell>
                                                <TableCell className="font-weight-bold">Action</TableCell>
                                            </TableRow>
                                        </TableHead>
                                        <TableBody>
                                            {watchList && watchList.map(item => (
                                                <TableRow key={item.name}>
                                                    <TableCell width="35%">{item.type}</TableCell>
                                                    <TableCell width="35%">{item.name}</TableCell>
                                                    <TableCell width="30%">
                                                        <Button variant="outlined" color="primary" onClick={() => {
                                                            history.push(`${item.prefix}/${item.slug}`)
                                                        }}>Visit</Button>
                                                        <Button className="mx-2" variant="outlined" color="secondary" onClick={() => deleteWatchList(item._id)}>Delete</Button>
                                                    </TableCell>
                                                </TableRow>
                                            ))}
                                        </TableBody>
                                    </Table>
                                </div>
                            </TabPanel>
                        </SwipeableViews>
                    </div>
                    :
                    history.push("/")
            }
        </div>
    );
}
