import { Divider, InputLabel, TextField, Select, MenuItem, Button } from "@material-ui/core";
import { useState } from "react"
import Tag from "../components/Tag";
import { animateScroll as scroll } from 'react-scroll';
import FilePicker from "../components/FilePicker";
import convertBase64 from "../functions/base64converter";
import { PayPalButton } from "react-paypal-button-v2";

export default function AdForm() {
    const [page, setPage] = useState(0);
    const [amount, setAmount] = useState("0")
    const [data, setData] = useState({
        name: null,
        desc: null,
        link: null,
        sDate: null,
        eDate: null,
        country: null,
        address: null,
        type: null,
        tags: null,
        small: null,
        large: null
    });
    async function getSmall(files) {
        setData({ ...data, small: await convertBase64(files[0]) })
    }
    async function getLarge(files) {
        setData({ ...data, large: await convertBase64(files[0]) })
    }
    function nextPage() {
        scroll.scrollToTop();
        setPage(1);
    }
    function previousPage() {
        setPage(0);
    }
    function editForm(event) {
        setData({ ...data, [event.target.name]: event.target.value });
        if (event.target.name == 'type') {
            switch (event.target.value) {
                case "landingPage":
                    setAmount("10.00")
                    break;
                case "screen":
                    setAmount("10.00")
                    break;
                case "prime":
                    setAmount("20.00")
                    break;
                case "content":
                    setAmount("30.00")
                    break;
                case "text":
                    setAmount("30.00")
                    break;
                default:
                    break;
            }
        }
    }
    function getTags(name, tags) {
        setData({ ...data, [name]: tags });
    }
    return (
        <div className="container my-4 py-3 card shadow-lg">
            <h3 className="titleText mb-3">Add/Edit Advertisement</h3>
            <Divider />
            {page === 0 &&
                <form>
                    <div className="form-group my-4">
                        <InputLabel>Campaign Name</InputLabel>
                        <TextField variant="outlined" value={data.name} color="primary" fullWidth placeholder="Name" name="name" onChange={editForm} />
                    </div>
                    <div className="form-group my-4">
                        <InputLabel>Quick Description of product/service</InputLabel>
                        <TextField variant="outlined" value={data.desc} multiline color="primary" fullWidth placeholder="Description" name="desc" onChange={editForm} />
                    </div>
                    <div className="form-group my-4">
                        <InputLabel>Link to more info/your content</InputLabel>
                        <TextField variant="outlined" value={data.link} color="primary" fullWidth placeholder="Link" name="link" onChange={editForm} />
                    </div>
                    <div className="form-group my-4">
                        <InputLabel>Start Date</InputLabel>
                        <TextField type="date" value={data.sDate} variant="outlined" color="primary" name="sDate" onChange={editForm} />
                    </div>
                    <div className="form-group my-4">
                        <InputLabel>End Date</InputLabel>
                        <TextField type="date" value={data.eDate} variant="outlined" color="primary" name="eDate" onChange={editForm} />
                    </div>
                    <h4 className="text-dark my-3">Audience Location</h4>
                    <Divider />
                    <div className="form-group my-4">
                        <InputLabel>Country</InputLabel>
                        <TextField fullWidth type="text" value={data.country} placeholder="Country" variant="outlined" color="primary" name="country" onChange={editForm} />
                    </div>
                    <div className="form-group my-4">
                        <InputLabel>Center Address</InputLabel>
                        <TextField fullWidth type="text" value={data.address} placeholder="Address" multiline variant="outlined" color="primary" name="address" onChange={editForm} />
                    </div>
                    <h4 className="text-dark my-3">AD Type</h4>
                    <Divider />
                    <div className="form-group my-4">
                        <InputLabel>Type</InputLabel>
                        <Select value={data.type} variant="outlined" color="primary" name="type" onChange={editForm}>
                            <MenuItem className="d-flex flex-column" value="landingPage">
                                <h6 className="font-weight-bold">Landing Page -5 Days - $10</h6>
                                <p>ADs that are always visible</p>
                            </MenuItem>
                            <MenuItem className="d-flex flex-column" value="screen">
                                <h6 className="font-weight-bold">Screen Adhesive - 5 Days - $10</h6>
                                <p>ADs that are always visible</p>
                            </MenuItem>
                            <MenuItem className="d-flex flex-column" value="prime">
                                <h6 className="font-weight-bold">Prime time - 5 Days - $20</h6>
                                <p>ADs that are located in prime locations</p>
                            </MenuItem>
                            <MenuItem className="d-flex flex-column" value="content">
                                <h6 className="font-weight-bold">Content - 5 Days - $30</h6>
                                <p>ADs that are effectively integrated between content</p>
                            </MenuItem>
                            <MenuItem className="d-flex flex-column" value="text">
                                <h6 className="font-weight-bold">Text Ads - 5 Days - $30</h6>
                                <p>ADs that are paired with keyword search</p>
                            </MenuItem>
                        </Select>
                    </div>
                    <div className="form-group my-4">
                        <InputLabel>Key Words</InputLabel>
                        <Tag name="tags" updateTags={getTags} />
                    </div>
                    <div className="form-group my-4">
                        <InputLabel>Small Image</InputLabel>
                        <FilePicker updateFilesCb={getSmall} />
                    </div>
                    <div className="form-group my-4">
                        <InputLabel>Large Image</InputLabel>
                        <FilePicker updateFilesCb={getLarge} />
                    </div>
                    <Button type="button" variant="outlined" color="primary" onClick={nextPage}>Next</Button>
                </form>
            }
            {page === 1 &&
                <form>
                    <div className="my-4 form-group d-flex flex-wrap justify-content-center">
                        <InputLabel className="col-4">
                            <h6 className="my-2">Amount:&nbsp;{amount}&nbsp;$USD</h6>
                            <h6 className="my-2 text-capitalize">Type:&nbsp;{data.type}</h6>
                            <h6 className="my-2">Name:&nbsp;{data.name}</h6>
                            <h6 className="my-2">Link:&nbsp;{data.link}</h6>
                        </InputLabel>
                        <Divider flexItem orientation="vertical" className="mx-2" />
                        <InputLabel className="col-4">
                            <h6 className="my-2">Start Date:&nbsp;{data.sDate}</h6>
                            <h6 className="my-2">End Date:&nbsp;{data.eDate}</h6>
                            <h6 className="my-2">Country:&nbsp;{data.country}</h6>
                            <h6 className="my-2">Address:&nbsp;{data.address}</h6>
                        </InputLabel>
                        <PayPalButton
                            amount={amount}
                            // shippingPreference="NO_SHIPPING" // default is "GET_FROM_FILE"
                            onSuccess={async (details, data) => {
                                alert("Transaction completed by " + details.payer.name.given_name);
                                // OPTIONAL: Call your server to save the transaction
                                return await fetch("/paypal-transaction-complete", {
                                    method: "post",
                                    body: JSON.stringify({
                                        orderId: data.orderID
                                    })
                                });
                            }}
                            options={{
                                clientId: "PRODUCTION_CLIENT_ID"
                            }}
                        />
                    </div>
                    <Button type="button" variant="outlined" color="primary" onClick={previousPage}>Previous</Button>
                    {/* <Button className="mx-3" type="button" variant="outlined" color="primary" onClick={submit}>Submit</Button> */}
                </form>
            }
        </div>
    )
}