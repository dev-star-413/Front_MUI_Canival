import { Link } from "react-router-dom";
import * as moment from "moment";
import generateAddressImg from '../../functions/generateAddressImg'
export default function EventCard({ event }) {
    return (
        <div className="col-md-4 col-sm-6 my-3">
            <Link className="linkCard card shadow-sm" to={`/events/${event.slug}`}>
                {/* <div className="cardImage" style={{ backgroundImage: `url('${event.imgs[0] && event.imgs[0].path}')` }} /> */}
                <img className="img-fluid" src={generateAddressImg(event.imgs[0] && event.imgs[0].path,300,400)}/>

                <div className="px-2 py-3">
                    <h5 className="card-title text-dark">{event.name}{event.price && ` - $${event.price}USD`}
                        <br />
                        <small className="text-muted">
                            {moment(event.sDate).utc().format('ddd, MMM DD, YYYY')}
                            {event.vName && ` @ ${event.vName}`}
                            {event.city && ` - ${event.city.name}`}
                        </small>
                    </h5>
                </div>
            </Link>
        </div>
    )
}