import React,{ useEffect, useState, useRef } from "react";
import { getEvent } from "../../functions/api";
import convertToUSD  from "../../functions/convertCurrency";
import { animateScroll as scroll } from 'react-scroll';
import generateAddressImg from "../../functions/generateAddressImg";
import {  LazyLoadComponent } from 'react-lazy-load-image-component';
import FadeLoader from "react-spinners/FadeLoader";
import { MenuItem} from "@material-ui/core";
import { Link } from "react-router-dom";
const EventCard =React.lazy(()=>import("./EventCard"))
const Map =React.lazy(()=>import("../../components/Map"))
export default function Event({ match }) {
    const [theEvent, setEvent] = useState(null);
    const [city, setCity] = useState(null);
    const [similiars, setSimiliars] = useState(null);
    const [carnival, setCarnival] = useState(null);
    const navRef = useRef(null);
    const menuRef = useRef()
    const menuRef2 = useRef()
    const [fixNavBar, setFixNavBar] = useState(false)
    const [fixedMenuWidth, setFixedMenuWidth] = useState(0);
    const [currencyRates,setCurrencyRates]=useState([])
    useEffect(function () {
        loadData();
    }, [match.params.slug]);
    useEffect(function () {
        window.addEventListener('scroll', handleScroll)
        window.addEventListener("hashchange", function () {
            window.scrollTo(window.scrollX, window.scrollY - 100);
        });
    }, [])
    var changeNavbar = false
    const handleScroll = () => {
        var navBarRect = navRef && navRef.current && navRef.current.getBoundingClientRect();
        navBarRect && setFixedMenuWidth(navBarRect.width);
        if (navBarRect && navBarRect.y < 53 && !changeNavbar) {
            setFixNavBar(true)
        }
        else if (navBarRect && navBarRect.y > 50) {
            setFixNavBar(false)
        }
    }
    const loadData = async () => {
        let data;
        if (!theEvent || theEvent.slug !== match.params.slug) {
            data = await getEvent(match.params.slug);
            setEvent(data.event)
            setSimiliars(data.similarEvents)
            setCarnival(data.carnival)
            setCity(data.city)
            setCurrencyRates(data && data.currencyRates)
            scroll.scrollToTop()
        }
    }
    const getSymbolCurrency=(x)=>{
        var rate=currencyRates.find((r)=>r.from==x)
        return rate && rate.symbol
      }
    if (theEvent) {
        var imgs = []
        if (theEvent.imgs && theEvent.imgs.length > 0) {
            for (let img of theEvent.imgs) {
                if( img && img.path){
                    imgs.push(
                        <div key={img.path} className="col-md-4 col-lg-3 col-6">
                            {/* <div className="galleryImage mb-3 rounded" style={{ backgroundImage: `url('${img.path}')` }} /> */}
                            <img className="img-fluid" src={generateAddressImg(img.path,300,400)}/>
                            
                        </div>
                    )
                }
            }
        }
    }
    const scrollLeft = function () {
        if (menuRef && menuRef.current) menuRef.current.scrollLeft += -50
        menuRef2.current.scrollLeft += -50
    }
    const scrollRight = function () {
        if (menuRef && menuRef.current) menuRef.current.scrollLeft += 50
        menuRef2.current.scrollLeft += 50
    }
    return (
        <React.Suspense fallback={<div style={{position: "fixed", top: "50%", left: "50%", transform: "translate(-50%, -50%)"}}><FadeLoader size={150}/></div>}>
        <section className="p-0 container" onScroll={handleScroll.bind()}>
            {(fixNavBar) ?
                <div>
                    <div style={{ backgroundColor: '#00A1AF', position: "fixed", zIndex: "1000", width: fixedMenuWidth }}>
                        <div className=" text-white">
                            <div className="d-flex align-items-center">
                                <a onClick={scrollLeft} className="float-left btn d-block d-sm-none " style={{ left: '0' }}><i className="fa fa-chevron-left"></i></a>
                                <div className="d-flex align-items-center" style={{ overflowX: "auto", height: "40px", overflowY: "hidden" }} ref={menuRef}>
                                    <a className="p-3 text-white" href="#section-about">About</a><span className="text-secondary">|</span>
                                    <a className="p-3 text-white" href="#section-description">Details</a><span className="text-secondary">|</span>
                                    {carnival && imgs && Array.isArray(imgs) && imgs.length >0 && <> <a className="p-3 text-white" href="#section-gallery">Gallery</a><span className="text-secondary">|</span></>}
                                    {carnival && similiars && similiars.length > 0 && <><a className="p-3 text-white " href="#section-similiars">Similliar</a><span className="text-secondary">|</span></>}
                                    <a className="p-3 text-white" href="#section-map">Map</a>
                                </div>
                                <a className="float-right btn d-block d-sm-none" onClick={scrollRight} style={{ right: '0' }}><i className="fa fa-chevron-right"></i></a>
                            </div>
                        </div>
                    </div>
                </div>
                : ''}
            {theEvent ?
                <>
                    <div className="d-flex justify-content-between">
                        <h1 className="py-3 font-weight-bold align-items-center text-capitalize">
                            {theEvent.name}
                        </h1>
                        {theEvent.link &&
                            <h3 className="py-3"><a href={theEvent.link} className="text-white btn btn-primary" >Buy Tix</a></h3>
                        }
                    </div>
                    <h6 className="font-weight-bold">
                        {theEvent.sDate}
                        {theEvent.sDate && theEvent.vName && ' - '}
                        {theEvent.vName}
                        {(theEvent.vName || theEvent.sDate) && theEvent.city && ' - '}
                        {theEvent.city && theEvent.city.name}
                    </h6>
                    {/* <div className='text-center d-flex justify-content-center align-items-end'
                        style={theEvent && theEvent.imgs && theEvent.imgs[0] && {
                            backgroundImage: `url('${theEvent.imgs[0].path}')`,
                            backgroundSize: 'contain',backgroundRepeat:"no-repeat",
                            backgroundPosition: 'center', height: '70vh'
                        }} >
                    </div> */}
                    {(theEvent && Array.isArray(theEvent.imgs) && theEvent.imgs[0] && theEvent.imgs[0].path)? <img src={generateAddressImg(theEvent.imgs[0].path,1120,630)} className="img-fluid"/>:""}
                    <div className="my-2" dangerouslySetInnerHTML={{ __html: theEvent.pitch }} />
                    <div style={{ backgroundColor: '#00A1AF' }} ref={navRef}>
                        <div className=" text-white">
                            <div className="d-flex align-items-center">
                                <a onClick={scrollLeft} className="float-left btn d-block d-sm-none " style={{ left: '0' }}><i className="fa fa-chevron-left"></i></a>
                                <div className="d-flex align-items-center" style={{ overflowX: "auto", height: "40px", overflowY: "hidden" }} ref={menuRef2}>
                                    <a className="p-3 text-white" href="#section-about">About</a><span className="text-secondary">|</span>
                                    {theEvent &&  theEvent.desc && <><a className="p-3 text-white" href="#section-description">Details</a><span className="text-secondary">|</span></>}
                                    {carnival && imgs && Array.isArray(imgs) && imgs.length >0 &&  <><a className="p-3 text-white" href="#section-gallery">Gallery</a><span className="text-secondary">|</span></>}
                                    {carnival && similiars && similiars.length > 0 && <><a className="p-3 text-white" href="#section-similiars">Similliar</a><span className="text-secondary">|</span></>}
                                    <a className="p-3 text-white" href="#section-map">Map</a>
                                </div>
                                <a className="float-right btn d-block d-sm-none" onClick={scrollRight} style={{ right: '0' }}><i className="fa fa-chevron-right"></i></a>
                            </div>
                        </div>
                    </div>
                    <div id="section-about" style={{ minHeight: "40vh" }}>
                        <div className="container py-4">
                            <h3>
                                About {theEvent.name} {carnival && `at ${carnival}`}
                            </h3>
                            <div className="col-12 py-2">
                                <h6>What: <b>{theEvent.name}</b></h6>
                                <h6>Starts: <b>{theEvent.sDate}</b></h6>
                                <h6>Ends: <b>{theEvent.eDate}</b></h6>
                                {theEvent.vAddress &&
                                    <h6>Where: <b>{theEvent.vName}{theEvent.vAddress && theEvent.vName && " - "}{theEvent.vAddress}{(theEvent.vName || theEvent.vAddress) && theEvent.city && ` - ${theEvent.city.name}`}{city && city.state && `, ${city.state}`}</b></h6>}
                                <h6>Types: <b>{theEvent.types}</b></h6>
                                {theEvent.price && 
                                <h6>Price: <b>{(theEvent.currency!='USD')?
                                getSymbolCurrency(theEvent.currency)+theEvent.price+" "+theEvent.currency+' ($'+convertToUSD(theEvent.price,currencyRates,theEvent.currency)+' USD)':
                                '$'+theEvent.price+' USD'}</b></h6>
                                }
                            </div>
                        </div>
                    </div>
                    <hr style={{ color: '#292b2c ', backgroundColor: '#292b2c ' }} />
                    <div id="section-description" style={{ minHeight: "40vh" }}>
                        <div className="container py-4">
                            <h3 className="text-capitalize">
                                {theEvent.name} Details {carnival && `- ${carnival}`}
                            </h3>
                            <div className="col-12 py-2">
                                <h6>
                                    {theEvent.sDate} 05:30 PM to 10:00 PM {theEvent && theEvent.city && theEvent.city.name}
                                </h6>
                                <div dangerouslySetInnerHTML={{ __html: theEvent.desc }} />
                            </div>
                        </div>
                    </div>
                    {imgs && imgs.length > 0 &&
                        <>
                            <hr style={{ color: '#292b2c ', backgroundColor: '#292b2c ' }} />
                            <div id="section-gallery" style={{ minHeight: "40vh" }}>
                                <div className="container py-4">
                                    <h3>{theEvent.name} Gallery Images {carnival && `- ${carnival}`}</h3>
                                    <div className="col-12 py-2">
                                        <div className="row">
                                            {imgs}
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </>
                    }
                    <hr style={{ color: '#292b2c ', backgroundColor: '#292b2c ' }} />
                    <div id="section-map" style={{ minHeight: "40vh" }}>
                        <div className="container py-4">
                            <h3>Where is  {theEvent && theEvent.vName}</h3>
                            <div className="py-2">
                                <React.Suspense fallback={<div style={{position: "fixed", top: "50%", left: "50%", transform: "translate(-50%, -50%)"}}><FadeLoader size={150}/></div>}>
                                    <LazyLoadComponent>
                                        <Map marker={theEvent && theEvent.location} address={theEvent && theEvent.vAddress} city={city && city.latlng}/>
                                    </LazyLoadComponent>
                                </React.Suspense>
                                <div className="col-12 text-center py-2">
                                    <span className="py-2">{theEvent && theEvent.vName}</span><br />
                                    <span className="py-2">{theEvent && theEvent.vAddress}</span>
                                </div>
                            </div>
                        </div>
                    </div>
                    <hr style={{ color: '#292b2c ', backgroundColor: '#292b2c ' }} />

                    {carnival && similiars && similiars.length > 0 &&
                        <div id="section-similiars" style={{ minHeight: "40vh" }}>
                            <div className="container py-4">
                                <h3>Similiar Events at {carnival}</h3>
                                <div className="col-12 py-2">
                                    <div className="row">
                                        {similiars.map(sim => (
                                            <EventCard key={sim._id} event={sim} />
                                        ))}
                                    </div>
                                </div>
                            </div>
                        </div>
                    }
                    {theEvent && theEvent.tags && theEvent.tags[0] &&
                    <div className="mb-5">
                        <h3>Event Tags</h3>
                        <div className="col-12">
                            <div className="row">
                                {theEvent.tags.map(function(tag) {
                                return (
                                    <MenuItem key={tag.id} value={tag.value}>
                                    <Link to={'/events?tag='+tag.slug}>
                                        {tag.value}
                                    </Link>
                                    </MenuItem>
                                );
                                })}
                            </div>
                        </div>
                    </div>
                    }
                </> :
                <h1 className="pt-4 text-center">No event found</h1>
            }
        </section>
        </React.Suspense>
    )
}