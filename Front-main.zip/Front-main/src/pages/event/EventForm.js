import {
    Button, Collapse, Divider, IconButton, InputAdornment, InputLabel, MenuItem, Select, TextField,
    Radio,RadioGroup,FormControlLabel,FormLabel, Checkbox
} from "@material-ui/core";
import { useEffect, useState } from "react";
import convertBase64 from "../../functions/base64converter";
import { BsImages, IoCloseSharp } from "react-icons/all";
import { createPost, getFormData } from "../../functions/api";
import { Alert, AlertTitle } from "@material-ui/lab";
import CloseIcon from '@material-ui/icons/Close';
import { useHistory } from "react-router";
import generateAddressImg from '../../functions/generateAddressImg'

export default function EventForm({ match }) {
    const history = useHistory();
    const [sizeMsg, setSizeMsg] = useState(false)
    const [event, setEvent] = useState({
        name: null,
        city: null,
        country: null,
        state: null,
        dId: null,
        vName: null,
        vAddress: null,
        frequency: null,
        sDate: null,
        eDate: null,
        mGenre: '',
        types: [],
        pitch: '',
        price: null,
        link: null,
        desc: null,
        imgs: null,
    })
    const [form, setForm] = useState({
        cities: [],
        countries: [],
        dates: null,
        loaded: false,
        submitted: false,
    })
    const [alert, setAlert] = useState({
        serverity: "",
        title: "",
        message: "",
        open: false
    })
    const eventTypes = ['Boat/Cruise','Carnival Band Launch', 'Comedy','Fashion Show','Food/Drinks','Dance party']
    eventTypes.sort();
    const musicTypes =  ['Soca majority', 'Dancehall Reggae majority', 'Hip Hop Majority'];
    function editEvent(e) {
        if (e.target.name == "types") {
            var types=event.types
            if(e.target.checked ) types.push(e.target.value)
            else types=types.filter((ty)=>ty!=e.target.value)
            setEvent({ ...event, types })
        } else {
            setEvent({ ...event, [e.target.name]: e.target.value })
        }
    }
    useEffect(() => {
        loadData();
    }, [])
    const loadData = async () => {
        if (!form.loaded) {
            const data = await getFormData('event');
            if (data && data.code == -1) {
                setAlert({ ...alert, open: true, message: "Some thing is wrong.", title: "Error", serverity: 'error' });
            }
            else if (data) setForm({
                cities: data.cities,
                dates: data.dates,
                loaded: true,
                countries: data.countries,
            });
        }
    }
    async function submit() {
        if (event.name) {
            const res = await createPost("event-temp", event);
            if (res && res.code) {
                switch (res.code) {
                    case -1:
                        setAlert({ ...alert, open: true, message: res.msg, serverity: 'error', title: 'Error' });
                        break;
                    case 0:
                        setAlert({ ...alert, open: true, message: res.msg, serverity: 'warning', title: 'Warning' });
                        break;
                    case 1:
                        setAlert({ ...alert, open: true, message: res.msg, serverity: 'success', title: 'Success' });
                        setForm({ ...form, submitted: true });
                        break;
                    default:
                        setAlert({ ...alert, open: false });
                        setEvent({
                            name: null,
                            city: null,
                            dId: null,
                            vName: null,
                            vAddress: null,
                            frequency: null,
                            sDate: null,
                            eDate: null,
                            mGenre: '',
                            types: [],
                            pitch: '',
                            price: null,
                            link: null,
                            desc: null,
                            imgs: null,
                        });
                        break;
                }
            }
        } else {
            setAlert({ ...alert, open: true, message: "Some fields have been missed.", title: "Warning", serverity: 'warning' });
        }
    }
    const styles = {
        input: {
            marginBottom: "2rem",
            marginTop: "1rem"
        },
        representImage: {
            display: "flex",
            flexDirection: "row",
            border: "1px dashed #212121",
            borderRadius: "7px"
        },
        image: {
            margin: "1rem"
        },
        imageBackground: {
            backgroundImage: `url(${event.imgs && event.imgs.data})`,
            backgroundPosition: "center",
            backgroundRepeat: "no-repeat",
            backgroundSize: "contain",
            width: "7rem",
            height: "7rem",
            borderRadius: "10px"
        }
    }
    var representImage;
    if (event.imgs) {
        representImage = (
            <div style={styles.representImage}>
                <div style={styles.image}>
                    {/* <div style={styles.imageBackground} /> */}
                    <img className="img-fluid" src={generateAddressImg(event.imgs && event.imgs.data,150,150)}/>
                    <Button style={{
                        marginTop: "0.3rem",
                        width: "7rem"
                    }} color="secondary" variant="text"
                        onClick={() => {
                            // remove this image from array
                            setEvent({ ...event, imgs: null })
                        }}><IoCloseSharp style={{ fontSize: "1.1rem" }} />&nbsp;Remove</Button>
                </div>
            </div>
        )
    }
    return (
        <div className="container">
            <div className="card shadow-lg my-5 px-5">
                <h3 className="titleText my-4">Add/Edit Event</h3>
                {!form.submitted && <Divider />}
                <section>
                    {!form.submitted &&
                        <>
                            <div className="form-group my-4">
                                <InputLabel>Event Name</InputLabel>
                                <TextField fullWidth color="primary" required value={event && event.name}
                                    variant="outlined" name="name" placeholder="Name" onChange={editEvent} />
                            </div>
                            <div className="form-group my-4">
                                <InputLabel>Venue Name</InputLabel>
                                <TextField fullWidth color="primary" value={event && event.vName} dir="auto"
                                    variant="outlined" name="vName" placeholder="Venue" onChange={editEvent} />
                            </div>
                            <div className="form-group my-4">
                                    <InputLabel>Venue Address</InputLabel>
                                    <TextField placeholder="Address" fullWidth color="primary" variant="outlined"
                                        value={event && event.vAddress} multiline dir="auto" name="vAddress" onChange={editEvent} />
                                </div> 
                            <div className="row">
                                {/* {form.countries &&
                                    <div className="form-group my-4 col-md-6">
                                        <InputLabel>Country</InputLabel>
                                        <Select fullWidth required name="country" onChange={editEvent} variant="outlined" color="primary">
                                            {form.countries.map(country => <MenuItem value={country}>{country}</MenuItem>)}
                                        </Select>
                                    </div>
                                }
                                {form.cities &&
                                    <div className="form-group my-4 col-md-6">
                                        <InputLabel>State</InputLabel>
                                        <Select disabled={!event.country} fullWidth required name="state" onChange={editEvent} variant="outlined" color="primary">
                                            {form.cities.map(city => city.country === event.country && <MenuItem value={city.state}>{city.state}</MenuItem>)}
                                        </Select>
                                    </div>
                                }
                                {form.cities &&
                                    <div className="form-group my-4 col-md-6">
                                        <InputLabel>City</InputLabel>
                                        <Select disabled={!event.state} fullWidth required name="city" onChange={editEvent} variant="outlined" color="primary">
                                            {form.cities.map(city => city.state === event.state && <MenuItem value={city.id}>{city.name}</MenuItem>)}
                                        </Select>
                                    </div>
                                } */}
                                {/* <div className="form-group my-4 col-md-6">
                                    <InputLabel>Venue Address</InputLabel>
                                    <TextField placeholder="Address" fullWidth color="primary" variant="outlined"
                                        value={event && event.vAddress} multiline dir="auto" name="vAddress" onChange={editEvent} />
                                </div> */}
                                <div className="form-group my-4 col-md-6">
                                    <InputLabel>Start Date</InputLabel>
                                    <TextField color="primary" type="datetime-local" value={event && event.sDate}
                                        variant="outlined" name="sDate" onChange={editEvent} />
                                </div>
                                <div className="form-group my-4 col-md-6">
                                    <InputLabel>End Date</InputLabel>
                                    <TextField color="primary" type="datetime-local" value={event && event.eDate}
                                        variant="outlined" name="eDate" onChange={editEvent} />
                                </div>
                                {form.dates &&
                                    <div className="form-group my-4 col-md-12">
                                        <InputLabel>Festival Date</InputLabel>
                                        <Select fullWidth name="dId" required onChange={editEvent} variant="outlined" color="primary">
                                            {form.dates.map(date => <MenuItem value={date.id}>{date.name}</MenuItem>)}
                                        </Select>
                                    </div>
                                }
                            </div>
                            <div className="form-group my-4">
                                <FormLabel>Music Type/Genre</FormLabel>
                                <RadioGroup row aria-labelledby="demo-row-radio-buttons-group-label">
                                {musicTypes.map(musicType => {
                                    return(
                                        <FormControlLabel id={musicType} key={musicType}  value={musicType} name='mGenre' control={<Radio onChange={editEvent}  color="primary" />} label={musicType}/>
                                    )
                                })}
                                </RadioGroup>

                            </div>
                            <div className="form-group d-flex flex-column my-4">
                                <FormLabel>Event Type</FormLabel>
                                <RadioGroup row aria-labelledby="demo-row-radio-buttons-group-label">
                                {eventTypes.map(eventType => {
                                    return(
                                        <FormControlLabel id={eventType} key={eventType}  value={eventType} name='types' control={<Checkbox onChange={editEvent}  color="primary" />} label={eventType}/>
                                    )
                                })}
                                </RadioGroup>
                            </div>
                            <div className="form-group my-4">
                                <InputLabel>Pitch/Summary</InputLabel>
                                <TextField fullWidth multiline placeholder="Pitch" color="primary" value={event && event.pitch}
                                    variant="outlined" name="pitch" onChange={editEvent} helperText={`${event.pitch.length}/150`} inputProps={{
                                        maxlength: 150
                                    }} dir="auto" />
                            </div>
                            <div className="row">
                                <div className="form-group my-4 col-md-3">
                                    <InputLabel>Price</InputLabel>
                                    <TextField fullWidth color="primary" name="price" onChange={editEvent}
                                        value={event && event.price} variant="outlined" type="number"
                                        InputProps={{
                                            startAdornment: <InputAdornment position="start">$</InputAdornment>,
                                        }} placeholder="USD" />
                                </div>
                                <div className="form-group my-4 col-md-9">
                                    <InputLabel>Buy Ticket Link</InputLabel>
                                    <TextField fullWidth placeholder="Ticket Link" type="url" color="primary" value={event && event.link}
                                        variant="outlined" name="link" onChange={editEvent} />
                                </div>
                            </div>
                            <div className="form-group my-4">
                                <InputLabel>Description</InputLabel>
                                <TextField fullWidth multiline placeholder="Description" color="primary" value={event && event.desc}
                                    variant="outlined" name="desc" onChange={editEvent} dir="auto" />
                            </div>
                            <div className="form-group my-4">
                                <InputLabel>Upload Main Image</InputLabel>
                                <Button
                                    style={styles.input}
                                    variant="outlined"
                                    color="primary"
                                    component="label"
                                >
                                    <BsImages />&nbsp;Upload Image
                                    <input
                                        formEncType="multipart/form-data"
                                        type="file"
                                        hidden
                                        accept="image/*,gif/*"
                                        onChange={async (e) => {
                                            if (e.target.files[0]) {
                                                var { name, type, size } = e.target.files[0]
                                                if (size > 5242880) {
                                                    setSizeMsg(true)
                                                }
                                                else {
                                                    setSizeMsg(false)
                                                    var data = await convertBase64(e.target.files[0])
                                                    var imgs = {
                                                        data,
                                                        originalname: name,
                                                        mimetype: type
                                                    }
                                                    setEvent({ ...event, imgs })
                                                }
                                            }
                                        }}
                                    />
                                </Button>
                                {(sizeMsg) ?
                                    <div>
                                        <small className="col-12 text-danger" >Maximum file size: 5MB</small>
                                    </div> : ''
                                }

                                {representImage}
                            </div>
                        </>
                    }
                    <Collapse className="mb-5" in={alert.open}>
                        <Alert severity={alert.serverity} action={
                            <IconButton aria-label="close" color="inherit" size="small"
                                onClick={() => setAlert({ ...alert, open: !alert.open })}>
                                <CloseIcon fontSize="inherit" />
                            </IconButton>
                        }>
                            <AlertTitle>{alert.title}</AlertTitle>
                            {alert.message}
                        </Alert>
                    </Collapse>
                    <Divider flexItem={alert.open} />
                    {!form.submitted &&
                        <Button variant="outlined" type="submit" color="primary" className="my-3" onClick={submit}>Submit</Button>
                    }
                    {form.submitted &&
                        <Button type="button" className="my-3" variant="outlined" color="primary" onClick={() => {
                            history.push('/events')
                        }}>Return</Button>
                    }
                </section>
            </div>
        </div>
    )
}