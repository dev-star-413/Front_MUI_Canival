

export default function OfficialEvents() {
    const more = [
        {
            title: "[Year] [Costume Bands, MIA]",
            target: "#",
        },
        {
            title: "[Band Name, MIA]  Results",
            target: "#",
        },
        {
            title: "[Year] [Carnival Name] Official Events",
            target: "#",
        },
        {
            title: "[Year] [Carnival Name] Events + Fetes, etc.",
            target: "#",
        },
        {
            title: "[Year] [Carnival Name] Things to do",
            target: "#",
        },
        {
            title: "[Year] [Carnival Name] Guides and Reviews",
            target: "#",
        },
        {
            title: "Things Travelers should know for [Year] [Carnival Name]",
            target: "#",
        },
        {
            title: "[Carnival Name] History",
            target: "#",
        },
    ]

    return (
        <div className="container">
            <h2 className="font-weight-bold text-dark">[Year] [Carnival Name] Official Events</h2>
            <ul className="list-group list-group-flush">
                <li className="list-group-item"><b className="subtitleText">EVENT NAME $10USD</b> @ Venue Name (MIA)|10:00 AM <span className="badge bg-primary">Buy Tix</span></li>
                <li className="list-group-item"><b className="subtitleText">EVENT NAME $10USD</b> @ Venue Name (MIA)|10:00 AM <span className="badge bg-primary">Buy Tix</span></li>
            </ul>
            <MoreSection items={more} />
        </div>
    )
}