import { useEffect, useState } from "react";
import { getEvents } from "../../functions/api";
import { Link } from "react-router-dom";
import { Button, Select, MenuItem, FormControl, InputLabel,Checkbox } from "@material-ui/core";
import { animateScroll as scroll } from 'react-scroll';
import { useHistory } from "react-router-dom";
export default function Events() {
  const [allEvents, setAllEvents] = useState([]);
  const [events, setEvents] = useState([]);
  const [eventTypes, setEventTypes] = useState([]);
  const [carnivals, setCarnivals] = useState(null);
  const [carFilter, setCarFilter] = useState(0);
  const [filterTypes,setFilterTypes]=useState([])
  const [filterTag,setFilterTag]=useState([])
  const history=useHistory()
  useEffect(function () {
    loadEvents();
    scroll.scrollToTop();
  }, []);

  const loadEvents = async () => {
    const data = await getEvents();
    let params = new URLSearchParams(window.location.search);
    setFilterTag(params.get('tag'))
    setCarFilter(params.get('filter'))
    var types=params.get('types')
    if(types) types= types.split(',')
    setFilterTypes(types || [])
    if (data && data.events) {
      setEvents(filterByQuery(data.events,'tag','filter','types'))
      setAllEvents(data &&  data.events);
      setCarnivals(data &&  data.carnivals);
      setEventTypes(data && data.eventTypes)
    }
  }
  const filter=(data)=>{
    return function (key,value){
      var newData=data.filter((ev)=>{
        var field=ev[key]
        if(Array.isArray(field))
        {
          if(key=='types'){
            if(Array.isArray(value)){
              return value.every((type)=>{
                if(field && field[0]) return field.includes(type)
              })
            }
          }
          else{
            return field.find((val)=>{
              if(key==='tags') return val.slug==value
              return val==value
            })
          }
        }
        else return value==field
      })
      return newData
    }
  }
  const filterByQuery=(data,...arr)=>{
    let params = new URLSearchParams(window.location.search);
    for(let key of arr){
      var value=params.get(key)
      if(value){
        if(key=='types')value=value.split(',')
        data=filter(data)((key=='filter')?'dId':key,value)
      }
    }
    return data
  }
  const gererateSearchQuery=(key,value)=>{
    let params = new URLSearchParams(window.location.search);
    var tag=params.get('tag')
    var filter=params.get('filter')
    var types=params.get('types')
    var query=''
    if(key=="types"){ 
      value=value.join()
      query=((tag)?'tag='+tag+'&':"")+((filter)?"filter="+filter+'&':"")+((value)?"types="+value:"")
    }
    if(key=='filter')query=((tag)?'tag='+tag+'&':"")+((value)?"filter="+value+'&':"")+((types)?"types="+types:"")
    return query
  }

  const filterEvents = async (actionEv) => {
    const filterValue = actionEv.target.value;
    setCarFilter(filterValue)
    var data=filterByQuery(allEvents,'tag','types')
    if(filterValue)
      data=filter(data)('dId',filterValue)
    setEvents(data)
    var searchQuery=gererateSearchQuery('filter',filterValue)
    history.push({
      search:searchQuery
    })
  }

  const filterByType=async (ev,check)=>{
    var type=ev.target.value
    var newFilters=filterTypes
    // var data=allEvents
    if(!Array.isArray(newFilters)) newFilters=[newFilters]
    if(check) {
      newFilters.push(type)
      setFilterTypes(newFilters)
    }
    if(!check){
      newFilters=newFilters.filter((f)=>f!=type)
      setFilterTypes(newFilters)
    }
    var data=filterByQuery(allEvents,'tag','filter')
    data=filter(data)('types',newFilters)
    setEvents(data)

    var searchQuery=gererateSearchQuery('types',newFilters)
    history.push({
      search:searchQuery
    })
  }

  return (
    <div className="container">
      <h1 className="my-4 font-weight-bold">Carnival Events and Fetes</h1>
      <div className="d-flex justify-content-between">
        {carnivals && Array.isArray(carnivals) &&
          <FormControl >
            <InputLabel htmlFor="age-nat  ive-simple">Filter Festivals</InputLabel>
            <Select value={carFilter} onChange={filterEvents} style={{ minWidth: "140px" }}>
              <MenuItem value={0}>No filter</MenuItem>
              {carnivals.map(item => <MenuItem key={item._id} selected={(item._id==carFilter)?true:false} value={item._id}>{item.festival && item.festival.name} - {item.year}</MenuItem>)}
            </Select>
          </FormControl>
        }

        <Link to="/event/form">
          <Button className="my-3" variant="outlined" color="primary">Add Event - Free</Button>
        </Link>
      </div>
      <div className="d-flex justify-content-between ">
      {eventTypes && Array.isArray(eventTypes) && eventTypes.map((ty)=>{
        return(
          <div className="d-flex px-2 align-items-center " key={ty}>
          <Checkbox key={ty} value={ty} defaultChecked={(filterTypes && filterTypes[0] && filterTypes.includes(ty))?true:false} onChange={filterByType} id={ty.replaceAll(' ','_')}></Checkbox>
          {ty}
          </div>
        )
        }) }
      </div>
      <ul className="list-group list-group-flush">
        {events && Array.isArray(events) && events.map(event => (
          <li key={event._id} className="px-0 list-group-item d-flex justify-content-between text-capitalize">
            <Link to={`/events/${event.slug}`}>
              <h4 className="titleText font-weight-bold mb-0">{event.name}{event.price && ` - $${event.price}USD`}</h4>
              <b>{event.sDate}{event.vName && ` @ ${event.vName}`}{event.city && ` - ${event.city.name}`}</b>
            </Link>
            <div>
              {event.link && <a href={event.link} className="btn btn-primary btn-sm">Buy Tix</a>}
            </div>
          </li>
        ))}
      </ul>
    </div>
  )
}