import React,{ useEffect,useState } from "react"
import { bandsCompare } from "../../functions/api"
import Dialog from '@material-ui/core/Dialog';
import DialogActions from '@material-ui/core/DialogActions';
import DialogContent from '@material-ui/core/DialogContent';
import DialogTitle from '@material-ui/core/DialogTitle';
import {Select ,MenuItem,InputLabel,FormControl } from "@material-ui/core"
import generateAddressImg from '../../functions/generateAddressImg'
// import InputLabel from '@material-ui/core/InputLabel';
import "@fortawesome/fontawesome-free/css/all.css"
import ordinal from "ordinal";
import "./compare.css"
import { Button } from "@material-ui/core";
const Advertisement = React.lazy(()=>import ("../../components/Advertisement.js"))
export default function CostumeBandCompare(props){
    const [bands,setBands]=useState(null) // compare bands
    const [open,setOpen]=useState(false)
    const [carnivals,setCarnivals]=useState(null) // carnival is festival date
    const [sections,setSections]=useState(null)
    const [allBands,setAllBands]=useState(null)
    const [allYears,setYears]=useState(null)
    const [optionCarnivals,setOptionCarnivals]=useState(null)
    const [optionSections,setOptionSections]=useState(null)
    const [optionBands,setOptionBands]=useState(null)
    const [selectBand,setSelectBand]=useState()
    const [selectSection,setSelectSection]=useState()
    const [services,setServices]=useState([])
    const [jouvertServices,setJouvertServices]=useState([])
    const [childrenServices,setChildrenServices]=useState([])

    useEffect(async ()=>{
        var {firstSlug,secondSlug,third,fourth}=props.match.params
        await refresh(firstSlug,secondSlug,third,fourth)
    },[props])

    async function refresh(first, second, third, forth) {
        let arraySlugs=[]
        if(first) arraySlugs.push(first)
        if(second) arraySlugs.push(second)
        if(third) arraySlugs.push(third)
        if(forth) arraySlugs.push(forth)
        var data=await bandsCompare(arraySlugs)
        var compareBands=data ? data.bands : []
        var allBa=data ? data.allBands : []
        var allSec=data ? data.sections : []
        var allFes=data ? data.carnivals : []
        var allServices=data ? data.services : {}
        var years=new Set()
        var costumeServices= []
        var jouvertServices= []
        var childrenServices= []
        if(allFes){
            allFes.map((fes)=>{
                years.add(fes.year)
            })
        }
        if(allServices && allServices._id){
            costumeServices= allServices ? allServices.services : []
            jouvertServices=allServices.jouvertServices
            childrenServices=allServices.childrenServices
        }
        else allServices=[]
        setYears(Array.from(years))
        setCarnivals(allFes)
        setSections(allSec)
        setAllBands(allBa)
        setBands(compareBands)
        setServices(costumeServices)
        setJouvertServices(jouvertServices)
        setChildrenServices(childrenServices)
    }

    const handleClickOpen = () => {
        setOpen(true);
      };
    
    const handleClose = () => {
    setOpen(false);
    }
    return (
        <div className="container">
            <div className="d-flex flex-row justify-content-between mt-2">
                <h1>Costume Bands Comparison</h1>
                {(!props.match.params.fourth)?
                <button className="btn btn-sm my-1"onClick={handleClickOpen} id="buttonAddCompare"
                style={{backgroundColor:" #e69900"}}><b>+</b> Add to compare</button>
                :""}
            </div>
            {compareModal()}
            <div className="table-responsive mt-2">
                {makeTable()}
            </div>
        </div>
    )
    function compareModal(){
        var OptionYears=[]
        var tempOptionCarnivals=[]
        if(allYears && allYears[0]){
          for(let year of allYears) {
            OptionYears.push(
              <MenuItem value={year}>{year}</MenuItem>
            )
          }
        }
        function changeYear(ev){
            var year=ev.target.value
            tempOptionCarnivals=[]
            if(carnivals && carnivals[0]){
                carnivals.map((car)=>{
                    if(car.year==year){
                        tempOptionCarnivals.push(
                            <MenuItem key={car._id} value={car._id}>{car.festival && car.festival.name}</MenuItem>
                        )
                    }
                })
            }
            setOptionCarnivals(tempOptionCarnivals)
            setOptionSections([])
            setOptionBands([])
        }
        function changeCarnival(ev){
            var dId=ev.target.value
            var tempOptionBands=[]
            var sample=bands ? bands[0] : {}
            if(allBands && allBands[0]){
                allBands.map((band)=>{
                    if(band.dateId==dId){
                        if(
                            (band.isCustomeService === sample.isCustomeService)|| 
                            (band.isJouvertService===sample.isJouvertService) ||
                            (!sample ||!sample._id)){

                            tempOptionBands.push(
                                <MenuItem key={band._id} value={band._id}>{band && band.name}</MenuItem>
                            )
                        }
                    }
                })
            }
            // if(tempOptionBands.length==0) tempOptionBands.push( <MenuItem value={0}>none</MenuItem>)
            setOptionBands(tempOptionBands)
        }
        function changeBand(ev){
            var bandId=ev.target.value
            if(allBands && allBands[0]){
                allBands.map((band)=>{
                    if(band._id==bandId)setSelectBand(band)
                })
            } 
            var tempSections=[]
            if(sections && sections[0]){
                sections.map((section)=>{
                    if(section.bdId==bandId){
                        tempSections.push(
                            <MenuItem key={section._id} value={section._id}>{section && section.name}</MenuItem>
                        )
                    }
                })
            }
            if(tempSections.length==0) tempSections.push( <MenuItem value={0}>none</MenuItem>)
            setOptionSections(tempSections)
        }
        function changeSection(ev){
            var secId=ev.target.value
            if(sections && sections[0]){
                sections.map((sec)=>{
                    if(sec._id==secId) setSelectSection(sec)
                })
            }
        }
        async function submitCompare(ev) {
                ev.preventDefault()
                var {third,fourth}=props.match.params
                var newSlug=selectBand.slug
                if(selectSection && selectSection!=0){
                    newSlug+="~"+selectSection._id
                 }
                if(!third) {
                    props.history.push(`${window.location.pathname}/${newSlug}${window.location.search}`)
                }
                else if(!fourth) {
                    props.history.push(`${window.location.pathname}/${newSlug}${window.location.search}`)
                }
                setOpen(false)
        }
        return(
            <Dialog id="modalAddCompare" fullWidth={true} maxWidth="sm"  open={open} onClose={handleClose}>
                <form onSubmit={submitCompare}>
                    <DialogTitle>Compare Costumes</DialogTitle>
                    <DialogContent>
                        <div className="container">
                            <div className="row">
                                {/* <div className="col-sm-6 col"> */}
                                    <div className="col-12 py-2">
                                        <FormControl className="col-sm-12">
                                        <InputLabel id="select-year-label">Select Year</InputLabel>
                                        <Select id="selector-compare-year" labelId="select-year-label" name="year" onChange={changeYear} required>
                                            {OptionYears}
                                        </Select>
                                        </FormControl>
                                    </div>
                                    <div className="col-12 py-2">
                                        <FormControl className="col-sm-12">
                                        <InputLabel id="select-carnival-label">Select Carnival</InputLabel>
                                        <Select id="selector-carnival-band" labelId="select-carnival-label" name="carnival" onChange={changeCarnival} required>
                                            {optionCarnivals}
                                        </Select>
                                        </FormControl>
                                    </div>
                                {/* </div>
                                <div className="col-sm-6"> */}
                                    <div className="col-12 py-2">
                                        <FormControl className="col-sm-12">
                                        <InputLabel id="select-band-label">Select Band</InputLabel>
                                        <Select id="selector-compare-band" labelId="select-band-label" name="band" onChange={changeBand} required>
                                            {optionBands}
                                        </Select>
                                        </FormControl>
                                    </div>
                                    <div className="col-12 py-2">
                                        <FormControl className="col-sm-12">
                                        <InputLabel id="select-section-label">Select Section</InputLabel>
                                        <Select id="selector-compare-section" labelId="select-section-label" name="section" onChange={changeSection}>
                                            {optionSections}
                                        </Select>
                                        </FormControl>
                                    </div>
                                {/* </div> */}
                            </div>
                            <div>
                                {/* <Advertisement/> */}
                            </div>
                        </div>
                    </DialogContent>
                    <DialogActions>
                        <Button className="btn" type="submit"  style={{backgroundColor:" #e69900"}}>compare</Button>
                    </DialogActions>
                </form>
            </Dialog>
        )
    }
   
    function makeTable(){
        var colspan=1
        // if(!bands || !bands[0]) return 
        if (bands && bands[0]) colspan=bands.length
        return(
                    <table className="table table-bordered ">
                        <thead >
                        </thead>
                        <tbody >
                        <tr><th className="text-center fieldRow" colSpan={colspan}><span>BAND NAME/CARNIVAL</span></th></tr>
                        {rowData('carnival')}
                        {rowData('mainImg')}
                        {/* <tr><th className="text-center fieldRow" colSpan={colspan}>ADS</th></tr> */}
                        <tr><th className="text-center fieldRow" colSpan={colspan}><span>THEME</span></th></tr>
                        {rowData('theme')}
                        <tr><th className="text-center fieldRow" colSpan={colspan}><span>SECTION</span></th></tr>
                        {rowData('section')}
                        <tr><th className="text-center fieldRow" colSpan={colspan}><span>POWERED BY</span></th></tr>
                        {rowData('name')}
                        <tr><th className="text-center fieldRow" colSpan={colspan}><span>DESIGNED BY</span></th></tr>
                        {rowData('designer')}
                        <tr><th className="text-center fieldRow" colSpan={colspan}><span>HOTNESS -THE DESIGN</span></th></tr>
                        {rowData('average')}
                        <tr><th className="text-center fieldRow" colSpan={colspan}><span>LAUNCH DATE</span></th></tr>
                        {rowData('lDate')}
                        <tr><th className="text-center fieldRow" colSpan={colspan}><span>REGISTRATION DEADLINE/DEPOSIT</span></th></tr>
                        {rowData('rdDate-deposit')}
                        <tr><th className="text-center fieldRow" colSpan={colspan}><span>AVAILABLE LINE(S)/PRICING </span></th></tr>
                        {rowData('lines')}
                        <tr><th className="text-center fieldRow" colSpan={colspan}><span>COLORS</span></th></tr>
                        {rowData('colors')}
                        <tr><th className="text-center fieldRow" colSpan={colspan}><span>STYLE/FIT</span></th></tr>
                        {rowData('styles')}
                        <tr><th className="text-center fieldRow" colSpan={colspan}><span>BAND SERVICES WITH COSTUME</span></th></tr>
                        {rowData('services')}
                        <tr><th className="text-center fieldRow" colSpan={colspan}><span>AVAILABLE ADD ONs/UPGRADES</span></th></tr>
                        {rowData('addOns')}
                        <tr><th className="text-center fieldRow" colSpan={colspan}><span>EVENT(S)</span></th></tr>
                        {rowData('events')}
                        <tr><th className="text-center fieldRow" colSpan={colspan}><span>AWARDS</span></th></tr>
                        {rowData('awards')}
                        <tr><th className="text-center fieldRow" colSpan={colspan}><span>BAND SCORE CARD <a className="btn btn-warning btn-sm" href="/how-are-costume-band-score" >How?</a></span></th></tr>
                        {rowData('scoreBands')}
                        </tbody>
                    </table>
        )
    }
    function dollarSigns (min, max, price) {
        if (max > min) {
            let output = [];
            const signCount = 4;
            const diff = max - min;
            const scope = diff / signCount;
            const enableSignsCount = Math.round((price - min) / scope);
            for (let i = 0; i < enableSignsCount; i++) {
                output.push(<span><b>$</b></span>)
            }
            for (let i = enableSignsCount; i < signCount; i++) {
                output.push(<span className="text-secondary">$</span>)
            }
            return output;
        }
        return <span><b>$$$$</b></span>;
    }

    function rowData(field){
        var column='col-sm-6'
        if (bands && bands.length==3) column='col-sm-4'
        if (bands && bands.length==4) column='col-sm-3'
        var cell=[]
        if(bands && bands[0]){
            switch(field){
                case "carnival":
                    for(let b in bands){
                        let band=bands[b]
                        cell.push(
                            <td key={band._id+b+field}>
                                <div className="d-flex flex-row justify-content-between">
                                    <span>{band.name}</span>
                                    <span  onClick={removeBand}>
                                        <i id={b} className="btn fa fa-times text-danger"></i>
                                    </span>
                                </div>
                                <div>
                                    <span>{band && band.festivalName} {band && band.year}</span>
                                </div>
                            </td>
                        )
                    };break
                    case "average":
                    for(let b in bands){
                        let band=bands[b]
                        cell.push(
                            <td key={band._id+b+field}>
                                <div>
                                    <span className="mr-2"><i className="fa fa-fire fa-lg" style={{color:'rgb(255, 100, 0)'}}></i></span>
                                    <span>
                                        {(band.section && band.section.average)?band.section.average:band && band.average  }
                                    </span>
                                </div>
                            </td>
                        )
                    };break
                case "theme":
                    for(let b in bands){
                        let band=bands[b]
                        cell.push(
                            <td key={band._id+b+field}>{band['theme']}</td>
                        )
                    };break
                case 'mainImg':
                    for(let b in bands){
                        let url=bands[b].mainImg && bands[b].mainImg.path
                        if(bands[b] && bands[b].section){
                            url=bands[b].section && bands[b].section.img &&  bands[b].section.img.path
                        }
                        cell.push(
                            <td key={bands[b]._id+b+field} >
                                <img src={generateAddressImg(url,560,315)} className="img-fluid"/>
                                {/* <div className="mx-auto" style={{maxHeight:"200px",maxWidth:'300px', backgroundImage: `url(${url})`,
                                    backgroundSize: 'contain',backgroundRepeat:"no-repeat",
                                    backgroundPosition:'center',height:'50vh',
                                }}></div> */}
                            </td>
                        )
                    };break
                case "rdDate-deposit":
                    for(let b in bands){
                        let band=bands[b]
                        cell.push(
                            <td key={b+field}>{band['rdDate']} / {band['deposit']?'$'+band['deposit']+" USD":""} </td>
                        )
                    };break
                case "lines":
                    for(let b in bands){
                        let lines=bands[b].lines || []
                        let content=[]
                        var min=0
                        var max=0
                        if(lines && lines[0]){
                            min = Math.min.apply(Math, lines.map(function(val) { return parseInt( val.minPrice) }));
                            max = Math.max.apply(Math, lines.map(function(val) { return  parseInt( val.minPrice) }));
                        }
                        for(let line of lines){
                             // have to be link section page
                            if(line && line.type){
                                let doller=dollarSigns(min,max,line.minPrice)
                                content.push(
                                    <div className="col-12" key={line && line._id}>
                             
                                        <span>{line && line.type} 
                                         / {doller}
                                        &ensp;
                                        {line ? line.minPrice : 0}+ USD</span>
                                    </div>
                                )
                            }
                        }
                        cell.push(
                            <td key={bands[b]._id+b+field}>
                                {content}
                            </td>
                        )
                    };break
                case "section":
                    for(let b in bands){
                        let section=bands[b].section || {}
                        let href=''
                        let slug=bands[b] && bands[b].slug
                        if(slug)
                        href='/bands/'+slug
                        cell.push(
                            <td key={section._id}>
                                <a href={href}>
                                    {section && section.name}
                                </a>
                            </td>
                        )
                    };break
                case "styles":
                    for(let b in bands){
                        let lines=bands[b].lines || []
                        let content=[]
                        for(let line of lines){
                            var styles=line.styles || []
                            if(!Array.isArray(styles)) styles=Array(styles)
                            for(let s of styles){
                                content.push(
                                    <div key={line._id+s} className="col-12">
                                        <span >{s}</span>
                                    </div>
                                )
                            }
                        }
                        cell.push(
                            <td key={bands[b]._id+b+field}>
                                {content}
                            </td>
                        )
                    };break
                case "colors":
                    for(let b in bands){
                        let section=bands[b].section || []
                        let colors=section.colors || []
                        let content=[]
                        for(let color of colors){
                            content.push(
                                <div className="col-12 row" key={section._id+color}>
                                    <span >{color}</span>
                                    <div className="mx-1"  style={{backgroundColor:`${color}`,width:"20px",height:"20px"}}></div> 
                                </div>
                            )
                        }
                        cell.push(
                            <td key={bands[b]._id+b+field}>
                                {content}
                            </td>
                        )
                    };break
                case "events":
                    for (let b in bands){
                        let events=bands[b].events || []
                        let content=[]
                        if(events[0]){
                            for(let ev of events){
                                let href=''
                                let slug= ev && ev.slug
                                if(slug)
                                href='/events/'+slug
                                // have to be link event page
                                content.push(
                                    <div className="col-12" key={ev._id}>
                                        <a href={href}>
                                            <span >{ev.name} - {ev.sDate}</span>
                                        </a>
                                    </div>
                                )
                            }
                        }
                        cell.push(
                            <td key={bands[b]._id+b+field}>
                                {content}
                            </td>
                        )
                    };break
                    case "awards":
                        for (let b in bands){
                            let awards=bands[b].awards || []
                            let content=[]
                            if(awards[0]){
                                for(let aw of awards){
                                    // have to be link event page
                                    var href=''
                                    let slug=aw && aw.slug
                                    if(slug)
                                    href='/awards/'+slug
                                    if(aw.cats && aw.cats[0]){
                                       for(let cat of aw.cats){
                                           let positions=cat.positions
                                           if(positions && positions[0]){
                                               positions.map(pos=>{
                                                    if(pos.bands && pos.bands[0]){
                                                        if( pos.bands.map(band => band._id).includes(bands[b]._id)){
                                                            let number=parseInt(pos.position) 
                                                            content.push(
                                                                <div className="col-12 "key={aw._id+''+pos.position}>
                                                                    <a href={href} >{ordinal(number)} | {cat.title} at {bands[b].festivalName } {bands[b].year}</a>
                                                                </div>
                                                            )
                                                        }
                                                    }
                                               })   
                                           }    
                                       }
                                    }
                                }
                            }
                            cell.push(
                                <td key={bands[b]._id+b+field}>
                                    {content}
                                </td>
                            )
                        };break
                    case "addOns":
                        for(let b in bands){
                            let lines=bands[b].lines || []
                            let content=[]
                            for(let line of lines){
                                let gallery=line.gallery || []
                                const isAddOn= (index)=>index.isAddOn==true
                                if(gallery.some(isAddOn)){
                                    content.push(
                                        <div className="col-12" key={line._id}>
                                            <span >yes</span>
                                        </div>
                                    )
                                }
                            }
                            cell.push(
                                <td key={bands[b]._id+b+field}>
                                    {content}
                                </td>
                            )
                        };break
                    case "services":
                        for(let b in bands){
                            let Bandservices=[]
                            Bandservices=bands[b].services || []
                            let content=[]
                            var all= services ? services.length : 0
                            var length =Bandservices ? Bandservices.length : 0
                            if(services && services[0]){
                                var hasCostume=bands[b].isCustomeService || false
                                for(let ser of services){
                                    console.log(b)
                                let exist=Bandservices.includes(ser)
                                var icon=(exist && hasCostume)?
                                        <i className='fa fa-check text-success   mx-1'></i>:
                                        <i className='fa fa-times text-danger  mx-1'></i>
                                    content.push(
                                        <div className="col-12" key={bands[b]._id+b+ser}>
                                            <span>{icon}{ser}</span>
                                        </div>
                                    )
                                }
                            }
                            var jouvertContent=[]
                            var bandJouvertServices=bands[b].jouvertServices || []
                            var jLength=bandJouvertServices ? bandJouvertServices.length : 0
                            var allJouvertLength=jouvertServices ? jouvertServices.length : 0
                            if(jouvertServices && jouvertServices[0]){
                                var hasJouvert=bands[b].isJouvertService || false
                                for(let jSer of jouvertServices){
                                    let include=bandJouvertServices.includes(jSer)
                                    let jIcon = (include && hasJouvert)?
                                        <i className='fa fa-check text-success   mx-1'></i> :
                                        <i className='fa fa-times text-danger  mx-1'></i>
                                        jouvertContent.push(
                                            <div className="col-12" key={jSer}>
                                                <span>{jIcon}{jSer}</span>
                                            </div>
                                        )
                                }
                            }
                            var childrenContent=[]
                            var bandChildrenServices=bands[b].childrenServices || []
                            var cLength=bandChildrenServices ? bandChildrenServices.length : 0
                            var allChildrenLength=childrenServices ? childrenServices.length : 0
                            if(childrenServices && childrenServices[0]){
                                var hasChildren=bands[b].isChildrenService || false
                                for(let cSer of childrenServices){
                                    let include=bandChildrenServices.includes(cSer)
                                    let cIcon = (include && hasChildren)?
                                        <i className='fa fa-check text-success   mx-1'></i> :
                                        <i className='fa fa-times text-danger  mx-1'></i>
                                    childrenContent.push(
                                        <div className="col-12" key={cSer}>
                                            <span>{cIcon}{cSer}</span>
                                        </div>
                                    )
                                }
                            }
                            cell.push(
                                <td key={bands[b]+b+field}>
                                    {bands[b].isCustomeService ?
                                        <div className="col-12 my-3">
                                            <h5>Adult Services</h5>
                                            <progress  id="progress" value={length} max={all}></progress> {length} / {all}
                                            {content}
                                        </div>
                                        : ''
                                    }
                                    {bands[b].isJouvertService ?
                                        <div className="col-12 my-3">
                                            <h5>Jouvert Services</h5>
                                            <progress  id="progress" value={jLength} max={allJouvertLength}></progress> {jLength} / {allJouvertLength}
                                            {jouvertContent}
                                        </div>
                                        : ''
                                    }
                                    {bands[b].isChildrenService ?
                                        <div className="col-12 my-3">
                                            <h5>Children Services</h5>
                                            <progress  id="progress" value={cLength} max={allChildrenLength}></progress> {cLength} / {allChildrenLength}
                                            {childrenContent}
                                        </div>
                                        : ''
                                    }
                                </td>
                            )
                        };break
                    case "scoreBands":
                        for(let b in bands){
                            let content=[]
                            let band=bands[b]
                            let scoreBands=band.scoreBands || []
                            if(scoreBands && scoreBands[0]){
                                scoreBands.map(function(x){
                                    if(!x.score || x.score ==0){
                                        content.push(
                                            <div className="col-12 " key={x._id} >
                                                <span>{x.year}/&nbsp;[N/A]</span>
                                            </div>
                                        )
                                    }else{
                                        content.push(
                                            <div className="col-12 " key={x._id} >
                                                <span>{x.year}/&nbsp;{x.score}/10</span>
                                            </div>
                                        )
                                    }
                                })
                            }
                            cell.push(<td>{content}</td> )
                        };break;
                    case "designer":
                        for(let b of bands){
                            let content=[] 
                            let designers=b.designers || []
                            for(let d of designers){
                                let href="#"
                                if(d && d.slug){
                                    let slug=d.slug
                                    href='/designers/'+slug
                                }
                                content.push(
                                    <div className='col-12' key={(d)? d._id || d.id  : 0}>
                                        <a href={href}>{d && d.name}</a>
                                    </div>
                                )
                            }
                            cell.push(<td>{content}</td> )
                        };break;
                    case 'name':
                        for(let b in bands){
                            let band=bands[b]
                            let slug=band.slug
                            let href;
                            if(slug) href='/bands/'+slug
                            cell.push(
                                <td key={bands[b]._id+b+field}>
                                    <a href={href}>
                                        {band['name']}
                                    </a>
                                </td>
                            )
                        }
                        break;

                default:
                    for(let b in bands){
                        let band=bands[b]
                        cell.push(
                            <td key={bands[b]._id+b+field}>{band[field]}</td>
                        )
                    }

            }
        }
        let row=<tr className={column}>{cell}</tr>
        return row
    }

    function removeBand(ev) {
        var numberSlug=ev.target.id
        var {firstSlug,secondSlug,third,fourth}=props.match.params
        var path=''
        if(numberSlug==0){
            if(secondSlug) path+="/"+secondSlug 
            if(third) path+="/"+third 
            if(fourth) path+="/"+fourth 
        }
        else if(numberSlug==1){
            if(firstSlug) path+="/"+firstSlug 
            if(third) path+="/"+third 
            if(fourth) path+="/"+fourth 
        }
        else if(numberSlug==2){
            if(firstSlug) path+="/"+firstSlug 
            if(secondSlug) path+="/"+secondSlug 
            if(fourth) path+="/"+fourth 
        }
        else if(numberSlug==3){
            if(firstSlug) path+="/"+firstSlug 
            if(secondSlug) path+="/"+secondSlug 
            if(third) path+="/"+third 
        }
        props.history.replace(`/bands/compare${path}${window.location.search}`)
    }
}
