import { makeStyles } from '@material-ui/core/styles';
import PropTypes from 'prop-types';
import {
    AppBar, Tabs, Tab, Typography, Box, IconButton
} from "@material-ui/core";
import { useState } from "react";
import SectionForm from './SectionForm';
import { BsPlus } from "react-icons/all";

export default function SectionTabs({
    designers, sectionTypes, lineTypes, dynamics, bands,
    editSection, editLine, sections, addSection, addLine
}) {
    const [value, setValue] = useState(0);
    const classes = useStyles();
    const handleChange = (event, newValue) => {
        event.preventDefault();
        setValue(newValue);
    };

    return (
        <div className={classes.root}>
            <AppBar position="static" color="default">
                <Tabs
                    value={value}
                    onChange={handleChange}
                    indicatorColor="primary"
                    textColor="primary"
                    variant="scrollable"
                    scrollButtons="auto"
                    aria-label="scrollable auto tabs example"
                >
                    {sections.map((section, index) => (
                        <Tab label={section.name || `Section ${index + 1}`} {...a11yProps(index)} />
                    ))}
                    <IconButton className="my-2 ml-auto" variant="outlined" color="primary" onClick={addSection}><BsPlus /></IconButton>
                </Tabs>
            </AppBar>
            {sections.map((section, index) => (
                <TabPanel value={value} index={index}>
                    <SectionForm
                        section={section}
                        editSection={editSection}
                        editLine={editLine}
                        addLine={addLine}
                        designers={designers}
                        bands={bands}
                        dynamics={dynamics}
                        sectionTypes={sectionTypes}
                        lineTypes={lineTypes}
                        index={index}
                    />
                </TabPanel>
            ))}
        </div>
    )
}

function TabPanel(props) {
    const { children, value, index, ...other } = props;

    return (
        <div
            style={{ backgroundColor: 'rgba(251, 251, 251, 1)' }}
            role="tabpanel"
            hidden={value !== index}
            id={`scrollable-auto-tabpanel-${index}`}
            aria-labelledby={`scrollable-auto-tab-${index}`}
            {...other}
        >
            {value === index && (
                <Box p={3}>
                    <Typography>{children}</Typography>
                </Box>
            )}
        </div>
    );
}

TabPanel.propTypes = {
    children: PropTypes.node,
    index: PropTypes.any.isRequired,
    value: PropTypes.any.isRequired,
};

function a11yProps(index) {
    return {
        id: `scrollable-auto-tab-${index}`,
        'aria-controls': `scrollable-auto-tabpanel-${index}`,
    };
}

const useStyles = makeStyles((theme) => ({
    root: {
        flexGrow: 1,
        width: '100%',
        backgroundColor: theme.palette.background.paper,
    },
}));