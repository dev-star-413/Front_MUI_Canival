import RateSection from "../../components/Festival/RateSection";
import { MenuItem, Button, Radio, RadioGroup, FormControlLabel, FormControl, FormLabel, Select, InputLabel, Checkbox } from "@material-ui/core";
import { useEffect, useState } from "react";
import { getCostumeBandsByYear, getFilterData } from "../../functions/api";
import { Link } from "react-router-dom";
import generateAddressImg from "../../functions/generateAddressImg"
import { LazyLoadImage } from 'react-lazy-load-image-component';

export default function BandDates() {
    const [bands, setBands] = useState();
    const [params, setParams] = useState(null);
    const [state, setState] = useState({
        sections: [],
        high: false,
        low: false,
        hotness: false,
        az: true,
        filter: 'high',

    });
    const [form, setForm] = useState({
        year: 0,
        band: '',
        carnival: '',
        sections: [],
    });
    const [open, setOpen] = useState(false);
    useEffect(function () {
        loadData();
    }, [bands]);

    const loadData = async () => {
        if (!bands) {
            setBands(await getCostumeBandsByYear(form));
            sortData(state.filter);
        }
        if (!params) {
            setParams(await getFilterData('band'));
        }
    }
    const handleChange = (event) => {
        setState({ ...state, filter: event.target.value });
        sortData(event.target.value);
    };

    const handleOpen = () => {
        setOpen(!open);
    }

    function sortData(filter) {
        if (bands) {
            let temp = [];
            switch (filter) {
                case "high":
                    // prices high to low
                    temp = bands.sort(function (a, b) {
                        if (a.deposit < b.deposit) { return 1; }
                        if (a.deposit > b.deposit) { return -1; }
                        return 0;
                    });
                    break;
                case "low":
                    // prices low to high
                    temp = bands.sort(function (a, b) {
                        if (a.deposit < b.deposit) { return -1; }
                        if (a.deposit > b.deposit) { return 1; }
                        return 0;
                    });
                    break;
                case "az":
                    // sort bands alphabetically
                    temp = bands.sort(function (a, b) {
                        if (a.name < b.name) { return -1; }
                        if (a.name > b.name) { return 1; }
                        return 0;
                    });
                    break;
                case "hotness":
                    // sort bands by sections hotness
                    temp = bands.sort(function (a, b) {
                        if (a.hotness < b.hotness) { return 1; }
                        if (a.hotness > b.hotness) { return -1; }
                        return 0;
                    });
                    break;
                default:
                    break;
            }
            setBands(temp);
        }
    }

    function editForm(e) {
        setForm({ ...form, [e.target.name]: e.target.value });
    }

    function handleCheckboxes(e) {
        const index = Array.isArray(form.sections) ? form.sections.indexOf(e.target.value) : -1;
        if (index > -1) {
            let temp = form.sections;
            temp.splice(index, 1);
            setForm({ ...form, sections: temp })
        } else {
            setForm({ ...form, sections: [...form.sections, e.target.value] })
        }
    }

    return (
        <div className="container">
            <h1 className="text-dark font-weight-bold py-3">Costumes, Bands and Designs</h1>
            {params &&
                <RateSection
                    sort={
                        <FormControl component="fieldset" className="px-4 pb-3">
                            <ul className="list-group list-group-flush">
                                <li className="list-group-item">
                                    <FormLabel className="pt-3" component="legend">Sort</FormLabel>
                                </li>
                                <li className="list-group-item">
                                    <RadioGroup name="filter" value={state.filter} onChange={handleChange}>
                                        <FormControlLabel value="hotness" control={<Radio color="primary" />} label="Hotness" />
                                        <FormControlLabel value="low" control={<Radio color="primary" />} label="Price - Low to High" />
                                        <FormControlLabel value="high" control={<Radio color="primary" />} label="Price - High to Low" />
                                        <FormControlLabel value="az" control={<Radio color="primary" />} label="A-Z" />
                                    </RadioGroup>
                                </li>
                            </ul>
                        </FormControl>
                    }
                    filter={
                        <div className="px-4 py-4">
                            <h4>Costume Search/Filter</h4>
                            <ul className="list-group list-group-flush">
                                <li className="list-group-item row">
                                    <div className="row">
                                        <div className="col-md-12 form-group">
                                            <InputLabel>Year</InputLabel>
                                            <Select fullWidth name="year" value={form.year} variant="outlined" color="primary" onChange={editForm}>
                                                <MenuItem value="">Choose One...</MenuItem>
                                                {params.years.map(year => <MenuItem value={year}>{year}</MenuItem>)}
                                            </Select>
                                        </div>
                                        <div className="col-md-12 form-group">
                                            <InputLabel>Carnival</InputLabel>
                                            <Select disabled={!form.year} value={form.carnival} fullWidth name="carnival" variant="outlined" color="primary" onChange={editForm}>
                                                <MenuItem value="">Choose One...</MenuItem>
                                                {params.carnivals.filter(carniv => carniv.year === form.year).map(carn => <MenuItem value={carn._id}>{carn.festival.name} - {carn.year}</MenuItem>)}
                                            </Select>
                                        </div>
                                        <div className="col-md-12 form-group">
                                            <InputLabel>Costume Band</InputLabel>
                                            <Select disabled={!form.carnival} value={form.band} fullWidth name="band" variant="outlined" color="primary" onChange={editForm}>
                                                <MenuItem value="">Choose One...</MenuItem>
                                                {params.bands.map(band => <MenuItem value={band._id}>{band.name}</MenuItem>)}
                                            </Select>
                                        </div>
                                        <div className="col-md-12 form-group">
                                            <InputLabel>Section</InputLabel>
                                            <div className="d-flex flex-row align-items-center">
                                                <InputLabel>Mas/Costume</InputLabel>
                                                <Checkbox
                                                    name="Mas/Costume"
                                                    value="Mas/Costume"
                                                    color="primary"
                                                    // checked={Boolean(form.sections.includes("Mas/Costume"))}
                                                    onChangeCapture={handleCheckboxes}
                                                />
                                            </div>
                                            <div className="d-flex flex-row align-items-center">
                                                <InputLabel>J'ouvert</InputLabel>
                                                <Checkbox
                                                    name="J'ouvert"
                                                    value="J'ouvert"
                                                    color="primary"
                                                    // checked={Boolean(form.sections.includes("J'ouvert"))}
                                                    onChangeCapture={handleCheckboxes}
                                                />
                                            </div>
                                            <div className="d-flex flex-row align-items-center">
                                                <InputLabel>Day2/2nd Wear</InputLabel>
                                                <Checkbox
                                                    name="Day2/2nd Wear"
                                                    value="Day2/2nd Wear"
                                                    color="primary"
                                                    // checked={Boolean(form.sections.includes("Day2/2nd Wear"))}
                                                    onChangeCapture={handleCheckboxes}
                                                />
                                            </div>
                                            <div className="d-flex flex-row align-items-center">
                                                <InputLabel>Others</InputLabel>
                                                <Checkbox
                                                    name="Others"
                                                    value="Others"
                                                    color="primary"
                                                    // checked={Boolean(form.sections.includes("Others"))}
                                                    onChangeCapture={handleCheckboxes}
                                                />
                                            </div>
                                        </div>
                                    </div>
                                </li>
                                <li className="list-group-item">
                                    <Button variant="outlined" color="primary" onClick={() => {
                                        setBands(null)
                                        setOpen(false);
                                    }}
                                    >
                                        Submit
                                    </Button>
                                    <Button className="ml-3" variant="outlined" color="secondary" onClick={() => setOpen(false)}>Close</Button>
                                </li>
                            </ul>
                        </div>
                    }
                    open={open}
                    handleOpen={handleOpen}
                />
            }
            <ul className="list-group list-group-flush mt-3">
                {bands && !bands.code && bands[0] && bands.map((section, index) => (
                    <li className="list-group-item" key={index}>
                        <Link className="row" to={`/bands/${section.slug}`}>
                            {section.img &&
                                <div className="col-3">
                                    <LazyLoadImage
                                        src={generateAddressImg(section.img.path,560,315)}
                                        className="img-fluid"
                                    />
                                </div>
                            }
                            <div className="col-9">
                                <h3>
                                    {section.name}
                                </h3>
                                <span className="text-secondary">{section.hotness}&nbsp;<i className="fa fa-fire fa-lg" style={{ color: 'rgb(255, 100, 0)' }}></i>&nbsp;{section.dateName}&nbsp;{section.year}&nbsp;{'>'}&nbsp;{section.bandName}</span>
                            </div>
                        </Link>
                    </li>
                ))}
            </ul>
        </div>
    )
}