import {
    Divider, InputLabel, MenuItem, Select, TextField, Button, InputAdornment, Collapse, IconButton,
} from "@material-ui/core";
import { Alert, AlertTitle } from "@material-ui/lab";
import CloseIcon from '@material-ui/icons/Close';
import { useHistory } from "react-router";
import { useEffect, useState } from "react";
import { animateScroll as scroll } from 'react-scroll';
import { createPost, getFormData } from "../../functions/api";
import SectionTabs from "./SectionTabs";

export default function BandForm() {

    const currentYear = new Date().getFullYear()
    const years = []
    for (let year = currentYear - 1; year < currentYear + 9; year++) {
        years.push(year)
    }
    const history = useHistory()
    const [dynamics, setDynamics] = useState({
        _id: null,
        addOns: [],
        colors: [],
        premiums: [],
        revellers: [],
        services: [],
        styles: [],
        themes: [],
    })
    const [alert, setAlert] = useState({
        serverity: "",
        title: "",
        message: "",
        open: false
    })
    const [designers, setDesigners] = useState(null);
    const [bands, setBands] = useState(null);
    const [sectionTypes, setSectionTypes] = useState(null);
    const [lineTypes, setLineTypes] = useState(null);
    const [festivalDates, setFestivalDates] = useState(null)
    const [pageNumber, setPageNumber] = useState(0)
    const [submitted, setSubmitted] = useState(false);
    // edit bands data
    function editBandForm(event) {
        setBand({ ...band, [event.target.name]: event.target.value })
    }

    // edit sections data
    function editSectionsForm(name, value, sectionIndex) {
        let sectionsTemp = sections;
        sectionsTemp[sectionIndex][name] = value;
        setSections(sectionsTemp);
    }

    // edit lines data
    function editLinesForm(name, value, sectionIndex, lineIndex) {
        let sectionsTemp = sections;
        let lineTemp = sections[sectionIndex].lines[lineIndex];
        lineTemp[name] = value;
        sectionsTemp[sectionIndex].lines[lineIndex] = lineTemp;
        setSections(sectionsTemp);
    }

    // add section
    function addSection() {
        setSections([...sections, rawSectionData])
    }

    // add line
    function addLine(sectionIndex) {
        let sectionsTemp = sections;
        sectionsTemp[sectionIndex].lines.push({
            type: null,
            lDate: null,
            rdDate: null,
            deposit: null,
            desc: null,
            includes: null,
            styles: [],
            link: null,
            sold: null,
            img: null,
            addOns: [],
        });
        setSections(sectionsTemp);
    }

    // redirect user after form submitted
    function redirect() {
        history.push('/bands')
    }

    // send forms data to the api
    async function submit() {
        if (band.bandId && band.dateId && band.year) {
            const res = await createPost('band-temp', { band, sections })
            if (res && res.msg) {
                switch (res.code) {
                    case -1:
                        setAlert({ ...alert, open: true, message: res.msg, serverity: 'error', title: 'Error' });
                        break;
                    case 0:
                        setAlert({ ...alert, open: true, message: res.msg, serverity: 'warning', title: 'Warning' });
                        break;
                    case 1:
                        setAlert({ ...alert, open: true, message: res.msg, serverity: 'success', title: 'Success' });
                        setSubmitted(true);
                        break;
                    default:
                        setAlert({ ...alert, open: false });
                        setBand(rawBandData)
                        setSections([])
                        break;
                }
            } else {
                setAlert({
                    ...alert,
                    open: true,
                    message: "Error occurred while posting your form data to the api. Please try again later.",
                    title: "Error",
                    serverity: 'error'
                });
            }
        } else {
            setAlert({ ...alert, open: true, message: "Some fields have been missed.", title: "Warning", serverity: 'warning' });
        }
        scroll.scrollToTop()
    }

    // get festival names list from API
    useEffect(function () {
        loadData()
    })
    const loadData = async () => {
        if (!festivalDates) {
            const data = await getFormData('band');
            if (data && !data.code) {
                setFestivalDates(data.dates);
                setDynamics(data.dynamics);
                setBands(data.bands);
                setDesigners(data.designers);
                setSectionTypes(data.sectionTypes);
                setLineTypes(data.lineTypes);
            }
        }
    }

    const rawLineData = {
        type: null,
        lDate: null,
        rdDate: null,
        deposit: null,
        desc: null,
        includes: null,
        styles: [],
        link: null,
        sold: null,
        img: null,
        addOns: [],
    }

    const rawSectionData = {
        types: [],
        name: null,
        lDate: null,
        rdDate: null,
        deposit: null,
        price: null,
        designers: [],
        desc: null,
        soldBy: null,
        gallery: [],
        colors: [],
        premiums: [],
        lines: [rawLineData]
    }

    const rawBandData = {
        name: null,
        bandId: null,
        dateId: null,
        year: null,
        themeType: null,
        theme: null,
        lDate: null,
        rdDate: null,
        deposit: null,
        desc: null,
        locals: null,
        reveller: null,
        services: [],
        imgs: [],
        video: null,
    }

    // band data
    const [band, setBand] = useState(rawBandData)

    // sections and lines data
    const [sections, setSections] = useState([rawSectionData])

    // change page number
    function changePage(number) {
        setPageNumber(pageNumber + number)
        if (number > 0) {
            scroll.scrollToTop()
        }
    }
    return (
        <div className="container card my-4 shadow-lg">
            <h3 className="my-3 titleText">Add Costume Band</h3>
            <Divider flexItem={alert.open} />
            <Collapse in={alert.open}>
                <Alert severity={alert.serverity} action={
                    <IconButton aria-label="close" color="inherit" size="small"
                        onClick={() => setAlert({ ...alert, open: !alert.open })}>
                        <CloseIcon fontSize="inherit" />
                    </IconButton>
                }>
                    <AlertTitle>{alert.title}</AlertTitle>
                    {alert.message}
                </Alert>
            </Collapse>
            {submitted ?
                <div>
                    <Button className="my-3" variant="outlined" color="primary" onClick={redirect}>Return</Button>
                </div>
                :
                <form className="container my-3">
                    <h5 className="subtitleText">
                        <span style={{ cursor: "pointer" }} onClick={() => setPageNumber(0)}>
                            {pageNumber == 0 ? <u>Band</u> : "Band"}
                        </span>&nbsp;|&nbsp;
                        <span style={{ cursor: "pointer" }} onClick={() => setPageNumber(1)}>
                            {pageNumber == 1 ? <u>Sections</u> : "Sections"}
                        </span>
                    </h5>
                    {pageNumber === 0 && bands && festivalDates && dynamics &&
                        <section className="row">
                            <div className="form-group my-4 col-md-4">
                                <InputLabel>Band Name</InputLabel>
                                <Select value={band.bandId} required fullWidth name="bandId" variant="outlined" color="primary" onChange={editBandForm}>
                                    {bands.map(band => <MenuItem value={band._id}>{band.name}</MenuItem>)}
                                </Select>
                            </div>
                            <div className="form-group my-4 col-md-4">
                                <InputLabel>Select Carnival</InputLabel>
                                <Select value={band.dateId} required fullWidth onChange={editBandForm} name="dateId" variant="outlined" color="primary">
                                    {festivalDates.map(date => <MenuItem value={date._id}>{date.festival.name} - {date.year}</MenuItem>)}
                                </Select>
                            </div>
                            <div className="form-group my-4 col-md-4">
                                <InputLabel>Year</InputLabel>
                                <Select value={band.year} required fullWidth name="year" onChange={editBandForm} variant="outlined" color="primary">
                                    {years.map((year) => {
                                        return (
                                            <MenuItem value={year}>{year}</MenuItem>
                                        )
                                    })}
                                    <MenuItem value="canceled">Band did not launch this year</MenuItem>
                                    <MenuItem value="closed">Retired this year</MenuItem>
                                </Select>
                            </div>
                            <div className="form-group my-4 col-4">
                                <InputLabel>Theme Type</InputLabel>
                                <Select fullWidth onChange={editBandForm} value={band.themeType} name="themeType" variant="outlined" color="primary">
                                    {dynamics.themes.map(theme => <MenuItem value={theme}>{theme}</MenuItem>)}
                                </Select>
                            </div>
                            <div className="form-group my-4 col-8">
                                <InputLabel>Theme</InputLabel>
                                <TextField variant="outlined" color="primary" onChange={editBandForm} name="theme" placeholder="Theme"
                                    value={band.theme} fullWidth />
                            </div>
                            <div className="form-group my-4 col-md-4">
                                <InputLabel>Launch Date</InputLabel>
                                <TextField fullWidth type="date" color="primary" onChange={editBandForm} name="lDate" variant="outlined"
                                    value={band.lDate} />
                            </div>
                            <div className="form-group my-4 col-md-4">
                                <InputLabel>Registration Deadline</InputLabel>
                                <TextField fullWidth type="date" name="rdDate" onChange={editBandForm} value={band.rdDate} color="primary"
                                    variant="outlined" />
                            </div>
                            <div className="form-group my-4 col-md-4">
                                <InputLabel>Registration Deposit</InputLabel>
                                <TextField value={band.deposit} type="number" fullWidth name="deposit" variant="outlined" InputProps={{
                                    startAdornment: <InputAdornment position="start">$</InputAdornment>,
                                    inputProps: { min: 0 }
                                }} placeholder="USD" onChange={editBandForm} />
                            </div>
                            <div className="form-group my-4 col-12">
                                <InputLabel>This Year's Description</InputLabel>
                                <TextField value={band.desc} name="desc" onChange={editBandForm} multiline color="primary"
                                    variant="outlined" placeholder="Description" className="col-12" />
                            </div>
                            <div className="form-group my-4 col-md-6">
                                <InputLabel>+50% of Revellers/Mas is between</InputLabel>
                                <Select value={band.reveller} fullWidth name="reveller" variant="outlined" color="primary" onChange={editBandForm}>
                                    {dynamics.revellers.map(reveller => <MenuItem value={reveller}>{reveller}</MenuItem>)}
                                </Select>
                            </div>
                            <div className="form-group my-4 col-md-6">
                                <InputLabel>Local Revellers</InputLabel>
                                <TextField value={band.locals} type="number" fullWidth name="locals" variant="outlined" InputProps={{
                                    startAdornment: <InputAdornment position="start">%</InputAdornment>,
                                    inputProps: {
                                        max: 100,
                                        min: 0,
                                    }
                                }} placeholder="Percentage" color="primary" onChange={editBandForm} />
                            </div>
                            <div className="form-group my-4 col-12">
                                <InputLabel>Services Offered</InputLabel>
                                <Select
                                    multiple
                                    fullWidth
                                    value={band.services}
                                    onChange={editBandForm}
                                    name="services"
                                    variant="outlined"
                                    color="primary"
                                >
                                    {dynamics.services.map(service => <MenuItem value={service}>{service}</MenuItem>)}
                                </Select>
                            </div>
                            <Divider />
                            <div className="d-flex col-12">
                                <Button variant="outlined" color="primary" onClick={submit}>
                                    Submit
                                </Button>
                                <Button className="mx-2" variant="outlined" color="primary"
                                    onClick={() => changePage(1)}>Next
                                </Button>
                            </div>
                        </section>
                    }
                    {pageNumber === 1 && designers && sectionTypes && dynamics &&
                        <SectionTabs
                            dynamics={dynamics}
                            sectionTypes={sectionTypes}
                            bands={bands}
                            lineTypes={lineTypes}
                            designers={designers}
                            editSection={editSectionsForm}
                            editLine={editLinesForm}
                            sections={sections}
                            addSection={addSection}
                            addLine={addLine}
                        />
                    }
                </form>
            }
        </div>
    )
}