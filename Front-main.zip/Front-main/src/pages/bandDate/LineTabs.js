import { makeStyles } from '@material-ui/core/styles';
import PropTypes from 'prop-types';
import {
    AppBar, Tabs, Tab, Typography, Box, IconButton
} from "@material-ui/core";
import { useState } from "react";
import LineForm from './LineForm';
import { BsPlus } from "react-icons/all";

export default function LineTabs({
    lineTypes, dynamics, sectionLines, addNewLine,
    editLine, sectionIndex
}) {
    const [value, setValue] = useState(0);
    const classes = useStyles();
    const [lines, setLines] = useState(sectionLines);
    const handleChange = (event, newValue) => {
        event.preventDefault();
        setValue(newValue);
    };
    function addLine() {
        setLines([
            ...lines,
            {
                type: null,
                lDate: null,
                rdDate: null,
                deposit: null,
                desc: null,
                includes: null,
                styles: [],
                link: null,
                sold: null,
                img: null,
                addOns: [],
            }
        ])
        addNewLine(sectionIndex)
    }

    return (
        <div className={classes.root} style={{ backgroundColor: 'inherit' }}>
            <h3 className="col-12">Lines</h3>
            {
                sectionLines.length > 0 &&
                <AppBar position="static" color="default">
                    <Tabs
                        value={value}
                        onChange={handleChange}
                        indicatorColor="primary"
                        textColor="primary"
                        variant="scrollable"
                        scrollButtons="auto"
                        aria-label="scrollable auto tabs example"
                    >
                        {sectionLines.map((line, index) => (
                            <Tab label={line.type || `Line ${index + 1}`} {...a11yProps(index)} />
                        ))}
                        <IconButton className="my-2 ml-auto" variant="outlined" color="primary" onClick={addLine}><BsPlus /></IconButton>
                    </Tabs>
                </AppBar>
            }
            {sectionLines.map((line, index) => (
                <TabPanel value={value} index={index}>
                    <LineForm
                        line={line}
                        editLine={editLine}
                        dynamics={dynamics}
                        lineTypes={lineTypes}
                        lineIndex={index}
                        sectionIndex={sectionIndex}
                    />
                </TabPanel>
            ))}
        </div>
    )
}

function TabPanel(props) {
    const { children, value, index, ...other } = props;

    return (
        <div
            style={{ backgroundColor: 'rgba(249, 249, 249, 1)' }}
            role="tabpanel"
            hidden={value !== index}
            id={`scrollable-auto-tabpanel-${index}`}
            aria-labelledby={`scrollable-auto-tab-${index}`}
            {...other}
        >
            {value === index && (
                <Box p={3}>
                    <Typography>{children}</Typography>
                </Box>
            )}
        </div>
    );
}

TabPanel.propTypes = {
    children: PropTypes.node,
    index: PropTypes.any.isRequired,
    value: PropTypes.any.isRequired,
};

function a11yProps(index) {
    return {
        id: `scrollable-auto-tab-${index}`,
        'aria-controls': `scrollable-auto-tabpanel-${index}`,
    };
}

const useStyles = makeStyles((theme) => ({
    root: {
        flexGrow: 1,
        width: '100%',
        backgroundColor: theme.palette.background.paper,
    },
}));