import {
    Divider, InputLabel, MenuItem, Select, TextField, InputAdornment
} from "@material-ui/core";
import { useState } from "react";
import FilePicker from "../../components/FilePicker";
import LineTabs from "./LineTabs";

export default function SectionForm({
    dynamics, designers, bands, sectionTypes, lineTypes, section, editSection, index,
    editLine, addLine
}) {
    const [sec, setSec] = useState(section)
    function getFiles(files) {
        setSec({ ...sec, gallery: files });
        editSection('gallery', files, index);
    }
    function editForm(e) {
        setSec({ ...sec, [e.target.name]: e.target.value })
        editSection(e.target.name, e.target.value, index)
    }
    const textBoxStyles = {
        backgroundColor: 'rgb(256, 256, 256)'
    }
    return (
        <section className="row">
            <Divider />
            <div className="form-group my-3 col-12">
                <InputLabel>Enter Band Section Name</InputLabel>
                <TextField
                    style={textBoxStyles}
                    fullWidth
                    name="name"
                    onChange={editForm}
                    placeholder="Band Section Name"
                    variant="outlined" color="primary"
                    value={sec.name}
                />
            </div>
            <div className="form-group my-3 col-12">
                <InputLabel>Section Types</InputLabel>
                <Select
                    style={textBoxStyles}
                    fullWidth
                    value={sec.types}
                    multiple
                    name="types"
                    onChange={editForm}
                    variant="outlined"
                    color="primary"
                >
                    {sectionTypes.map(type => <MenuItem value={type}>{type}</MenuItem>)}
                </Select>
            </div>
            <div className="form-group my-3 col-md-6">
                <InputLabel>Launch Date</InputLabel>
                <TextField style={textBoxStyles} style={textBoxStyles} name="lDate" onChange={editForm} type="date" variant="outlined"
                    value={sec.lDate} />
            </div>
            <div className="form-group my-3 col-md-6">
                <InputLabel>Registration Deadline</InputLabel>
                <TextField style={textBoxStyles} name="rdDate" onChange={editForm} type="date" variant="outlined"
                    value={sec.rdDate} />
            </div>
            <div className="form-group my-3 col-md-6">
                <InputLabel>Deposit</InputLabel>
                <TextField style={textBoxStyles} fullWidth type="number" name="deposit" variant="outlined" InputProps={{
                    startAdornment: <InputAdornment position="start">$</InputAdornment>,
                    inputProps: { min: 0 }
                }} placeholder="USD" onChange={editForm} value={sec.deposit} />
            </div>
            <div className="form-group my-3 col-md-6">
                <InputLabel>Price</InputLabel>
                <TextField style={textBoxStyles} fullWidth type="number" name="price" variant="outlined" InputProps={{
                    startAdornment: <InputAdornment position="start">$</InputAdornment>,
                    inputProps: { min: 0 }
                }} placeholder="USD" onChange={editForm} value={sec.price} />
            </div>
            <div className="form-group my-3 col-12">
                <InputLabel>Designers Name</InputLabel>
                <Select
                    style={textBoxStyles}
                    fullWidth
                    placeholder="Designers"
                    name="designers"
                    variant="outlined"
                    onChange={editForm}
                    value={sec.designers}
                    multiple
                >
                    {designers.map(designer => <MenuItem value={designer._id}>{designer.name}</MenuItem>)}
                </Select>
            </div>
            <h3 className="col-12">About This Section</h3>
            <div className="form-group my-3 col-12">
                <InputLabel>General Description</InputLabel>
                <TextField style={textBoxStyles} fullWidth multiline placeholder="About" name="gDesc" variant="outlined"
                    value={sec.gDesc} onChange={editForm} />
            </div>
            <div className="form-group my-3 col-12">
                <InputLabel>This Section Includes</InputLabel>
                <TextField style={textBoxStyles} className="col-12" placeholder="Includes" name="includes"
                    value={sec.includes} variant="outlined" onChange={editForm} />
            </div>
            <div className="form-group my-3 col-12">
                <InputLabel>Colors/Patterns</InputLabel>
                <Select
                    style={textBoxStyles}
                    multiple
                    fullWidth
                    name="colors"
                    value={sec.colors}
                    onChange={editForm}
                    variant="outlined"
                    color="primary"
                >
                    {dynamics.colors.map(color => <MenuItem value={color}>{color}</MenuItem>)}
                </Select>
            </div>
            <div className="form-group my-3 col-12">
                <InputLabel>Premiums specific to this section</InputLabel>
                <Select
                    style={textBoxStyles}
                    multiple
                    fullWidth
                    name="premiums"
                    value={sec.premiums}
                    onChange={editForm}
                    variant="outlined"
                    color="primary"
                >
                    {dynamics.premiums.map(premium => <MenuItem value={premium}>{premium}</MenuItem>)}
                </Select>
            </div>
            <div className="form-group my-3 col-12">
                <InputLabel>Marketed/Sold by</InputLabel>
                <Select style={textBoxStyles} value={sec.soldBy} fullWidth name="soldBy" onChange={editForm} variant="outlined" color="primary">
                    {bands.map(band => <MenuItem value={band._id}>{band.name}</MenuItem>)}
                </Select>
            </div>
            <div className="form-group my-3 col-12 d-none">
                <InputLabel>Gallery+</InputLabel>
                <FilePicker updateFilesCb={getFiles} />
            </div>
            <LineTabs
                dynamics={dynamics}
                lineTypes={lineTypes}
                sectionLines={section ? section.lines : []}
                addNewLine={addLine}
                sectionIndex={index}
                editLine={editLine}
            />
        </section>
    )
}