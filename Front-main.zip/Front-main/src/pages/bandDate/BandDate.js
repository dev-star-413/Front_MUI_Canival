import React, { useEffect, useState } from "react";
import {useHistory} from "react-router"
import { useRef } from "react";
import { AiOutlineLike, AiOutlineDislike, BsChevronCompactDown } from "react-icons/all";
import ordinal from "ordinal";
import { useCookies } from "react-cookie";
import { LazyLoadComponent } from 'react-lazy-load-image-component';
import {FadeLoader} from "react-spinners";
import Comment from "../../components/Comment"
import { Divider, Button } from "@material-ui/core";
import {Col} from "react-bootstrap"
import {Link} from "react-router-dom"
import "@fortawesome/fontawesome-free/css/all.css"
import LoadingOverlay from 'react-loading-overlay';

import {getCostumeBand, postBandDateScoreReview} from "../../functions/api"
import generateAddressImg from "../../functions/generateAddressImg"
import convertToUSD from "../../functions/convertCurrency"
import profilePicture from "../../assets/imgs/image-not-found.jpg";
import { LazyLoadImage } from 'react-lazy-load-image-component';
import { GrStar } from "react-icons/all";
import Advertisement from "../../components/Advertisement";
const RateSection = React.lazy(() => import('../../components/Festival/RateSection')); 
const Slideshow = React.lazy(() => import("../../components/SlideShow"));
const BandReview = React.lazy(() => import("../../components/BandReview"));
const Compare = React.lazy(() => import("../../components/Compare"));
const Hot = React.lazy(() => import("../../components/Hot"));
const AddOn = React.lazy(() => import("../../components/AddOn"));

export default function BandDate({ match }) {
    const hr = {
        color: '#292b2c ',
        backgroundColor: '#292b2c ',
        height: 1,
    }
    const history = useHistory()
    const [band, setBand] = useState(null);
    const [dynamics, setDynamics] = useState({ bands: [], sections: [], carnivals: [], years: [] });
    const [sections, setSections] = useState(null);
    const [jouvertSections, setJouvertSections] = useState(null);
    const [costumeSections, setCostumeSections] = useState(null);
    const [childrenSections, setChildrenSections] = useState(null);
    const [day2Sections, setDay2Sections] = useState(null);
    const [otherSections, setOtherSections] = useState(null);
    const [lines, setLines] = useState(null);
    const [rawBand, setRawBand] = useState(null);
    const [events, setEvents] = useState(null);
    const [reviews, setReviews] = useState(null);
    const [comments, setComments] = useState([])
    const [guides, setGuides] = useState(null);
    const [festival, setFestival] = useState(null);
    const [changed, setChanged] = useState(false);
    const [comparisons, setComparisons] = useState([]);
    const [services, setServices] = useState(null);
    const [jouvertServices, setJouvertServices] = useState(null);
    const [childrenServices, setChildrenServices] = useState(null);
    const [awards, setAwards] = useState([]);
    const [soldout, setSoldout] = useState(0);
    const [avgScore, setAvgScore] = useState(0);
    const navRef = useRef(null);
    const menuRef = useRef()
    const menuRef2 = useRef()
    const [fixNavBar, setFixNavBar] = useState(false)
    const [navWidth, setNavWidth] = useState(100)
    const [linesMinPrice, setLinesMinPrice] = useState(0)
    const [linesMaxPrice, setLinesMaxPrice] = useState(0)
    const [linesCurrencyPrice, setLinesCurrencyPrice] = useState("USD")
    const [uniqueId, setUniqueId] = useCookies(['uniqueId']);
    const [otherBandsInFY, setOtherBandsInFY] = useState(null);
    const [servicesCheckbox, setServicesCheckbox] = useState(null);
    const [jouvertServicesCheckbox, setJouvertServicesCheckbox] = useState(null);
    const [childrenServicesCheckbox, setChildrenServicesCheckbox] = useState(null);
    const [thisBandInOtherFYs, setThisBandInOtherFYs] = useState([]);
    const [allCourenciesRates, setAllCourenciesRates] = useState([]);
    const [slideShow, setSlideShow] = useState({
      open: false,
      images: [],
      type: "list",
      dialogTitle: "",
      selected: null,
      continuous: true,
      sectionIndex: 0,
    })
    const [loading, setLoading] = useState(true)
    const userExists = Boolean(localStorage.token);
    let scoreAverage = 0;
    const [sectionsList,setSectionsList]=useState([])
    const [navigated, setNavigated]=useState(false)
    // gallery
    const [gallery,setGallery]=useState([])
    const [news,setNews]=useState([])
    const [pastExperience,setPastExperience]=useState([])
    //
    const [bandDateDetails,setBandDateDetails]=useState('')
    useEffect(function () {
      let tempMinPrice = Infinity, tempMaxPrice = 0,currency='USD';
      if (lines && lines[0] && Array.isArray(lines)) {
        for (let line of lines) {
          const thisSection = sections.find(item => item._id == line.sId);
          if(thisSection.types.indexOf("Mas/Costume") === -1) {
            continue;
          }
          for (let gallery of line.gallery) {
            if(gallery.currency) currency=gallery.currency
            if(gallery.price === 0) {
              continue;
            }
            if (gallery.price < tempMinPrice) {
              tempMinPrice = gallery.price;
            }
            if (gallery.price > tempMaxPrice) {
              tempMaxPrice = gallery.price;
            }
          }
        }
        setLinesCurrencyPrice(currency)
        setLinesMinPrice(tempMinPrice);
        setLinesMaxPrice(tempMaxPrice);
      }
    }, [lines])

    useEffect(function () {
        window.addEventListener('scroll', handleScroll)
        window.addEventListener("hashchange", function () {
          window.scrollTo(window.scrollX, window.scrollY - 100);
        });
    }, [])

    useEffect(() => {
      if (band && band.scores && band.scores[0]) {
        let sum = 0;
        band.scores.map(score => sum += parseFloat(score.score));
        scoreAverage = sum / band.scores.length;
      }
      setAvgScore(scoreAverage)

      if (lines && soldout == 0) {
          let temp = 0;
          lines.map(line => temp += parseInt(line.sold));
          setSoldout(Math.floor(temp / lines.length))
      }
    }, [band])

    useEffect(() => {
      if(!navigated && band && window.location.hash) {
        var element = document.querySelector(window.location.hash);
        if (element) {
          element.scrollIntoView();
          setNavigated(true);
        }
      }
    })
    const getData=async()=>{
      try{
        const data = await getCostumeBand(match.params.slug)
        if(!data || !data.band || !data.bandDate) return window.location.href="/404"
        if (data && data.band) {
            setBand(data.bandDate)
            setAllCourenciesRates(data && data.CurrencyRates )
            if(data.sections){
              setSections(data.sections)
              var sectionsList=data.sections.map((index)=>{return {name:index.name,_id:index._id}})
              setSectionsList(sectionsList)
              let tempCostumeSections = [];
              let tempJouvertSections = [];
              let tempChildrenSections = [];
              let tempDay2Sections = [];
              let tempOtherSections = [];

              var details=data.bandDate?.details
              if(!details)details=data.bandDateDetails && data.bandDateDetails.bandDateDetails
              if(details){
                details=details.replaceAll('#BandName_year',data.bandDate.name+' '+data.bandDate.year)
                details=details.replaceAll('#FestivalName_year',data.bandDate.dateName+' '+data.bandDate.year)
                details=details.replaceAll('#BandName',data.band.name)
                details=details.replaceAll('#FestivalName',data.carnival?.festival.name)
                details=details.replaceAll('#year',data.bandDate.year)
              }
              setBandDateDetails(details)
              for(let sec of data.sections) {
                if(sec.types.indexOf("Mas/Costume") > -1 || sec.types.indexOf("Adult Costume") > -1) {
                  tempCostumeSections.push(sec)
                } 
                if (sec.types.indexOf("J'ouvert") > -1 || sec.types.indexOf("Jouvert") > -1) {
                  tempJouvertSections.push(sec)
                }
                if (sec.types.indexOf("Day2/2nd Wear") > -1 || sec.types.indexOf("Day || Wear") > -1) {
                  tempDay2Sections.push(sec)
                }
                if (sec.types.indexOf("Others") > -1) {
                  tempOtherSections.push(sec)
                }
                if (sec.types.indexOf("Children/Junior") > -1) {
                  tempChildrenSections.push(sec)
                }
              }
              setCostumeSections(tempCostumeSections);
              setJouvertSections(tempJouvertSections)
              setDay2Sections(tempDay2Sections)
              setOtherSections(tempOtherSections)
              setChildrenSections(tempChildrenSections)
            }
            setRawBand(data.band)
            if(data.lines && data.lines[0]) {
              setLines(data.lines)
            }
            setEvents(data.events);
            setReviews(data.reviews);
            setServices(data.services);
            setJouvertServices(data.jouvertServices);
            setChildrenServices(data.childrenServices);
            setGuides(data.guides);
            setFestival(data.carnival);
            setComparisons(data.comparisons);
            setAwards(data.awards);
            setDynamics({
                bands: data.dynamics.bands,
                sections: data.dynamics.sections,
                carnivals: data.dynamics.carnivals,
                years: data.dynamics.years
            });
            setComments(data.comments);
            setOtherBandsInFY(data.otherBandsInFY)
            setThisBandInOtherFYs(data.thisBandInOtherFYs);
            setGallery(data.galleries)
            setNews(data.news)
            setPastExperience(data.pastExperience || [])
        } else {
          history.push('/404')
        }
      } catch (err) {
        console.log(err)
      } finally {
        setTimeout(() => {
          setLoading(false)
        }, 20)
      }
    }

    useEffect(async function () {
      setLoading(true)
      getData()
    }, [match.params.slug]);
    
    useEffect(() => {
      if (loading) {
        document.body.style.overflow = "hidden";
        document.body.style.height = "100%";
      } else {
        document.body.style.overflow = "auto";
        document.body.style.height = "auto";
      }
    }, [loading]);

    useEffect(()=>{
      if(band && band.services){
        let bandServices = band.services;
        let content = []
        var all = services ? services.length : 0
        var length =bandServices ? bandServices.length : 0
        if(length < 1) content.push(<span className="text-secondary mx-1 ">No Feature Selected or Unknown.</span>)
        if(services && services[0] && bandServices) {
            for (let ser of services) {
                let exist = bandServices.includes(ser)
                var icon = (exist ) ?
                    <i className='fa fa-check text-success mx-1'></i> :
                    <i className='fa fa-times text-danger mx-1'></i>
                content.push(
                    <div className="col-12" key={ser}>
                        <span>{icon}{ser}</span>
                    </div>
                )
            }
        }
        setServicesCheckbox(
          <div>
            <h3>Top Costumes Features and services with {band.name} at {band.dateName}</h3>
            {(length < 1)?"":<><progress id="progress" value={length} max={all}></progress> {length} / {all} </>}
            {content}
          </div>
        )
      }
      if(band && band.jouvertServices) {
        var bandJouvertServices= band.jouvertServices || []
        var jouvertContent=[]
        var allJouvert=jouvertServices ? jouvertServices.length : 0
        var jLength=bandJouvertServices ? bandJouvertServices.length : 0
        if(jLength < 1) jouvertContent.push(<span className="text-secondary mx-1">No Feature Selected or Unknown.</span>)
        else if(jouvertServices && jouvertServices[0]){
          for(let jSer of jouvertServices){
            let include=bandJouvertServices.includes(jSer)
            let jIcon = (include ) ? <i className='fa fa-check text-success mx-1'></i> :
                <i className='fa fa-times text-danger mx-1'></i>
                jouvertContent.push(
                    <div className="col-12" key={jSer}>
                        <span>{jIcon}{jSer}</span>
                    </div>
                )
          }
        }
        setJouvertServicesCheckbox(
          <div>
            <h3>Top Jouvert Features and Service with {band.name} at {band.dateName}</h3>
            {(jLength < 1)?"":<><progress id="progress" value={jLength} max={allJouvert}></progress> {jLength} / {allJouvert} </>}
            {jouvertContent}
          </div>
        )
      }
      if(band && band.childrenServices){
        var bandChildrenServices= band.childrenServices || []
        var childrenContent=[]
        var allChildren=childrenServices ? childrenServices.length : 0
        var ChLength=bandChildrenServices ? bandChildrenServices.length : 0
        if(ChLength < 1) childrenContent.push(<span className="text-secondary mx-1">No Feature Selected or Unknown.</span>)
        else if( childrenServices && childrenServices[0]){          
          for(let cSer of childrenServices){
            let include=bandChildrenServices.includes(cSer)
            let chIcon = (include) ? <i className='fa fa-check text-success mx-1'></i> :
                <i className='fa fa-times text-danger mx-1'></i>
                childrenContent.push(
                    <div className="col-12" key={cSer}>
                        <span>{chIcon}{cSer}</span>
                    </div>
                )
          }
        }
        setChildrenServicesCheckbox(
          <div>
            <h3>Top Children Features and Service with {band.name} at {band.dateName}</h3>
            {/* <progress id="progress" value={ChLength} max={allChildren}></progress> {ChLength} / {allChildren} */}
            {childrenContent}
          </div>
        )

      }
    }, [band, services, jouvertServices,childrenServices])

    useEffect(()=>{
      if(!bandDateDetails || !bandDateDetails.indexOf("#sectionList") ) return
      var costume=''
      var jouvert=''
      var children=''
      var day2=''
      var other=''
      if(costumeSections && costumeSections[0]){
        for(let c of costumeSections){
          let content=c.name +` (Adult)`
          if(c.designers && c.designers[0]) content+=' designed by '+c.designers.map(d=>d.name) 
          if(c.soldBy && c.soldBy) content+=' Marketed  by '+c.soldBy.name  
          costume+=`<li>${content}</li>`
        }
      }
      if(jouvertSections && jouvertSections[0]){
        for(let j of jouvertSections){
          let content=j.name +` (Jouvert)`
          if(j.designers && j.designers[0]) content+=' designed by '+j.designers.map(d=>d.name) 
          if(j.soldBy && j.soldBy) content+=' Marketed  by '+j.soldBy.name   
          jouvert+=`<li>${content}</li>`
        }
      }
      if(childrenSections && childrenSections[0]){
        for(let ch of childrenSections){
          let content=ch.name +` (Children)`
          if(ch.designers && ch.designers[0]) content+=' designed by '+ch.designers.map(d=>d.name) 
          if(ch.soldBy && ch.soldBy) content+=' Marketed  by '+ch.soldBy.name   
          children+=`<li>${content}</li>`
        }
      }
      if(day2Sections && day2Sections[0]){
        for(let d of day2Sections){
          let content=d.name +` (Day II)`
          if(d.designers && d.designers[0]) content+=' designed by '+d.designers.map(d=>d.name)  
          if(d.soldBy && d.soldBy) content+=' Marketed  by '+d.soldBy.name   
          day2+=`<li>${content}</li>`
        }
      }
      if(otherSections && otherSections[0]){
        
        for(let o of otherSections){
          let content=o.name 
          if(o.designers && o.designers[0]) content+=' designed by '+o.designers.map(d=>d.name) 
          if(o.soldBy && o.soldBy) content+=' Marketed  by '+o.soldBy.name  
          other+=`<li>${content}</li>`
        }
      }
      var content=''
      if(costume[0]) {
        content+=
          `<div className="my-1">
            <h5>${band.name} Adult Costume Options for the ${band.year} ${band.dateName}:</h5>
            <ul>${costume}</ul>
          </div>`
        
      }
      if(jouvert[0]) {
        content+=
          `<div className="my-1">
            <h5>${band.name} Jouvert Options for the ${band.year} ${band.dateName}:</h5>
            <ul>${jouvert}</ul>
          </div>`
        
      }
      if(children[0]) {
        content+=
          `<div className="my-1">
            <h5>${band.name} Children Options for the ${band.year} ${band.dateName}:</h5>
            <ul>${children}</ul>
          </div>`
        
      }
      if(day2[0]) {
        content+=
          `<div className="my-1">
            <h5>${band.name} Day II Wear Options for the ${band.year} ${band.dateName}:</h5>
            <ul>${day2}</ul>
          </div>`
        
      }
      if(other[0]) {
        content+=
          `<div className="my-1">
            <h5>${band.name} for the ${band.year} ${band.dateName}:</h5>
            <ul>${other}</ul>
          </div>`
        
      }
      var details=bandDateDetails.replace('#sectionList',content)
      setBandDateDetails(details)

    },[childrenSections])  

    const dollarSigns = (min, max, price) => {
        if (max > min) {
            let output = [];
            const signCount = 4;
            const diff = max - min;
            const scope = diff / signCount;
            const enableSignsCount = Math.round((price - min) / scope);
            for (let i = 0; i < enableSignsCount; i++) {
                output.push(<span><b>$</b></span>)
            }
            for (let i = enableSignsCount; i < signCount; i++) {
                output.push(<span className="text-secondary">$</span>)
            }
            return output;
        }
        return <span><b>$$$$</b></span>;
    }
    const getSymbolCurrency=(x)=>{
      var rate=allCourenciesRates.find((r)=>r.from==x)
      return rate && rate.symbol
    }
    const handleScroll = ({ element, useWindow }) => {
        var navBarRect = navRef && navRef.current && navRef.current.getBoundingClientRect();
        if (navBarRect && navBarRect.y < 53 && !changeNavbar) {
            setFixNavBar(true)
            setNavWidth(navBarRect.width)
        }
        else if (navBarRect && navBarRect.y > 50) {
            setFixNavBar(false)
        }
    }

    function handleSliderChooseSection(sectionID){
      const thisSectionLines = lines ? lines.filter(line => line.sId == sectionID) : []
      let images=[]
      for(let line of thisSectionLines){
        if(line.gallery && line.gallery[0]) {
          for(let lg of line.gallery) {
            if(!lg || !lg.path || lg.isAddOn) {
              continue;
            }
            let media = {};
            media._id=lg._id
            media.img = (lg.mime && lg.mime.includes('video')) ? lg.path : generateAddressImg(lg.path, 1120, 630)
            media.name = lg.text
            images.push(media)
          }
        }
      }
      setSlideShow(
        {
          ...slideShow, 
          images, selected: null, open: true, 
          continuous: true, 
          dialogTitle: band.name + " > " + band.dateName + " " + band.year 
        }
      )
    } 

    function createSectionElement(section, index) {
      const average = section.average;
      let prevLineTitle = "";
      const thisSectionLines = lines ? lines.filter(line => line.sId == section._id) : []
      let images=[]
      for(let line of thisSectionLines){
        if(line.gallery && line.gallery[0]) {
          for(let lg of line.gallery) {
            if(!lg || !lg.path || lg.isAddOn) {
              continue;
            }
            let media = {};
            media._id=lg._id
            media.img = (lg.mime && lg.mime.includes('video')) ? lg.path : generateAddressImg(lg.path, 1120, 630)
            media.name = lg.text
            images.push(media)
          }
        }
      }

      let thisSection = null;
      let sectionIndex = -1;
      for(let i in sections) {
        if(sections[i]._id === section._id) {
          thisSection = sections[i]
          sectionIndex = i;
          break;
        }
      }

      if(!thisSection) return;

      return (
          <div key={section._id}>
              <details open={thisSection.open} >
                  <summary className="row pb-2" onClick={(e) => handleSectionClick(e, sectionIndex, !thisSection.open)} >
                      {(section.img)?
                          <div className="col-3">
                              <img
                                  src={generateAddressImg(section && section.img && section.img.path,45,45)}
                                  className="img-fluid mx-auto d-inline-block d-sm-none"
                              />
                              <img
                                  src={generateAddressImg(section && section.img && section.img.path,240,240)}
                                  className="img-fluid mx-auto d-none d-sm-block"
                              />
                          </div>:
                          <div className="col-3">
                            <img
                                src={profilePicture}
                                className="img-fluid mx-auto d-inline-block d-sm-none"
                            />
                            <img
                                src={profilePicture}
                                className="img-fluid mx-auto d-none d-sm-block"
                            />
                          </div>
                      }
                      <div className="col-8 col-sm-8">
                          <h3 >
                              {section.name}
                              <BsChevronCompactDown className="d-inline-block d-sm-none float-right"></BsChevronCompactDown>
                          </h3>
                          <span className="text-secondary">{average}&nbsp;<i className="fa fa-fire fa-lg" style={{ color: 'rgb(255, 100, 0)' }}></i>&nbsp;{band.dateName}&nbsp;{band.year}&nbsp;{'>'}&nbsp;{band.name}</span>
                      </div>
                      <div className="col-1  d-none d-sm-block">
                          <BsChevronCompactDown className="fa-lg"></BsChevronCompactDown>
                      </div>
                  </summary>
                  <RateSection
    
                      // hot={average}
                      compare={`/bands/compare/${band.slug}~${section._id}`}
                      wishlist={userExists}
                      share
                      link={`/bands/${band.slug}`}
                      text={`${band.name} at ${band.dateName} ${band.year}`}
                      collName="Section"
                      docID={section._id}
                  />
                  <hr style={hr} />
                  <h4 className="my-3">
                      About {section.name} section by {band.name} for {band.dateName} {band.year}
                  </h4>
                  {section.img &&
                    <div>
                        <img src={generateAddressImg(section && section.img && section.img.path,1120,630)} className="img-fluid" />
                        {/* <div className="bandPicture shadow"
                            style={{ backgroundImage: `url('${section.img.path}')` }} /> */}
                    </div>
                  }
                  <div className="mb-4 text-center">
                    <a href="javascript: void(0)" className="pointer" onClick={()=>{
                      setSlideShow({...slideShow, images, type: "list", selected: null, open: true, 
                        continuous: true, sectionIndex: sectionIndex, dialogTitle: band.name + " > " + band.dateName + " " + band.year });}}>
                      View List 
                    </a> 
                    &nbsp;|&nbsp;
                    <a href="javascript: void(0)" className="pointer" id={"showSlide" + sectionIndex} onClick={()=>{
                      setSlideShow({...slideShow, images, type: "slideShow", selected: null, open: true, 
                        continuous: true, sectionIndex: sectionIndex, dialogTitle: band.name + " > " + band.dateName + " " + band.year});}}> 
                      View Slide show 
                    </a>
                  </div>
                  <div>
                      {section.lDate && <h5><b>Launch:</b>&nbsp;{section.lDate}</h5>}
                      {section.deposit && 
                        <div className="d-flex">
                          <h5><b>Deposit</b> of:&nbsp;<b>{(section.dCurrency && section.dCurrency!="USD")?getSymbolCurrency(section.dCurrency)+section.deposit+' '+section.dCurrency+"($"+convertToUSD(section.deposit,allCourenciesRates,section.dCurrency)+" USD)":"$"+section.deposit+" USD"}</b>{(section.rdDate)?" by "+section.rdDate:""}</h5>
                          {band && band.link && 
                              <Link to={{pathname:band.link}} style={{fontSize:'1.2rem',lineHeight:1.2}} target="_blank">&nbsp;Buy</Link>
                          }
                        </div>
                      }
    
                  </div>
                  <div className="my-5">
                      {section.starts && <h5>Prices start:&nbsp;<b>{section.currencyStarts !="USD"? getSymbolCurrency(section.currencyStarts)+section.starts+' '+ section.currencyStarts+'($'+convertToUSD(section.starts,allCourenciesRates,section.currencyStarts)+" USD)":"$"+section.starts+" USD"}</b> ({dollarSigns(linesMinPrice, linesMaxPrice, section.starts)}) / <Link className="titleText" target={'_blank'} to="/pricing-learn-more">Learn More</Link></h5>}
                      {section.designers && Array.isArray(section.designers) && section.designers[0] &&
                          <h5>Designed by:&nbsp;
                              <b>
                                  {section.designers.map((designer, index) => {
                                      if (index + 1 !== section.designers.length) {
                                          return (
                                              <span key={index}>
                                                  <Link style={{ color: "#2e86c1" }} to={"/designers/" + designer.slug}>{designer.name}</Link>,&nbsp;
                                              </span>
                                          )
                                      } else {
                                          return (
                                              <span key={index}>
                                                  <Link style={{ color: "#2e86c1" }} to={"/designers/" + designer.slug}>{designer.name}</Link>
                                              </span>
                                          )
                                      }
                                  })}
                              </b>
                          </h5>
                      }
                      {section.soldBy && <h5>Powered/Marketed by:&nbsp;<b className="titleText">{section.soldBy.name}</b></h5>}
                      {section.colors && <h5>Colors/Patterns:&nbsp;{section.colors.map((color, cI) => (
                          <React.Fragment key={cI}>
                              <span style={{
                                  backgroundColor: color,
                                  width: '1rem',
                                  height: '1rem',
                                  display: 'inline-block',
                                  marginLeft: '0.5rem',
                                  marginRight: '0.5rem'
                              }} />
                              <span>{color}</span>
                          </React.Fragment>
                      ))}</h5>}
                  </div>
                  <div>
                      {section.desc &&
                          <div dangerouslySetInnerHTML={{ __html: section.desc }} />}
                  </div>
                  <hr style={hr} />
                  {thisSectionLines.map(line => {
                      line.styles = Array.isArray(line.styles) ? line.styles : [line.styles];
                      return (
                          <div key={line._id}>
                              <small>{section.name}</small>
                              <h5 className="align-items-center d-flex flex-row">
                                  {line.type}&nbsp;
                                  {line.deposit? line.currency && line.currency!="USD"?getSymbolCurrency(line.currency)+line.deposit+' '+line.currency+"($"+convertToUSD(line.deposit,allCourenciesRates,line.currency)+" USD)":"$"+line.deposit+" USD" : ""}&nbsp;
                                  {(line && line.link) ? <a className="text-primary" target="_blank" href={line.link}>Book Now</a>:<a className="text-primary" target="_blank" href={band.link}>Book Now</a>}
                              </h5>
                              <div className="my-2">
                                  {line.gallery.filter(img => img.isAddOn === false).map((img, index) => 
                                    {
                                      let el = <div key={index} className="row my-5">
                                        <div className="col-12 col-md-3 ">
                                          <a href="javascript: void(0)" onClick={
                                            ()=>{
                                              setSlideShow({
                                                ...slideShow,
                                                images, 
                                                selected: img._id, 
                                                continuous: true, 
                                                open: true, 
                                                dialogTitle: band.name + " > " + band.dateName + " " + band.year
                                              });
                                            }}>
                                            <img src={generateAddressImg(img.path,330,440)} className="img-fluid"/>
                                          </a>
                                        </div>
                                        {prevLineTitle !== img.text && <div className="col-12 col-md-9">
                                            <h4 className='pt-2 font-weight-bold'>
                                                {img.text} {img.price ? (img.currency && img.currency!="USD")?getSymbolCurrency(img.currency)+img.price+' '+img.currency+ '($'+convertToUSD(img.price,allCourenciesRates,img.currency)+ ' USD)' :"$"+img.price+' USD' :""}
                                            </h4>
                                            <p>
                                              {band.dateName} {band.year} {">"} {band.name} {">"} {section.name}
                                              <br />
                                              {img.includes && `Included: ${img.includes}`}
                                            </p>
                                        </div> }
                                      </div>
                                      prevLineTitle = img.text
                                      return el
                                    }
                                  )}
                              </div>
                              {line.gallery.filter(img => img.isAddOn === true).length > 0 &&
                                  <div className="my-2">
                                      <h5 className="text-dark mt-4">Available Add ons</h5>
                                      {line.gallery.filter(img => img.isAddOn === true).map((img, index) => <AddOn index={index} key={index} title={img.text} img={img.path} price={img.price? (img.currency && img.currency!="USD")?getSymbolCurrency(img.currency)+img.price+' '+img.currency+"($"+convertToUSD(img.price,allCourenciesRates,img.currency)+" USD)":"$"+img.price+" USD" : ""} />)}
                                  </div>
                              }
                              <div>
                                  {line.lDate && <h5><b>Launch:</b>&nbsp;{line.lDate}</h5>}
                              </div>
                              <div>
                                  {line.styles && <h5 className="my-3"><b>Available style/fit:</b>&nbsp;{line.styles.join(', ')} | <Link className="titleText" to="/view-style-chart">View Style Chart</Link></h5>}
                              </div>
                              {line.desc && <div className="my-4" dangerouslySetInnerHTML={{ __html: line.desc }} />}
                              <hr style={hr} />
                          </div>
                      )
                  })}
                  <Hot section={section} average={average} />
                  <Comment hasReply={true} collName="section" docID={section._id} countCoumments={section.commentC}/>
              </details>
              <Button className={'d-none'} variant="text" onClick={(e) => handleSectionClick(e, sectionIndex, !thisSection.open)}>- Hide this section</Button>
              <Divider className="my-3" />
          </div>
        )
    }

    function handleSectionClick(e, index, data) {
      e.preventDefault();
      let sects = sections;
      sects[index] = { ...sects[index], open: data }
      setSections(sects);
      setChanged(!changed)
    }
    
    async function handleScoreReviewSubmit(type) {
        const res = await postBandDateScoreReview({ docID: band._id, review: type, uniqueId: !userExists && uniqueId.uniqueId });
        if (res && res.code === 0) {
            if (!userExists) {
                setUniqueId('uniqueId', res.msg, { path: '/' });
            }
            setBand({ ...band, agree: res.data.agree, disagree: res.data.disagree, notsure: res.data.notsure });
        } else {
            alert(res.msg);
        }
    }
    const lineImages = []
    if (lines && lines.length > 0) {
      for(let line of lines) {
        if (line.gallery && line.gallery.length > 0) {
          for(let gallery of line.gallery) {
            lineImages.push({
              _id:gallery._id,
              img: generateAddressImg(gallery && gallery.path,1120,630),
              name: gallery.text,
              deposit: gallery.price,
              bandName: band.name,
              dateName: band.dateName,
              year: band.year
            });
          }
        }
      }
    }
    let scoreReviewsSum = 0;
    if (band && band.agree >= 0 && band.disagree >= 0 && band.notsure >= 0) {
        scoreReviewsSum = band.agree + band.disagree + band.notsure;
    }
    var changeNavbar = false

    function scrollLeft() {
        if (menuRef && menuRef.current) menuRef.current.scrollLeft += -50
        menuRef2.current.scrollLeft += -50
    }
    function scrollRight() {
        if (menuRef && menuRef.current) menuRef.current.scrollLeft += 50
        menuRef2.current.scrollLeft += 50
    }

    function CreateNavbar() {
      return <>
        {rawBand && rawBand.slug && <><a className="p-3 text-white menuButton font-weight-bold" href={'/band/'+rawBand.slug}>Home</a><span className="text-secondary">|</span></>}
        {band && band.year && <><a className="p-3 text-white menuButton font-weight-bold" href="#section-about">{band.year}</a><span className="text-secondary">|</span></>}
        {band && band.showAdult && <><a className="p-3 text-white menuButton font-weight-bold text-nowrap" href="#section-costume">Adult Costumes</a><span className="text-secondary">|</span></>}
        {band && band.showJouvert && <><a className="p-3 text-white menuButton font-weight-bold" href="#section-jouvert">Jouvert</a><span className="text-secondary">|</span></>}
        {band && band.showChildren && <><a className="p-3 text-white menuButton font-weight-bold" href="#section-children">Children</a><span className="text-secondary">|</span></>}
        {gallery && gallery.length > 0 && <><a className="p-3 text-white menuButton font-weight-bold" href="#section-gallery">Photos</a><span className="text-secondary">|</span></>}
        {pastExperience && pastExperience.length > 0 && <><a className="p-3 text-white menuButton font-weight-bold text-nowrap" style={{whiteSpace:'nowrap'}} href="#section-experience">Past&nbsp;Years</a><span className="text-secondary">|</span></>}
        {events && events.length > 0 && <><a className="p-3 text-white menuButton font-weight-bold" href="#section-events">Events</a><span className="text-secondary">|</span></>}
        {awards  && awards.length > 0 && <><a className="p-3 text-white menuButton font-weight-bold" href="#section-results">Results</a><span className="text-secondary">|</span></>}
        {news  && news.length > 0 && <><a className="p-3 text-white menuButton font-weight-bold" href="#section-news">News</a><span className="text-secondary">|</span></>}
        {band.scores && band.scores.length > 0 && <><a className="p-3 text-white menuButton font-weight-bold" href="#section-reviews">Reviews/Score</a><span className="text-secondary">|</span></>}
        {/*<Link className="p-3 text-white menuButton font-weight-bold text-nowrap" style={{whiteSpace:'nowrap'}} to={`/festivals/${festival && festival.slug}`}>{band.dateName} {band.year}</Link>*/}
        {/* {festival && festival.bestE && new Date() > new Date(festival.bestE) && <a className="p-3 text-white menuButton font-weight-bold" href="#section-userreviews">User Reviews</a>} */}
      </>
    }

    function handleActionSlide() {
      setSlideShow({...slideShow, open: false})
    }
    function RenderOtherBands(){
      var confirm=[]
      var unConfirm=[]
      if(otherBandsInFY && Array.isArray(otherBandsInFY) && otherBandsInFY.length>0){
        for(var b of otherBandsInFY){
          var actived=false;
          var types=[]
          if(b.isChildrenService)types.push('Children')
          if(b.isCustomeService)types.push('Adult')
          if(b.isJouvertService)types.push('Jouvert')
          if(b.theme || b.sections >0) actived=true
          if(b.confirm){
            confirm.push(
              <li className="col-md-6" key={b._id}>
                <Link  to={`/bands/${b.slug}`}>
                  {b.name} {(types && types[0])?' ('+types.join(', ')+') ':""} {(actived)?'  [active]':""}
                </Link>
              </li>
            )
          }else{
            unConfirm.push(
              <li className="col-md-6" key={b._id}>
                <Link  to={`/bands/${b.slug}`}>
                {b.name} 
                {(types && types[0])?' ('+types.join(', ')+') ':""}
                </Link>
                
              </li>
            )
          }
        }
      }
      return(
        <div className="py-2">
          <h2 className="mb-2">{band.dateName} {band.year} Pariticiptaing  Bands</h2>
          {(confirm && confirm[0])?
            <>
              <label>Confirmed</label>
              <ul className="row pt-2">
                {confirm}              
              </ul>
            </>
            :""
          }
          {(unConfirm && unConfirm[0])?
            <>
              <label>Unconfirmed</label>
              <ul className="row pt-2">
                {unConfirm}              
              </ul>
            </>
            :""
          }

        </div>
      )
    }
    function RenderAdultCostumeSections(){
      if(!band || !band.showAdult) return <></>
      return(
          <div id="section-costume" className="col-12 my-3" >
            <h2>{band.name} at {band.dateName} {band.year} Adult Costume Options</h2>
            {
                (band.costumeImg && band.costumeImg.path) ? <img className="img-fluid " alt={band.name} src={generateAddressImg(band.costumeImg.path,560,315)} width="100%" height="auto" />
                :
                (band.costumeLImg && band.costumeLImg.path) ? <img className="img-fluid " alt={band.name} src={generateAddressImg(band.costumeLImg.path,560,315)} width="100%" height="auto" />
                : ""
            }
            <div className="col-12 my-2">
              {band.theme &&  <div className="col"> <span>Theme: {band.theme}</span> </div>}
              {band.preRegisPrice &&  <div className="col"> <span>PRE-Registration Option: {band.preRegisPrice} USD</span> </div>}
              {band.preRegisDeadLine &&  <div className="col"> <span>PRE-Registration DeadLine: {band.preRegisDeadLine}</span> </div>}
              {band.lDate &&  <div className="col"> <span>Launch Date: {band.lDate}</span></div>}
              {band.rdDate && <div className="col">  <span>Registration Deadline: {band.rdDate}</span></div>}
            </div>
            {(festival && festival.paradeS && festival.paradeE )?
              <div className="col-12 my-2">
                <h3>When and Where is {band.dateName} Adult Costume Parade {band.year}</h3>
                <div>
                    <b>Date/Time</b>
                    <div>{festival.paradeS }</div>
                    <div>{festival.paradeE }</div>
                </div>
                {(festival.paradeLocation)?
                 <div>
                    <b>Location</b>
                    <div className="col"><span>{festival.paradeLocation}</span></div>
                  </div>:""
                }
               
              </div>:''

            }

            {/* show  costume services */}
            { servicesCheckbox}
            {/* list costume sections */}
            { costumeSections && costumeSections[0] && 
              <div className="col-12 my-2">
                <h3>{band.name} at {band.dateName} Costume Sections {band.year}</h3>
                <div>
                  {costumeSections.map( (section,index)=>{
                    return createSectionElement(section, index)
                  })}
                
                </div>   
              </div>
            
            }
            
          </div>
      )
    }
    function RenderJouvertSections(){
      if(!band || !band.showJouvert) return <></>
      return(
          <div id="section-jouvert" className="col-12 my-3" >
            <h2>{band.name} at {band.dateName} {band.year} Jouvert Options</h2>
              {
                  (band.jImg && band.jImg.path) ? <img className="img-fluid " alt={band.name} src={generateAddressImg(band.jImg.path,560,315)} width="100%" height="auto" />
                      :
                  (band.jlImg && band.jlImg.path) ? <img className="img-fluid " alt={band.name} src={generateAddressImg(band.jlImg.path,560,315)} width="100%" height="auto" />
                      : ""
              }
            <div className="col-12 my-2">
              {band.jouvertTheme && <div  className="col"><span>Theme: {band.jouvertTheme}</span></div>}
              {band.jouvertLaunchDate && <div  className="col"><span>Launch Date: {band.jouvertLaunchDate}</span></div>}
              {band.jouvertDeadlineDate && <div  className="col"><span>Registration Deadline: {band.jouvertDeadlineDate}</span></div>}
            </div>
            {(festival && festival.jouvertStartDate && festival.jouvertEndDate)?
              <div className="col-12 my-2">
                <h3>When and Where is {band.dateName} Jouvert Parade Fete {band.year}</h3>
                <div>
                    <b>Date/Time</b>
                    <div>{festival.paradeS}</div>
                    <div>{festival.paradeE }</div>
                </div>
                {(festival.jouvertAddress)?
                  <div>
                    <b>Location</b>
                    <div className="col"><span>{festival.jouvertAddress}</span></div>
                  </div>:""
                }
              </div>:""
          }

            {/* show  jouvert services */}
            {jouvertServicesCheckbox}
            {/* list jouvert sections */}
            { jouvertSections && jouvertSections[0] && 
              <div className="col-12 my-2">
                <h3>{band.name}  Jouvert Sections {band.year}</h3>
                <div>
                  {jouvertSections.map( (section,index)=>{
                      return createSectionElement(section, index)
                  })}
                
                </div>   
              </div>
            
            }
            
          </div>
      )
    }
    function RenderChildrenSections(){
      if(!band || !band.showChildren) return <></>
      return(
          <div id="section-children" className="col-12 my-3" >
            <h2>{band.name} at {band.dateName} {band.year} Children Options</h2>
              {
                  (band.childrenImg && band.childrenImg.path) ? <img className="img-fluid " alt={band.name} src={generateAddressImg(band.childrenImg.path,560,315)} width="100%" height="auto" />
                      :
                  (band.childrenlImg && band.childrenlImg.path) ? <img className="img-fluid " alt={band.name} src={generateAddressImg(band.childrenlImg.path,560,315)} width="100%" height="auto" />
                      : ""
              }
            <div className="col-12 my-2">
              {band.childrenTheme && <div className="col"><span>Theme: {band.childrenTheme}</span></div>}
              {band.childrenLaunchDate && <div className="col"><span>Launch Date: {band.childrenLaunchDate}</span></div>}
              {band.childrenDeadlineDate && <div className="col"><span>Registration Deadline: {band.childrenDeadlineDate}</span></div>}
            </div>
            {(festival && festival.childrenStartD && festival.childrenEndD )?
              <div className="col-12 my-2">
                <h3>When and Where is {band.dateName} Children Parade Fete {band.year}</h3>
                <div>
                    <b>Date/Time</b>
                    <div>{festival.childrenEndD }</div>
                    <div>{festival.childrenStartD }</div>
                </div>
                {(festival.childrenParadeAddress)?
                 <div>
                    <b>Location</b>
                    <div className="col"><span >{festival.childrenParadeAddress}</span></div>
                  </div>:""
                }
              </div>:""
            }
            {/* show  children services */}
            {childrenServicesCheckbox}
            {/* list jouvert sections */}
            { childrenSections && childrenSections[0] && 
              <div className="col-12 my-2">
                <h3>{band.name}  Children Sections {band.year}</h3>
                <div>
                  {childrenSections.map( (section,index)=>{
                      return createSectionElement(section, index)
                  })}
                </div>   
              </div>
            
            }
            
          </div>
      )
    }

    function ContentGallery(){
      var content=[]
      if(!gallery || !gallery[0] ) return <></>
      for(let g of gallery){
          let img=g.imgs && g.imgs[0]
          if(!img) continue;
          
          let mime=img && img.mime
          if(!mime) continue;
          
          
          var images=[]
          if(g.imgs && g.imgs[0]){
            g.imgs.map((media)=>{
                media.img=(media.mime && media.mime.includes('video'))?media.path : generateAddressImg(media && media.path,1120,630)
                media.name=media.text
                images.push(media)
            })
          }
          const handleOnclick=(images=[],selected=null)=>{
              setSlideShow({...slideShow, images, type: "list", selected: selected, open: true})
                
          }
          content.push(
          <div>
              <div className='col-sm-12'>
              <h5>{g && g.title}</h5>
              <span>
                  {g && g.desc}
              </span>
              </div>
              <div className="my-2 row">
              {images.map((img)=>{
                  let mime=img.mime
                  return(
                  <div key={img._id} className="col-sm-4 pointer" onClick={(e)=>{e.preventDefault(); handleOnclick(images,img._id)}} >
                      {(mime.includes("video"))?
                      <video className="img-fluid my-1" width='100%' controls> <source src={img && img.path} type={mime}/></video>:
                      <img className='img-fluid my-1' src={img.img}/>}
                  </div>
                  )
              })}
              </div>
              <b className="pointer" onClick={(e)=>{e.preventDefault(); handleOnclick(images,null)}}>  View Gallery </b> 
          </div>
          )
      }
        if(content && content[0]){
            return(
                <section id="section-gallery" className="py-2" >
                    <h4>Photos and Video Gallery</h4>
                    <div className='d-flex flex-column mt-2'>
                        {content}
                    </div>
                </section>
            )
          } 
          else return <></>
    }

    function ContentNews(){
      if(!news || !news[0]) return <></>
      const content=[]
      news.map((index)=>{
        var href=(index && index.slug)?`/blogs/${index.slug}`: " "
        content.push(
          <li key={href}><a className="py-1" href={href}>{index.title}</a></li>
        )
      })
      return(
        <div id="section-news">
        <div className="py-2">
          <h2 className="text-capitalize">
            {band && band.name} News 
          </h2>
          <ul key="newsKey">
            {content}
          </ul>
        </div>
      </div>
      )
    }
    function ContentPastExperience(){
      if(!pastExperience || !pastExperience[0]) return <></>
      const content=[]
      for(var pastBand of pastExperience){
        var imgSrc=pastBand.mainImg && pastBand.mainImg.path
        if(!imgSrc)imgSrc=pastBand.imgs  && pastBand.imgs[0] && pastBand.imgs[0].path
        var types=[]
        if(pastBand.isChildrenService)types.push('Children')
        if(pastBand.isJouvertService)types.push('Jouvert')
        if(pastBand.isCustomeService)types.push('Adult')
        content.push(
          <li className="list-group py-2"  key={pastBand &&  pastBand.slug}>
              <div className="row" >
                  <Link to={`/bands/${pastBand.slug}`} className="col-3">   
                  <LazyLoadImage
                      src={(imgSrc)?generateAddressImg(imgSrc,560,315):profilePicture}
                      className="img-fluid"
                  />      
                  </Link>
                  <div className="col-9">
                      <Link to={`/bands/${pastBand.slug}`}>
                          <h4 className="">
                              {pastBand.name} {pastBand.year} 
                          </h4>
                      </Link>
                      <div>
                        <span>{pastBand.dateName}  
                        {/* {(pastBand.theme)?' > '+pastBand.theme :''} */}
                        </span>
                      </div>
                      <div>
                        {(types && types[0])?'Type > '+types.toString():""}
                      </div>
                      <div>
                          <span>
                              {(pastBand.score)?'Score: '+ pastBand.score+'/10':""} 
                              {
                              (pastBand.avgScore)?
                                  (pastBand.score)?' | UR ' + pastBand.avgScore:'UR '+ pastBand.avgScore
                              :""} 
                              {(pastBand.avgScore)?
                                      <GrStar size={25} style={{ color: '#ffeb3b', verticalAlign:"middle"}} />
                              :""}
                          </span>
                      </div>
                  </div>
              </div>
          </li>
        )
      }
      return(
        <div id="section-experience">
          <h2>{band.name} Past Years Experience</h2>
          <ul className="list-group list-group-flush mt-2" id="section-bandDates">
            {content}
          </ul>
        </div>
      )
    }
    function QuickState(){
      var text=''
      if(costumeSections && costumeSections[0]) text+=`Adult Costume [${costumeSections.length}] `
      if(childrenSections && childrenSections[0]) text+=`Children Costume [${childrenSections.length}] `
      if(jouvertSections && jouvertSections[0]) text+=`Jouvert [${jouvertSections.length}] `
      if(day2Sections && day2Sections[0]) text+=`Day II [${day2Sections.length}] `
      if(text == '')return <></>
      return (
        <div className="py-2">
          <h5>Quick Stats: {text}</h5>
        </div>
      )
    }

    return (
      <React.Suspense fallback={<div style={{position: "fixed", top: "50%", left: "50%", transform: "translate(-50%, -50%)"}}>
        <FadeLoader size={150}/></div>}>
        <LoadingOverlay  
          active={loading}
          spinner={<FadeLoader/>}
          fadeSpeed={200}
          styles={{ wrapper: { width: "100%", height: "100%" } }} 
        >
          <Slideshow images={slideShow.images} open={slideShow.open} type={slideShow.type} 
            handleAction={handleActionSlide} selected={slideShow.selected} sectionIndex={slideShow.sectionIndex} 
            continuous={slideShow.continuous} dialogTitle={slideShow.dialogTitle}
            sectionsList={sectionsList} handleSliderChooseSection={handleSliderChooseSection}
          />
            {band &&
                <section className="container" style={{overflowY: "hidden"}}>
                    {fixNavBar ?
                        <div style={{ backgroundColor: '#00A1AF', position: "fixed", zIndex: "1000", width: `${navWidth}px` }}>
                            <div className=" text-white">
                                <div className="d-flex align-items-center">
                                    <a onClick={scrollLeft} className="float-left btn d-block d-sm-none " style={{ left: '0' }}><i className="fa fa-chevron-left"></i></a>
                                    <div className="d-flex align-items-center" style={{ overflowX: "auto", height: "40px", overflowY: "hidden" }} ref={menuRef}>
                                      <CreateNavbar/>
                                    </div>
                                    <a className="float-right btn d-block d-sm-none" onClick={scrollRight} style={{ right: '0' }}><i className="fa fa-chevron-right"></i></a>
                                </div>
                            </div>
                        </div> : ''
                    }
                    {/* <Slideshow images={lineImages} open={open} handleAction={handleAction} type="list" selected={selectedImage}/> */}
                    <h1 className="pt-3 font-weight-bold">{band.name} at {band.dateName} {band.year}</h1>
                    <Advertisement slot="6887070145"/>
                    <div className="mb-2">
                      <RateSection
                        score={(avgScore == 0 || !avgScore) ? false : avgScore.toFixed(1)}
                        ur={band && band.avgScore} // user review 
                        wishlist={userExists}
                        compare={`/bands/compare/${band.slug}`}
                        share
                        link={`/bands/${band.slug}`}
                        text={`${band.name} at ${band.dateName} ${band.year}`}
                        collName="Band"
                        docID={band._id}
                      />
                    </div>
                    {(band && band.mainImg) ?
                      <>
                        <img className="img-fluid d-none d-xl-block" alt={band.name} src={generateAddressImg(band.mainImg.path,1120,630)} width="100%" height="auto" />
                        <img className="img-fluid d-none d-lg-block d-xl-none" alt={band.name} src={generateAddressImg(band.mainImg.path,960,540)} width="100%" height="auto" />
                        <img className="img-fluid d-none d-md-block d-lg-none" alt={band.name} src={generateAddressImg(band.mainImg.path,720,405)} width="100%" height="auto" />
                        <img className="img-fluid d-none d-sm-block d-md-none" alt={band.name} src={generateAddressImg(band.mainImg.path,560,315)} width="100%" height="auto" />
                        <img className="img-fluid d-block d-sm-none" alt={band.name} src={generateAddressImg(band.mainImg.path,560,315)} width="100%" height="auto" />
                      </>
                        :
                        (rawBand && rawBand.img) ?
                            <>
                                <img className="img-fluid d-none d-xl-block" alt={band.name} src={generateAddressImg(rawBand.img.path,1120,630)} width="100%" height="auto" />
                                <img className="img-fluid d-none d-lg-block d-xl-none" alt={band.name} src={generateAddressImg(rawBand.img.path,960,540)} width="100%" height="auto" />
                                <img className="img-fluid d-none d-md-block d-lg-none" alt={band.name} src={generateAddressImg(rawBand.img.path,720,405)} width="100%" height="auto" />
                                <img className="img-fluid d-none d-sm-block d-md-none" alt={band.name} src={generateAddressImg(rawBand.img.path,560,315)} width="100%" height="auto" />
                                <img className="img-fluid d-block d-sm-none" alt={band.name} src={generateAddressImg(rawBand.img.path,560,315)} width="100%" height="auto" />
                            </>
                            :
                            ""
                    }
                    <div>
                      <Divider style={{ backgroundColor: "rgba(255, 255, 255, 0.68)" }} />
                      <div className="mt-3" style={{ backgroundColor: '#00A1AF' }} ref={navRef}>
                          <div className="text-white">
                              <div className="d-flex align-items-center">
                                  <a onClick={scrollLeft} className="float-left btn d-block d-sm-none " style={{ left: '0' }}><i className="fa fa-chevron-left"></i></a>
                                  <div className="d-flex align-items-center" style={{ overflowX: "auto", height: "40px", overflowY: "hidden" }} ref={menuRef2}>
                                    <CreateNavbar/>
                                  </div>
                                  <a className="float-right btn d-block d-sm-none" onClick={scrollRight} style={{ right: '0' }}><i className="fa fa-chevron-right"></i></a>
                              </div>
                          </div>
                      </div>
                    </div>
                    <div className="py-4" id="section-about">
                      <h2>About {band.name} at {band.dateName} {band.year}</h2>
                      {/* <div className="col-12">
                        {(band.theme ) &&
                            // <h5><b>Theme:</b>&nbsp;<i>{`${band.themeType}${band.themeType && band.theme && ` - ${band.theme}`}`}</i></h5>
                            <h5><b>Theme:</b>&nbsp;<i>{`${band.theme}`}</i></h5>
                          }
                        <h5><b>Launch:</b>&nbsp;{band && band.lDate}</h5>
                        <div className="d-flex">
                          {band && band.deposit &&
                            <h5><b>Deposit/Registration: </b>&nbsp;<i>{(band.rdCurrency && band.rdCurrency!="USD")?getSymbolCurrency(band.rdCurrency)+band.deposit+' '+band.rdCurrency+' ($'+convertToUSD(band.deposit,allCourenciesRates,band.rdCurrency)+' USD)':'$'+band.deposit+' USD' }</i> {(band.rdDate)?"by "+band.rdDate:""}</h5>}
                          {band && band.link && 
                          <Link to={{pathname:band.link}} style={{fontSize:'1.25rem',lineHeight:1.2}} target="_blank">&nbsp;Buy</Link>
                          }
                        </div>
                  
                        {band &&
                          <div className="d-flex">
                            <h5>
                              <b>Pricing:</b>&nbsp;
                              <i>
                                {getSymbolCurrency(linesCurrencyPrice)}{linesMinPrice} - {linesMaxPrice} {linesCurrencyPrice}
                                 {
                                  (linesCurrencyPrice=="USD"?null:"($"+convertToUSD(linesMinPrice,allCourenciesRates,linesCurrencyPrice)+" - "+convertToUSD(linesMaxPrice,allCourenciesRates,linesCurrencyPrice) +"  USD)")
                                } ($$$$) /
                              </i>
                            </h5>
                            <Link className="titleText" style={{fontSize:'1.25rem',lineHeight:1.2}} target={'_blank'} to="/pricing-learn-more">&nbsp;Learn More</Link>
                          </div>} 
                          
                        <h5><b>Quick Stats:</b>&nbsp;
                          <i>
                            {`${band && band.sections && band.sections > 1 ? `${band && band.sections} Sections` : `${band && band.sections} section`}`}
                            {band.reveller && `, Age of 50%+ ${band.reveller} yrs`}
                            {band.locals && `, Locals ${band.locals}%`}
                          </i>
                        </h5>
                        <h5 className="font-weight-bold titleText my-3"> {band.city && band.city.code}</h5>
                        {band.video && <video height="auto" width="100%" controls preload="metadata"><source src={band.video.path} /></video>}
                      </div> */}
                      <QuickState/>
                      <RenderOtherBands/>
                      <div className="col-12 mt-2" dangerouslySetInnerHTML={{ __html: band.desc }} />
                      <div className="col-12 mt-2" dangerouslySetInnerHTML={{ __html: bandDateDetails }} />

                    </div>
                    
                    
                    {/* {band && band.meta &&
                      <p className="font-italic font-weight-bold">{band.meta}</p>
                    } 
                    {
                      guides && guides.length > 0 &&
                      <div className="py-2" id="section-guides">
                          <h2 className="mb-2">{band.dateName} {band.year} Guides</h2>
                          <div className="col-12"  dangerouslySetInnerHTML={{ __html: festival && festival.guide }}></div>
                          <ul className="row" >
                              {guides.map((guide, gI) => (
                                <li key={gI} className="py-1 col-12">
                                  <a key={gI}  
                                  // style={{ color: "#00A1AF", fontWeight: "bold" }} 
                                  href={`/blogs/${guide.slug}`}>{guide.title}</a>
                                </li>
                              ))}
                          </ul>
                      </div>
                    }
                  */}

                    <a id="section-sections"></a>
                    <RenderAdultCostumeSections />
                    <RenderJouvertSections />
                    <RenderChildrenSections/>
                    {rawBand && rawBand.about &&
                      <>
                        <h3>{band.name} History {rawBand.foundY && <small>(Founded {rawBand.foundY})</small>}</h3>
                        <div className="col-12">
                          <div className="mt-3" dangerouslySetInnerHTML={{ __html: rawBand.about }} />
                        </div>
                      </>
                    }
                    <ContentGallery />
                    {
                      events && events.length > 0 &&
                      <>
                      <a id="section-events"></a>
                        <div className="py-2">
                          <h2>{`${band.name} at ${band.dateName} ${band.year} Events`}</h2>
                          <div className="col-12">
                              {events.length > 0 &&
                                  <div className="row titleText">
                                      {events.map((event, eI) => (
                                          <Link key={eI} to={`/events/${event.slug}`} className="col-12">
                                              <h5>
                                                  {`${event.name} ${event.sDate && event.name && '-'} ${event.sDate} ${event.vName && `@ ${event.vName}`}`}
                                              </h5>
                                          </Link>
                                      ))}
                                  </div>
                              }
                          </div>
                        </div>
                      </>
                    }
                    <ContentPastExperience/>
                    {
                      awards  && awards.length > 0 &&
                      <>
                        <a id="section-results"></a>
                        <div className="py-2">
                          <h2>{`${band.name} at ${band.dateName} ${band.year} Results`}</h2>
                          <div className="col-12" dangerouslySetInnerHTML={{ __html: band.resultText }} />
                          <div className="col-12">
                            {awards.map(award => (
                                <React.Fragment key={award._id}>
                                    {award.cats.map(category => (
                                        <React.Fragment key={category.title}>
                                            {category.positions.map((position, index) => (
                                                <React.Fragment key={index}>
                                                    {position.bands.map(band => band._id).includes(band._id) &&
                                                      <Link to={`/awards/${award.slug}`}>
                                                          <h5 className="titleText">
                                                              {ordinal(parseInt(position.position))} | {category.title} at {award.name} 
                                                          </h5>
                                                      </Link>
                                                    }
                                                </React.Fragment>
                                            ))}
                                        </React.Fragment>
                                    ))}
                                </React.Fragment>
                            ))}
                            {/* <h3>All {band.dateName} Results {band.year}</h3>
                            {awards.map(aw => (
                                    <React.Fragment key={aw._id}>
                                        {aw.cats.map((cat,index) => (
                                            <React.Fragment key={cat.title}>
                                              <Col key={index}>
                                                <Link to={`/awards/${aw.slug}`}>
                                                  <h5>{cat.title} - {aw.name}</h5>
                                                </Link>
                                              </Col>
                                            </React.Fragment>
                                        ))}
                                    </React.Fragment>
                                ))} */}
                          </div>
                      </div>
                      </>
                    }
                    <ContentNews/>

                    {/* {(band && band.isCustomeService) && 
                      <div className="py-4">
                        <h2 >{band.name} {band.year} Mas Costume Sections at {band.dateName} </h2>
                        <div className="col-12">
                          {servicesCheckbox}
                          <Divider className="my-3"/>
                          {band && band.sectionOptions ? band.sectionOptions : ''}
                        </div>
                      </div>
                    }
                    {costumeSections && Array.isArray(costumeSections) && costumeSections.length > 0 &&
                      <div className="py-4">
                        <h3>Mas Costume Options for {band.name} at {band.dateName} {band.year}</h3>
                        <div className="col-12">
                          <React.Suspense fallback={<div style={{position: "fixed", top: "50%", left: "50%", transform: "translate(-50%, -50%)"}}><FadeLoader size={150}/></div>}>
                            <LazyLoadComponent>
                              {costumeSections.map((section, index) => {
                                return createSectionElement(section, index)
                              })}
                            </LazyLoadComponent>
                          </React.Suspense>
                        </div>
                      </div>
                    } */}
                    {comparisons && comparisons.length > 0 &&
                        <div className="pt-4 pb-2">
                            <h2>{band.name} at {band.dateName} {band.year} Popular Comparisons</h2>
                            <div className="row">
                                {comparisons.map((compare, cI) => compare.sections && compare.sections[0] && compare.sections[1] &&
                                    <Compare sections={compare.sections} bandDateSlug={band.slug} key={cI}/>)
                                }
                            </div>
                        </div>
                    }
                    {/* <a id="section-jouverts"></a>
                    {(band && band.isJouvertService && 
                      <div className="py-4">
                        <h2 >{band.name} {band.year} Jouvert Sections</h2>
                        {(band && band.jImg&&  band.jImg.path && 
                        <div className="col-12 py-2">
                            <img src={generateAddressImg(band && band.jImg && band.jImg.path,1120,630)} className="img-fluid" />
                        </div>
                        )}
                        {(festival && festival.jouvert && 
                            <div className="col-12 my-2" dangerouslySetInnerHTML={{ __html: festival.jouvert }} />
                          )}
                        <div className="col-12">
                          {jouvertServicesCheckbox}
                        </div>
                      </div>
                    )}
                    {jouvertSections && Array.isArray(jouvertSections) && jouvertSections.length > 0 &&
                      <div className="py-4">
                        <h3>Jouvert Options for {band.name} at {band.dateName} {band.year}</h3>
                        <div className="col-12">
                          <React.Suspense fallback={<div style={{position: "fixed", top: "50%", left: "50%", transform: "translate(-50%, -50%)"}}><FadeLoader size={150}/></div>}>
                            <LazyLoadComponent>
                              {jouvertSections.map((section, index) => {
                                return createSectionElement(section, index)
                              })}
                            </LazyLoadComponent>
                          </React.Suspense>
                        </div>
                      </div>
                    }
                    {day2Sections && Array.isArray(day2Sections) && day2Sections.length > 0 &&
                      <div className="py-4">
                        <h3>Monday/Day 2 Options for {band.name} at {band.dateName} {band.year}</h3>
                        <div className="col-12">
                          <React.Suspense fallback={<div style={{position: "fixed", top: "50%", left: "50%", transform: "translate(-50%, -50%)"}}><FadeLoader size={150}/></div>}>
                            <LazyLoadComponent>
                              {day2Sections.map((section, index) => {
                                return createSectionElement(section, index)
                              })}
                            </LazyLoadComponent>
                          </React.Suspense>
                        </div>
                      </div>
                    }
                    {otherSections && Array.isArray(otherSections) && otherSections.length > 0 &&
                      <div className="py-4">
                        <h3>Other Options for {band.name} at {band.dateName} {band.year}</h3>
                        <div className="col-12">
                          <React.Suspense fallback={<div style={{position: "fixed", top: "50%", left: "50%", transform: "translate(-50%, -50%)"}}><FadeLoader size={150}/></div>}>
                            <LazyLoadComponent>
                              {otherSections.map((section, index) => {
                                return createSectionElement(section, index)
                              })}
                            </LazyLoadComponent>
                          </React.Suspense>
                        </div>
                      </div>
                    } */}
                    <a id="section-reviews"></a>
                    {
                      band.scores && band.scores.length > 0 &&
                      <section className="my-4">
                          <h2>{band.name} at {band.dateName} {band.year} Reviews/Scorecard</h2>
                          <div className="col-12">
                            <div style={{ backgroundColor: 'rgb(222,222,222)', padding: '1rem' }}>
                              <h4>
                                <b style={{ fontSize: '1.5rem' }}>{(avgScore!=0)?avgScore.toFixed(1):""}</b><small style={{ fontSize: '0.75rem' }}>{(avgScore!=0)?'/10':"- -"}</small> for {band.name} at {band.dateName} {band.year}
                              </h4>
                              <h5 className="font-weight-bold mt-4">Our Score breakdown</h5>
                              <h5>
                                This is the Hello Carnival Review and Scorecard for this band. 
                              </h5>
                              <h5>
                                  {band.scores.map(score => `${score.title} ${(score.score !=0)?score.score+'/10':"- -"}`).join(', ')}
                                  <sup className="titleText"><Link target={'_blank'} to="/how-are-costume-band-score"> How?</Link></sup>
                              </h5>
                              <div className="d-flex flex-row justify-content-around mt-2 align-items-center">
                                <h4 className="text-danger"><b>Take our Survey</b></h4>
                              </div>
                              <div className="row">
                                <div className="col-12 col-md-4 text-center">
                                  <Button onClick={() => handleScoreReviewSubmit('agree')} variant="outlined" color="primary">
                                      <AiOutlineLike style={{ fontSize: '3rem' }} />
                                      <span className="mt-2">Agree</span>
                                  </Button>
                                </div>
                                <div className="col-12 col-md-4 text-center">
                                  <Button onClick={() => handleScoreReviewSubmit('notsure')} variant="outlined" color="default">
                                      <span style={{ fontSize: '2rem' }}>Not sure</span>
                                  </Button>
                                </div>
                                <div className="col-12 col-md-4 text-center">
                                  <Button onClick={() => handleScoreReviewSubmit('disagree')} variant="outlined" color="secondary">
                                      <AiOutlineDislike style={{ fontSize: '3rem' }} />
                                      <span className="mt-2">Disagree</span>
                                  </Button>
                                </div>
                              </div>

                              <details >
                                <summary className="row mt-3 text-center">
                                  <div className="col-12 text-center">
                                    <h4 className="text-primary">
                                      View Survey Results
                                      <BsChevronCompactDown className="d-inline-block ml-2"></BsChevronCompactDown>
                                    </h4>
                                  </div>
                                </summary>
                                <div className="d-flex flex-row justify-content-around align-items-center">
                                  {band.agree >= 0 && <h5>
                                    Agree <b style={{ fontSize: '2rem' }}>{Math.round(((band.agree / (scoreReviewsSum)) * 100) || 0)}%</b>
                                  </h5>}
                                  {band.notsure >= 0 && <h5>
                                    Not sure <b style={{ fontSize: '2rem' }}>{Math.round(((band.notsure / (scoreReviewsSum)) * 100) || 0)}%</b>
                                  </h5>}
                                  {band.disagree >= 0 && <h5>
                                    Disagree <b style={{ fontSize: '2rem' }}>{Math.round(((band.disagree / (scoreReviewsSum)) * 100) || 0)}%</b>
                                  </h5>}
                                </div>
                              </details>
                            </div>
                          </div>
                      </section>
                    }
                    {
                    reviews && reviews.length > 0 &&
                      <div className="pt-2">
                        <h2>{band.name} at {band.dateName} {band.year} Reviews</h2>
                        {band.reviewText ? <h5 className="col-12 pb-2">
                          {band.reviewText}
                        </h5>: ""}
                        <div className="col-12">
                          {reviews.map(blog => (
                            <Link key={blog.slug} to={`/blogs/${blog.slug}`}>
                              <h5>{blog.title}</h5>
                            </Link>
                          ))}
                        </div>
                      </div>
                    }


                    {festival && festival.bestE && new Date() > new Date(festival.bestE) &&
                    <>
                    <div>
                      <BandReview
                        bandName={band.name}
                        dateName={band.dateName}
                        id={band._id}
                        fId={festival && festival._id}
                        year={festival && festival.year}
                        years={dynamics.years}
                        bands={dynamics.bands}
                        carnivals={dynamics.carnivals}
                        sections={dynamics.sections}
                        comments={comments}
                        thisBandInOtherFYs={thisBandInOtherFYs}
                        average={band.avgScore}
                      />
                      <a id="section-userreviews"></a>
                    </div>
                    </>
                    }
                </section >
            }
          </LoadingOverlay>
        </React.Suspense>
    )
}

export function SoldoutBadge({ number }) {
    number = number ? number : 0;
    return (
        <span className={`text-white badge ${number < 40 ? 'badge-success' : number < 80 ? 'badge-warning' : 'badge-danger'}`}>
            {number}% Sold Out
        </span>
    )
}
