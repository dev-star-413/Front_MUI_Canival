import {
    InputLabel, MenuItem, Select, TextField, InputAdornment
} from "@material-ui/core";
import { useState } from "react";

export default function LineForm({
    line, lineTypes, dynamics, editLine, lineIndex, sectionIndex
}) {
    const [ln, setLn] = useState(line);
    function editForm(e) {
        setLn({ ...ln, [e.target.name]: e.target.value });
        editLine(e.target.name, e.target.value, sectionIndex, lineIndex)
    }
    const textBoxStyles = {
        backgroundColor: 'rgb(256, 256, 256)'
    }
    return (
        <section>
            <div className="form-group my-3 col-12">
                <InputLabel>Line Type</InputLabel>
                <Select style={textBoxStyles} value={ln.type} fullWidth name="type" onChange={editForm} variant="outlined">
                    {lineTypes.map(type => <MenuItem value={type}>{type}</MenuItem>)}
                </Select>
            </div>
            <div className="form-group my-3 col-12">
                <InputLabel>Price</InputLabel>
                <TextField style={textBoxStyles} fullWidth type="number" value={ln.price} name="price" variant="outlined" InputProps={{
                    startAdornment: <InputAdornment position="start">$</InputAdornment>,
                    inputProps: { min: 0 }
                }} placeholder="USD" onChange={editForm} />
            </div>
            <div className="form-group my-3 col-12">
                <InputLabel>Available Style/Fit</InputLabel>
                <Select
                    style={textBoxStyles}
                    multiple
                    fullWidth
                    name="styles"
                    value={ln.styles}
                    onChange={editForm}
                    variant="outlined"
                    color="primary"
                >
                    {dynamics.styles.map(style => <MenuItem value={style}>{style}</MenuItem>)}
                </Select>
            </div>
            <div className="form-group my-3 col-12 d-none">
                <InputLabel>addOns/Upgrades</InputLabel>
                <TextField style={textBoxStyles} name="addOns" variant="outlined" InputProps={{
                    startAdornment: <InputAdornment position="start">$</InputAdornment>,
                }} placeholder="USD" onChange={editForm} value={ln.addOns} />
            </div>
            <div className="form-group my-3 col-12">
                <InputLabel>Links to purchase</InputLabel>
                <TextField style={textBoxStyles} type="url" fullWidth placeholder="Purchase" multiline variant="outlined" name="link"
                    value={ln.link} onChange={editForm} />
            </div>
            <div className="form-group my-3 col-12">
                <InputLabel>Sold out</InputLabel>
                <TextField style={textBoxStyles} type="number" fullWidth name="sold" variant="outlined" InputProps={{
                    startAdornment: <InputAdornment position="start">%</InputAdornment>,
                    inputProps: {
                        min: 0,
                        max: 100
                    }
                }} placeholder="Percentage" onChange={editForm} value={ln.sold} />
            </div>
        </section>
    )
}