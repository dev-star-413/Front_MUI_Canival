import React, { useState, useEffect } from 'react';
import { Link, useHistory } from "react-router-dom";
import {getLandingFestival, searchFestivals} from '../functions/api';
import { IoLocation, FaCalendarAlt } from "react-icons/all";
import generateAddressImg from '../functions/generateAddressImg';
import { LazyLoadImage,LazyLoadComponent } from 'react-lazy-load-image-component';
import FadeLoader from "react-spinners/FadeLoader";
import ReactCountryFlag from "react-country-flag"
import Signin from '../components/Signin'
import AwesomeDebouncePromise from 'awesome-debounce-promise';
import Autosuggest from 'react-autosuggest';
import { Card , CardHeader,Avatar } from '@material-ui/core';
import Rate from "react-rating-stars-component";
import ReviewForm from '../components/modal/ReviewForm'
import Carousel from "react-multi-carousel";
import "react-multi-carousel/lib/styles.css";
import { GrStar } from "react-icons/all";
import Advertisement from '../components/Advertisement';
import {defaultTheme} from 'react-autosuggest/dist/theme'
import {makeStyles} from '@material-ui/core/styles';
const searchAPIDebounced = AwesomeDebouncePromise(searchFestivals, 500);

const useStyle = makeStyles({
    suggestionsContainer: {
        maxHeight: '230px',
        overflowY: 'auto',
    }
});

export default function Landing() {
    const history=useHistory()
    const [landingData, setlandingData] = useState([])
    const [bands, setBands] = useState([]) // compare bands
    const [SearchCarnivals, setSearchCarnivals] = useState([]) // carnivals
    const [reviews, setReviews] = useState([]) // reviews
    const [search,setSearch]=useState('')
    const [openReviewForm,setOpenReviewForm]=useState(false)
    const theme = useStyle()
    const responsive = {
        desktop: {
          breakpoint: { max: 3000, min: 1024 },
          items: 4,
          slidesToSlide: 1 // optional, default to 1.
        },
        tablet: {
          breakpoint: { max: 1024, min: 464 },
          items: 3,
          slidesToSlide: 1 // optional, default to 1.
        },
        mobile: {
          breakpoint: { max: 464, min: 0 },
          items: 2,
          slidesToSlide: 1 // optional, default to 1.
        }
      };
    // component mounts from the DOM
    useEffect(function () {
        document.title = "Guides for Carnivals, Travel, fetes and Events"
    }, [])
    //component unmounts from the DOM
    useEffect(function () {
        return () => {
            document.title = "Hello Carnival"
        }
    }, [])
    useEffect(function () {
        loadData();
    }, [])
    const loadData = async () => {
        if (!landingData || !landingData[0]) {
            let data = await getLandingFestival()
            if(data) {
              var { dates, compareBands ,reviews} = data
              setlandingData(dates)
              setBands(compareBands)
              setReviews(reviews)
            } else {
              alert("Something went wrong. Please try again later.")
            }
        }
        // if(!landingCostum || !landingCostum[0]) setLandingCostum(await getCostumeBands())
    }
    // useEffect(function() {
    //     setBands(landingData && landingData[0] && landingData[0].bands)
    // },[landingData])
    function nextUp() {
        var next = []
        if (landingData && landingData[0]) {
            for (var i = 0; i < landingData.length; i++) {
                var src = landingData[i] && landingData[i].img && landingData[i].img
                src = src && src.path
                var link = landingData[i].festival?.slug ? `/festival/${landingData[i].festival.slug}` : '';
                next.push(
                    <div key={i} className="col-md-6 p-2">
                        {(landingData && landingData[0]) ?
                            <Link to={link}>
                                {/* <div style={{
                                    backgroundImage: `url("${src}")`, maxHeight: "50vh",
                                    backgroundPosition: "center", minHeight: "50vh",
                                    backgroundSize: "contain",backgroundRepeat:"no-repeat"
                                }}></div> */}
                                <LazyLoadImage className="img-fluid" src={generateAddressImg(src,560,315)} />
                                <div>
                                    <div className="d-flex flex-row align-items-center">
                                        {(landingData[i] && landingData[i].cityCode) ? <ReactCountryFlag countryCode={landingData[i].cityCode} svg style={{width: '48px', height:'48px'}}/>: ''}
                                        <h5 className="mx-2 mt-1 text-white">{landingData[i] && landingData[i].festival && landingData[i].festival.name}</h5>
                                    </div>
                                    <div className="flex flex-column" >
                                        <div className="d-flex flex-column mx-2" style={{ color: 'rgb(230, 230, 230)' }}>
                                            <small ><IoLocation className="mr-2 text-secondary" size={24} /><b>{landingData[i] && landingData[i].cityName}</b></small>
                                            <small className="mt-1"><FaCalendarAlt className="mr-2 text-secondary" size={20} />Parade: {landingData[i].paradeS}</small>
                                        </div>
                                    </div>
                                </div>
                            </Link>

                            : ''}
                    </div>
                )
            }
        }
        return (
            <React.Suspense fallback={<div style={{position: "fixed", top: "50%", left: "50%", transform: "translate(-50%, -50%)"}}><FadeLoader size={150}/></div>}>
                <LazyLoadComponent>
                    {next}
                </LazyLoadComponent>
            </React.Suspense>
        )
    }
    function cardCompare() {
        //first, second,cityCode,festivalName
        var content = []
        if (bands && bands[0]) {
          let key=-1;
            for (var coupleBands of bands) {
              key++;
                var first = coupleBands[0]
                var second = coupleBands[1]
                var firstImg = ''
                var sImg = ''
                if (first && first.section && first.section.img) firstImg = first.section.img.path
                else if (first && first.mainImg && first.mainImg.path) firstImg = first.mainImg.path
                // second img
                if (second && second.section && second.section.img) sImg = second.section.img.path
                else if (second && second.mainImg &&  second.mainImg.path) sImg = second.mainImg.path
                let fUrl = (first && first.section) ? first && first.slug + "~" + first.section._id : first && first.slug
                let sUrl = (second && second.section) ? second && second.slug + "~" + second.section._id : second && second.slug
                var compareUrl = '/bands/compare/' + fUrl + '/' + sUrl
                content.push(
                    <div className="col-lg-6 py-2" key={key}>
                        <div className="col-12 shadow-lg  rounded card bg-dark">
                            <div className="row" >
                                <div className="row">
                                    <div >
                                    </div>
                                    <div className="d-flex align-items-center px-2">
                                        <h4>
                                            {/* {festivalName} */}
                                        </h4>
                                    </div>
                                </div>

                            </div>
                            <div className="row">
                                <div className="col-5 ">

                                    <div className=" p-1">
                                        {/* <div style={{
                                            maxHeight: "200px", maxWidth: '200px', backgroundImage: `url(${firstImg})`,
                                            backgroundSize: 'contain',backgroundRepeat:"no-repeat",
                                            backgroundPosition: 'center', height: '40vh'
                                        }} >
                                        </div> */}
                                        <LazyLoadImage className="img-fluid" src={generateAddressImg(firstImg,195,260)}/>

                                        <div className="  p-2">
                                            <Link className="text-white" to={'/bands/' + (first && first.slug)}>
                                                <span  >{first && first.name} </span>
                                            </Link>
                                        </div>
                                    </div>
                                </div>
                                <div className="col-2 d-flex justify-content-center align-items-center">
                                    <span style={{ fontSize: "1.5rem", fontWeight: "bold" }}>VS.</span>
                                </div>
                                <div className="col-5 ">
                                    <div className=" p-1 d-flex  flex-column">
                                        {/* <div style={{
                                            maxHeight: "200px", maxWidth: '200px', backgroundImage: `url(${sImg})`,
                                            backgroundSize: 'contain',backgroundRepeat:"no-repeat",
                                            backgroundPosition: 'center', height: '40vh'
                                        }} >
                                        </div> */}
                                        <LazyLoadImage className="img-fluid float-right" src={generateAddressImg(sImg,195,260)}/>
                                        <div className="  p-2">
                                            <Link className="text-white" to={'/bands/' + second.slug}>
                                                <span >{second && second.name}</span>
                                            </Link>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div className=" justify-content-center py-3">
                                <div className="text-center">
                                    <span className="text-uppercase btn btn-secondary">
                                        <Link  to={compareUrl} className="px-2 text-white" style={{ fontWeight: 'bold' }}>
                                            compare now
                                        </Link>
                                    </span>
                                </div>
                            </div>
                        </div>
                    </div>

                )
            }
        }
        return (
            <React.Suspense fallback={<div style={{position: "fixed", top: "50%", left: "50%", transform: "translate(-50%, -50%)"}}><FadeLoader size={150}/></div>}>
                <LazyLoadComponent>
                {content}
                </LazyLoadComponent>
            </React.Suspense>
        )

    }

    function onChangeSearch  (event, { newValue })  {
        setSearch(newValue)
    };

    // Autosuggest will call this function every time you need to update suggestions.
    // You already implemented this logic above, so just use it.
    async function onSuggestionsFetchRequested  ({ value })  {
        if (value.length < 3) {
            setSearchCarnivals([{name: 'Please enter at least three characters'}])
            return;
        }
        let find = await searchAPIDebounced(value)
        var data=find && find.data
        data = data && data.festivals
        if (!data[0]) data=[{name:'The filter returned no results'}]
        setSearchCarnivals(data)
    };

    // Autosuggest will call this function every time you need to clear suggestions.
    function onSuggestionsClearRequested  (val)  {
        setSearchCarnivals([])
    };
    function getSuggestionValue(item){
        var name = item.name
        setSearch(name)
        return name
    }
    function onSuggestionSelected(event, { suggestion, suggestionValue, suggestionIndex, sectionIndex, method }){
            history.push('/festival/'+suggestion.slug)
    }

    function renderSuggestion(item){
        return (
            <div>
                {item && item.name}
            </div>
        )
    }
    const inputProps={
        placeholder: 'Carnival Name?',
        value:search,
        onChange:onChangeSearch,

    }
    const reviewsSection =()=>{
        if(!reviews || !reviews[0]) return
        var cards=[]
        for(var rev of reviews){
            const avatar=<img src={rev.avatar} /> 
            cards.push(
                <Card className=' m-2  '>
                    <CardHeader 
                            avatar={
                                <Avatar  aria-label="recipe">{avatar}</Avatar>
                            }
                            title={
                                rev.score && rev.score.avg &&
                                <>
                                {Number(rev.score.avg).toFixed(1)}
                                <GrStar size={25} style={{ color: '#ffeb3b', paddingBottom: "3px" }} />
                                </>
                            }
                            subheader={
                                    <>
                                        {/* <Rate size={18} value={rev.score && rev.score.avg} edit={false} /> */}
                                        <small><b>{rev.band?'Band: '+rev.band:''}{(rev.festival?', '+rev.festival+' '+rev.year || '':"")}</b></small>
                                    </>
                                }
                        />
                    <small><b></b></small>
                    <p  className='container' title={rev && rev.comment}> {/** style={{textOverflow:"ellipsis",overflow:"hidden",width:'100%',whiteSpace:"pre-wrap"}} too long text... */}
                        {(rev && rev.comment && rev.comment.length >128)?rev.comment.slice(0,128)+'...':rev.comment}
                    </p>
                </Card>
            )
        }
        return (
            <div id='section-reviews' style={{backgroundColor: 'rgb(230, 230, 230)' }}>
                <h3 className='container pt-5'>RECENT REVIEWS</h3>
                <div className=' py-2'>
                    <Carousel
                        swipeable={false}
                        draggable={false}
                        responsive={responsive}
                        // ssr={true} // means to render carousel on server-side.
                        infinite={true}
                        autoPlay={true}
                        autoPlaySpeed={4000}
                        customTransition="all .5"
                        transitionDuration={100}
                        containerClass="carousel-container"
                        removeArrowOnDeviceType={["mobile"]}
                        itemClass="carousel-item-padding-40-px"
                        >
                        {cards}
                    </Carousel>
                </div>
            </div>
        )
    }
    const handleOpenReviewForm=()=>{
        setOpenReviewForm(true)
    }
    const handleCloseReviewForm=()=>{
        setOpenReviewForm(false)
        
    }
    return (
        <div>
            <span className="p-2"> <b>Content Loading...</b>Beta version 3.1 </span>
            <Advertisement slot="6887070145"/>

            <div style={{ backgroundColor: "#181716" }} >
                {/* <h1 className="text-white" style={{backgroundColor:"#181716"}}>Festival</h1> */}
                <div className="col-12 d-flex flex-column  justify-content-center align-items-center text-white"
                    style={{ minHeight: 'calc(60vh - 3.5rem)' }}>
                    <span style={{ fontSize: "2rem" }}>Welcome</span>
                    <span style={{ fontSize: "2rem" }}>to</span>
                    <h1>HelloCarnival</h1>
                    <span style={{ color: "orange" }}>Your Ultimate Guide for the Best Travel and Carnival Experience!</span>
                    <div className="col-xl-4 col-sm-6  d-flex flex-column m-3 justify-content-center  ">
                        <Autosuggest
                            suggestions={SearchCarnivals}
                            onSuggestionsFetchRequested={onSuggestionsFetchRequested}
                            onSuggestionsClearRequested={onSuggestionsClearRequested}
                            getSuggestionValue={getSuggestionValue}
                            onSuggestionSelected={onSuggestionSelected}
                            renderSuggestion={renderSuggestion}
                            inputProps={inputProps}
                            theme={{...defaultTheme, suggestionsContainer: theme.suggestionsContainer}}
                        />
                    </div>
                </div>

            </div>
            <div style={{ backgroundColor: 'rgb(230, 230, 230)', minHeight: '50vh' }} >
                <div className='container py-5'>
                    <div className="pb-3 text-center">
                        <h3>WHO WE ARE</h3>
                        <p>
                            We are the world’s leading Carnivals hub and selection platform Celebrating Caribbean culture through food,
                            music, and the arts.<br /> We will help you find the right [event, costume, _____________ or whatever]
                            for that awesome Carnival experience.
                        </p>
                    </div>
                    <div className="row" >
                        <div className="col-md-6 col-sm-12  py-3">
                            <h3>
                                GET THE FACTS
                            </h3>
                            <span>
                                You are using the most detailed carnival hub and data bank with the latest carnival information.
                            </span>
                            <br />
                        </div>
                        <div className="col-md-6 col-sm-12 py-3">
                            <h3>
                                EXPLORE REVIEWS
                            </h3>
                            <span >
                            Read HelloCarnival editorial reviews and scorecard or the reviews from thousands of carnivalist like you. Be heard,<a href='#' onClick={handleOpenReviewForm}> write a Carnival Review</a>, and share an experience that matters.
                            </span>
                        </div>
                        <div className="col-md-6 col-sm-12  py-3">
                            <h3>
                                GET SUGGESTIONS
                            </h3>
                            <span>
                                Get personalized costume suggestions, find the best events, compare options and save to your dashboard for later.                             </span>
                            <br />
                        </div>
                        <div className="col-md-6 col-sm-12 py-3">
                            <h3>
                                FIND FOOD
                            </h3>
                            <span>
                                Find local eats or food on your parade route. Use our map to locate hidden tasty menus.                            </span>
                        </div>
                    </div>
                </div>
                <ReviewForm open={openReviewForm} handleClose={handleCloseReviewForm} />
            </div>
            <div style={{ backgroundColor: "#00A1AF" }}>
                <div className="container py-5 d-flex flex-column  justify-content-center" style={{ minHeight: '50vh' }}>
                    <div className="text-center text-white">
                        <p style={{ color: 'rgb(230, 230, 230)' }}>
                            100s... of events and fetes to choose, mas costumes to see and much more.
                            <br />Add to your watch list, set an alert and be in the know.
                        </p>
                        <br />
                        {(!localStorage.token)?
                            <Signin  btnTitle="Signup Now"   />
                            :""
                        }
                  
                    </div>
                </div>
            </div>
            {reviewsSection()}
            <div id="section-compare" style={{ backgroundColor: '#181716' }}>
                <h3 className='text-white container pt-5'>COMPARE COSTUMES</h3>
                <div className="container text-white  d-flex flex-column justify-content-center py-2">
                    <h5>Compare Choices side by side</h5>
                    <p>Get the lowdown on the costume bands you are looking at.
                        See the pros and cons with features, pricing and more.
                        <br />See some popular comparison below or <Link className='text-secondary' to='/bands/compare'>build your own</Link>.
                    </p>
                    <div className="row py-5 justify-content-between">
                        {cardCompare()}
                        {/* <div className="col-lg-6 py-2" >
                        {(bands && bands[0])?
                        cardCompare( bands[0])
                    :''
                        }
                    </div>
                    <div className="col-lg-6 py-2 ">
                        { (bands && bands[1])?
                        cardCompare(bands[1])
                            : ''
                        }   
                    </div> */}
                    </div>
                </div>
            </div>
            <div id="section-resources" style={{ minHeight: "50vh", backgroundColor: 'rgb(230, 230, 230)' }}>
                <h3 className="container pt-5">RESOURCES</h3>
                <div className="container   d-flex flex-column  justify-content-center ">
                    <h5> Simplify your search for the Best Carnival experience.</h5>
                    <span>Don’t know where to start? Then begin with our full detailed wall to wall <a className="text-primary" href="/festivals" >Guide</a> on how to have the Best Carnival Experience. </span>
                    <div className=" justify-content-center pt-5">
                        <div className="text-center">
                            <span className="text-uppercase">
                                <a href="#" className="px-2" style={{ fontWeight: 'bold' }}>
                                    READ ARTICLE
                                </a>
                                |
                                <a href="/blogs" className="px-2" style={{ fontWeight: 'bold' }}>
                                    GO TO OUR BLOG
                                </a>
                            </span>
                        </div>
                    </div>
                </div>
            </div>
            <div id="section-upNext" style={{ backgroundColor: "#181716" }}>
                <h3 className="container pt-5  text-white">UP NEXT</h3>
                <div className="container py-2">
                    <div className="row ">
                        {nextUp()}

                    </div>
                    <div className="row justify-content-center py-5">
                        <div className="text-center text-white">
                            <span className="text-uppercase">
                                <a href="/festivals" style={{ fontWeight: 'bold' }}>
                                    view all carnival dates
                                </a>
                            </span>
                        </div>
                    </div>

                </div>
            </div>
            <div id="section-affiliate" style={{ backgroundColor: "#00A1AF" }}>
                <div className="container d-flex flex-column  justify-content-center py-5 " style={{ minHeight: '50vh' }}>
                    <div className="text-center text-white">
                        <p style={{ color: 'rgb(230, 230, 230)' }}> Affiliate Disclaimer: We work very hard to create the content on our website.
                            We attempt to make some coins in exchange for our efforts by adding links to various products.
                            Assume we are compensated from these affiliate links. If you choose to click and buy, we thank you.
                            It helps to keep us in business.
                        </p>
                    </div>

                </div>
            </div>
        </div>
    )
}
