import "../../assets/styles/Festival.css";
import { Link } from "react-router-dom";
import { useState, useEffect } from "react";
import { getDesigner } from "../../functions/api";
import generateAddressImg from "../../functions/generateAddressImg";
import "@fortawesome/fontawesome-free/css/all.css"

export default function Designer({ match }) {
    const [designer, setDesigner] = useState(null);
    const [sections, setSections] = useState([]);
    const [years, setYears]=useState([])
    useEffect(function () {
        loadData();
    },[]);
    const loadData = async () => {
        if (!designer) {
            let data=await getDesigner(match.params.designerid)
            var designerTemp = data ? data.designer : []
            var sections = data ? data.sections : []
            let sectionsYears = Object.keys(sections)
            sectionsYears = sectionsYears.sort()
            setYears(sectionsYears)
            setDesigner(designerTemp);
            setSections(sections);

        }
    }
    const hr = {
        color: '#292b2c ',
        backgroundColor: '#292b2c ',
        height: 1,
    }

    function createSectionElement(section) {
      return (
        <Link className="row col-12" key={section._id} to={"/bands/" + section.bandDate.slug + "#section-sections"}>
          <div className="col-3 mb-3">
            <img
              src={generateAddressImg(section && section.img && section.img.path,45,45)}
              className="img-fluid d-inline-block d-sm-none"
            />
            <img
              src={generateAddressImg(section && section.img && section.img.path,240,240)}
              className="img-fluid d-none d-sm-block"
            />
          </div>
          <div>
            <h3>
              {section.name}
            </h3>
            <span className="text-secondary">
              {section.average}&nbsp;
              <i className="fa fa-fire fa-lg" style={{ color: 'rgb(255, 100, 0)' }}></i>&nbsp;
              {section.bandDate.dateName}&nbsp;
              {section.bandDate.year}&nbsp;
              {'>'}&nbsp;
              {section.bandDate.name}
            </span>
          </div>
        </Link>
      )
    }

    function sectionsYear(year){
        var content=[]

        let sectionsYear=sections[year]
        if(sectionsYear && sectionsYear[0]){
            for(let section of sectionsYear){
                content.push(
                  createSectionElement(section)
                )
            }
        }

            
        return (
            <div>
                <h2> {year} Designs </h2>
                <div className="d-flex flex-column">
                    {content}
                </div>
            </div>
        )
    }
    function showYears() {
        var content=[]
        if(years && years[0]){
            for(var year of years){
                content.push(sectionsYear(year))
            }
        }
        return content
    }

    if (designer) {
        var page = (
            <>
                <h2 className="mt-4">{designer.coName}</h2>
                <h1>{designer.name}</h1>
                <hr style={hr} />
                <div className="fadedDiv">
                    {/* <div className="bandPicture mb-4 shadow-lg" style={{ backgroundImage: `url('${designer && designer.img && designer.img.path}')`, height: "40vw", width: "100%" }} /> */}
                    <img className="img-fluid" src={generateAddressImg(designer && designer.img && designer.img.path,1120,630)}/>
                </div>
                <h5 className="titleText font-weight-bolder">About</h5>
                <p className="text-dark text-justify" dangerouslySetInnerHTML={{ __html: designer.about }} />
                <hr style={hr} />
                {showYears()}
            </>
        )
    }
    return (
        <div className="container">
            {page}
        </div>
    )
}
