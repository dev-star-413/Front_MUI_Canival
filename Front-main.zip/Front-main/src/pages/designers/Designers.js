import { useState, useEffect } from "react";
import { getDesigners } from "../../functions/api";
import { Link } from "react-router-dom";
import generateAddressImg from '../../functions/generateAddressImg'
import { LazyLoadImage } from 'react-lazy-load-image-component';
import {TextField, Radio, RadioGroup, FormControlLabel, FormControl, FormLabel } from "@material-ui/core";
import Popover from "../../components/Popover";
import { MdSort } from "react-icons/all"
import AwesomeDebouncePromise from 'awesome-debounce-promise';
import profilePicture from "../../assets/imgs/image-not-found.jpg";
const getDesignersDebounced = AwesomeDebouncePromise(getDesigners, 500);

export default function Designers() {
  const [designers, setDesigners] = useState(null);
  const [search, setSearch] = useState("");
  const [sort, setSort] = useState("year");
  const [sortsOpen, setSortsOpen] = useState(false);
  
  async function submit({sort, search}, debounced) {
    let queryString = new URLSearchParams({sort, q: search}).toString();
    let url = window.location.protocol + "//" + window.location.host + window.location.pathname + "?" + queryString;
    window.history.pushState({path:url},'', url);
    if(debounced) {
      setDesigners(await getDesignersDebounced(window.location.search));
    } else {
      setDesigners(await getDesigners(window.location.search));
    }
  }
  
  useEffect(async function () {
    setDesigners(await getDesigners(window.location.search));
    let params = new URLSearchParams(window.location.search);
    let search = params.get("q") || "";
    setSearch(search)
    let sort = params.get("sort") || "year";
    setSort(sort)
  }, []);

  async function sortChange(e) {
    console.log()
    setSort(e.target.value || "year")
    setSortsOpen(false);
    await submit({sort: e.target.value, search}, false)
  }

  async function searchChange(el) {
    let val = el.target.value
    setSearch(val)
    await submit({sort, search: val}, true)
  }

  const sortContent = <FormControl component="fieldset">
    <ul className="list-group list-group-flush">
      <li className="list-group-item">
        <FormLabel className="pt-3" component="legend">Sort designers</FormLabel>
      </li>
      <li className="list-group-item">
        <RadioGroup name="sort" value={sort} onChange={sortChange}>
          <FormControlLabel value="year" control={<Radio color="primary" />} label="Recent years at the top" />
          <FormControlLabel value="az" control={<Radio color="primary" />} label="A-Z" />
        </RadioGroup>
      </li>
    </ul>
  </FormControl>

  return (
    <div className="container">
      <h1 className="text-dark mt-4">Carnival Costume Designers</h1>
      <div className="d-flex flex-row justify-content-between align-items-center flex-wrap">
        <TextField placeholder="Search designers" label="Search designers" 
          variant="outlined" size="small" onChange={searchChange} value={search || ""}/>
        <Popover handleOpen={() => setSortsOpen(true)} handleClose={() => setSortsOpen(false)} open={sortsOpen}
          item={<span className="rateSectionItem"><MdSort />&nbsp;Sort</span>} id="sort" content={sortContent} />
      </div>

      <ul className="list-group list-group-flush mt-3">
        {designers && designers[0] && designers.map((designer, index) => {
          let aboutSummary = (designer.about && designer.about.length > 250) ? designer.about.substr(0, 250) + "..." : designer.about
          return (
            <li className="list-group-item" key={index}>
                <Link className="row" to={`/designers/${designer.slug}`}>
                    {designer.img ?
                      <div className="col-3 pl-0">
                        <LazyLoadImage
                          src={generateAddressImg(designer.img.path,560,315)}
                          className="img-fluid"
                        />
                      </div>
                    : <div className="col-3 pl-0">
                        <LazyLoadImage
                          src={profilePicture}
                          className="img-fluid"
                        />
                      </div>
                    }
                    <div className="col-9 px-0">
                        <h3>
                            {designer.name}
                        </h3>
                        {aboutSummary && 
                          <p className="mt-4 text-dark text-justify" dangerouslySetInnerHTML={{ __html: aboutSummary }} />
                        }
                    </div>
                </Link>
            </li>
          )
        })}
      </ul>
    </div>
  )
}