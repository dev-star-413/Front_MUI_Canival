import { Card } from "@material-ui/core";
import { useEffect, useState } from "react";
import Title from "../components/Festival/FestivalTitle";
import { getFaqs } from "../functions/api";

export default function FAQ() {
    const [faqs, setFaqs] = useState(null);
    useEffect(function () {
        loadData();
    });
    const loadData = async () => {
        if (!faqs) {
            setFaqs(await getFaqs());
        }
    }
    const items = [];
    if (faqs) {
        for (var faq of faqs) {
            items.push(<h3>{faq.category}</h3>);
            faq.faqs.map(faq =>
                items.push(
                    <Card className="my-2">
                        <div className="py-3 px-4">
                            <h4 className="titleText" dangerouslySetInnerHTML={{ __html: faq.q }} />
                            <p className="text-dark my-4 px-4" dangerouslySetInnerHTML={{ __html: faq.a }} />
                        </div>
                    </Card>
                )
            )
        }
    }
    return (
        <div className="container">
            <Title page="Frequently Asked Questions (FAQs)" />
            {items}
        </div>
    )
}