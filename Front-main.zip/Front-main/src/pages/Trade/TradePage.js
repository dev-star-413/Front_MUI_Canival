import { Button } from "@material-ui/core";
import RateSection from "../../components/Festival/RateSection";
import { Link } from "react-router-dom";
export default function Trade() {
    const hr = {
        color: '#292b2c ',
        backgroundColor: '#292b2c ',
        height: 1,
    }
    return (
        <div className="container">
            <h2 className="font-weight-bold text-dark mt-3">Buy/Sell/Trade</h2>
            <Link to="/trade/form">
                <Button variant="outlined" color="primary">Post Yours</Button>
            </Link>
            <RateSection search filter />
            <hr style={hr} />
            <div className="card w-100 my-1 card-item">
                <div className="card-body">
                    <h4>Carnival l Tickets for Sale</h4>
                    <h6>(Carnival A)</h6>
                </div>
            </div>
            <div className="card w-100 my-1 card-item">
                <div className="card-body">
                    <h4>Carnival House for Sale</h4>
                    <h6>(Carnival D)</h6>
                </div>
            </div>
        </div>
    )
}