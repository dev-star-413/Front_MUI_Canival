import { Button, Checkbox, Divider, FormControlLabel, InputAdornment, InputLabel, MenuItem, Select, TextField } from "@material-ui/core";
import { useEffect, useState } from "react";
import { createPost, getFestivalsList } from "../../functions/api";


export default function TradeForm() {
    const list = [];
    const [data, setData] = useState({
        title: null, // string
        festivals: null, // array of object
        type: null, // string
        price: null, // number
        desc: null, // string
        eDate: null, // date
        private: false, // boolean
        contact: null // string
    });
    const [festivals, setFestivals] = useState(null);
    useEffect(function () {
        loadData();
    });
    const loadData = async () => {
        if (!festivals) {
            setFestivals(await getFestivalsList());
        }
    }
    function handleChange(event) {
        if (event.target.name === "private") {
            setData({ ...data, [event.target.name]: event.target.checked });
        } else {
            setData({ ...data, [event.target.name]: event.target.value });
        }
    }
    function submit() {
        createPost("trade", data);
    }
    if (festivals) {
        for (let festival of festivals) {
            list.push(
                <MenuItem value={festival._id}>{festival.name}</MenuItem>
            )
        }
    }
    return (
        <div className="container my-5">
            <div className="card shadow-lg">
                <div className="card-body">
                    <h3 className="titleText mb-4">ADD/EDIT BUY/SELL/TRADE</h3>
                    <Divider />
                    <form>
                        <div className="col-lg-6"></div>
                        <div className="col-lg-6"></div>
                        <div className="form-group my-4">
                            <InputLabel>Title</InputLabel>
                            <TextField name="title" onChange={handleChange} className="col-lg-3 col-md-6" variant="outlined" placeholder="Title of the post" />
                        </div>
                        <div className="form-group my-4">
                            <InputLabel>Festivals</InputLabel>
                            <Select name="festivals" onChange={handleChange} variant="outlined" className="col-lg-3 col-md-6">
                                {list}
                            </Select>
                        </div>
                        <div className="form-group my-4">
                            <InputLabel>Item Type</InputLabel>
                            <Select name="type" onChange={handleChange} variant="outlined" className="col-lg-3 col-md-6">
                                <MenuItem value="Tickets">Tickets</MenuItem>
                                <MenuItem value="Accommodations">Accommodations</MenuItem>
                                <MenuItem value="Transportation">Transportation</MenuItem>
                                <MenuItem value="Food">Food</MenuItem>
                                <MenuItem value="Hair/Makeup">Hair/Makeup</MenuItem>
                                <MenuItem value="Costumes +">Costumes +</MenuItem>
                                <MenuItem value="Others">Others</MenuItem>
                            </Select>
                        </div>
                        <div className="form-group my-4">
                            <InputLabel>Price</InputLabel>
                            <TextField name="price" onChange={handleChange} className="col-lg-3 col-md-6" variant="outlined" InputProps={{
                                startAdornment: <InputAdornment position="start">$</InputAdornment>,
                            }} placeholder="USD" />
                        </div>
                        <div className="form-group my-4"></div>
                        <div className="form-group my-4">
                            <InputLabel>Description</InputLabel>
                            <TextField fullWidth name="desc" onChange={handleChange} placeholder="Description" variant="outlined" />
                        </div>
                        <div className="form-group my-4">
                            <InputLabel>End/Expires Date</InputLabel>
                            <TextField name="eDate" onChange={handleChange} type="date" variant="outlined" />
                        </div>
                        <div className="form-group my-4">
                            <FormControlLabel
                                control={
                                    <Checkbox
                                        name="private"
                                        onChange={handleChange}
                                        checked={data.private}
                                    />
                                }
                                label="Keep private"
                            />
                        </div>
                        <div className="form-group my-4">
                            <InputLabel>Contact Info</InputLabel>
                            <TextField fullWidth name="contact" onChange={handleChange} placeholder="Name/Phone/email contact" variant="outlined" />
                        </div>
                    </form>
                    <Divider />
                    <Button onClick={submit} color="secondary" variant="outlined" className="mt-4 float-right">Submit</Button>
                </div>
            </div>
        </div>
    )
}