import { Link } from "react-router-dom";
import { makeStyles } from '@material-ui/core/styles';
import TruncateText from "../../functions/TruncateText";
import Card from '@material-ui/core/Card';
import CardContent from '@material-ui/core/CardContent';
import CardMedia from '@material-ui/core/CardMedia';
import Typography from '@material-ui/core/Typography';
import generateAddressImg from "../../functions/generateAddressImg";

const useStyles = makeStyles({
  media: {
    height: 140,
    marginRight: "1px",
    marginLeft: "1px"
  },
});

export default function BlogCard({ blog }) {
  const classes = useStyles();
  return (
    <Card >
      <Link className="linkCard shadow-md" to={`/blogs/${blog.slug}`}>
        <CardMedia
          className={classes.media}
          image={generateAddressImg(blog.img && blog.img.path,560,315)}
          title={blog.title}
        />
        <CardContent>
          <Typography gutterBottom variant="h5" component="h2">
            {blog.title}
          </Typography>
          <Typography variant="body2" color="textSecondary" component="p">
            {TruncateText(blog.meta, 50)}
          </Typography>
        </CardContent>
      </Link>
    </Card>
  )
}
