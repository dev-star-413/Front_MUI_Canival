import React,{ useEffect, useState } from "react";
import { getBlog } from "../../functions/api";
import Comment from "../../components/Comment";
import {Divider } from "@material-ui/core";
import { Link } from "react-router-dom";
import generateAddressImg from '../../functions/generateAddressImg'
import { LazyLoadImage } from "react-lazy-load-image-component";
import Advertisement from "../../components/Advertisement"
function Blog({ match }) {
  const [blog, setBlog] = useState(null);
  const [more, setMore] = useState(null);

  useEffect(() => {
    (async () => {
      let data = await getBlog(match.params.slug);
      setBlog(data && data.blog);
      setMore(data && data.more);
    })()
  }, [match.params.slug]);



  var page;
  if (blog) {
    let tags = [];
    if(blog.festivals && blog.festivals.length > 0) {
      
      tags = tags.concat(blog.festivals.map(item => {
         return {name: item.name, link: `/blogs?festival=${item.slug}`
        }}));
    }
    if(blog.cities && blog.cities.length > 0) {
      tags = tags.concat(blog.cities.map(item => {return {name: item.name, link: `/blogs?city=${item.slug}`}}));
    }
    if(blog.designers && blog.designers.length > 0) {
      tags = tags.concat(blog.designers.map(item => {return {name: item.name, link: `/blogs?designer=${item.slug}`}}));
    }
    if(blog.bands && blog.bands.length > 0) {
      tags = tags.concat(blog.bands.map(item => {return {name: item.name, link: `/blogs?band=${item.slug}`}}));
    }

    page = (
      <>
        <div className="col-md-8">
          <section dangerouslySetInnerHTML={{ __html: blog.desc }}></section>
          {(blog && blog.rLink)?
            <div className="text-center">
              <a className="font-weight-bold" href={blog && blog.rLink}>Continue Reading</a>
            </div>:""  
          }
          {/* <Advertisement /> */}
          {(
              <h6 className="card-title">Tags: <span> </span>
                {tags.map((item, index, array) => {return <span><Link to={item.link}>{item.name}</Link>{index !== array.length-1 && ','} </span>})}
              </h6>
          )}
          {more && more.length > 0 && (
            <div>
              <h5 className="mt-3 font-weight-bold">Related Posts</h5>
              <Divider />
            </div>
          )}
          <div className="mt-3">
          {more &&
            more.length > 0 &&
            more.map((card,index) =>
              <div  key={index}>
                <Link className="row my-2" to={`/blogs/${card.slug}`}>
                    {card.img &&
                      <div className="col-md-3 col-sm-12">
                          <LazyLoadImage
                              src={generateAddressImg(card.img.path,560,315)}
                              className="img-fluid"
                          />
                      </div>
                    }
                    <div className="col-md-9 col-sm-12">
                        <h3>
                            {card.title}
                        </h3>
                        <span className="text-dark">
                          {card.meta}
                        </span>
                    </div>
                </Link>
              </div>
            )
          }
          </div>
          <div>
            <div className="col-12">
              <Comment hasReply={true} collName='blog' docID={blog._id} countCoumments={blog.commentC}/>
            </div>
          </div>
        </div>
        <div className="col-md-4">
          <div className="sideAdvertisement card rounded d-flex mb-5">
            <h4 className="m-auto">sideAdvertisement</h4>
          </div>
          {more && (
            <div className="card mb-5">
              <div className="card-body">
                <h4 className="card-title">Top Stories</h4>
                <div className="row">
                  {more.map(mr => (
                    <div className="col-md-12 col-6 rounded my-2 ">
                      <Link  to={`/blogs/${mr.slug}`}>
                        <LazyLoadImage className="img-fluid" src={generateAddressImg(mr.img.path,560,315)}/>
                        <div>
                          <h6 className="my-3 font-weight-bold">{mr.title}</h6>
                        </div>
                      </Link>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}
          <div className="card mb-5">
            <div className="card-body">
              <h4 className="card-title">Categories</h4>
              {blog.cats &&
                blog.cats.length > 0 &&
                blog.cats.map(cat => <h6 key={cat}>
                  <a href={`/blogs?&cats=${cat}`}> {`${cat}\n`}</a>
                </h6>)}
            </div>
          </div>
        </div>
      </>
    );
  }
  return (
    <>
      <div className="container">
        <h1 className="text-capitalize pt-3">{blog && blog.title}</h1>
        {blog && <h5>By {blog.author} | {blog.pDate}</h5>}
        {blog && blog.img && (
          <img src={generateAddressImg(blog && blog.img && blog.img['path'],1120,630)} className="img-fluid"/>
        )}
        <i className="text-center d-flex justify-content-center">
          {blog && blog.imgt}
        </i>
        <div className="row pt-4">
            {page}
        </div>
      </div>
    </>
  );
}

export default Blog;
