import { Button, Divider, InputLabel, MenuItem, Select, TextField } from "@material-ui/core"
import { useState } from "react"
import FilePicker from "../../components/FilePicker";
import Tag from "../../components/Tag";
import { createPost } from "../../functions/api";
import convertBase64 from "../../functions/base64converter";
import { useHistory } from "react-router-dom";

export default function BlogForm() {
    const history = useHistory();
    const [data, setData] = useState({
        title: null, // string
        pDate: null, // date
        cats: null, // string
        sDesc: null, // string
        desc: null, // string
        imgs: null, // object
        city: [], // array
        carnival: [], // array
        band: [], // array
        designer: [], // array
        artist: [] // array
    });
    function editForm(event) {
        setData({ ...data, [event.target.name]: event.target.value });
    }
    async function getFile(file) {
        setData({ ...data, imgs: await convertBase64(file[0]) });
    }
    function update(name, tags) {
        setData({ ...data, [name]: tags });
    }
    async function submit() {
        if (data.title && data.pDate && data.cats && data.sDesc && data.desc) {
            const res = await createPost('blog', data)
            if (res && res.code == 1) {
                history.push("/profile")
            }
        } else {
            alert("Fill entire fields")
        }
    }
    return (
        <div className="container card shadow-lg my-5">
            <h3 className="titleText my-3">Add/Edit Blog Form</h3>
            <Divider />
            <form>
                <div className="form-group my-4">
                    <InputLabel>Blog Title</InputLabel>
                    <TextField fullWidth variant="outlined" color="primary" placeholder="Title" name="title" onChange={editForm} />
                </div>
                <div className="form-group my-4">
                    <InputLabel>Post Date</InputLabel>
                    <TextField type="date" variant="outlined" color="primary" name="pDate" onChange={editForm} />
                </div>
                <div className="form-group my-4">
                    <InputLabel>Blog Category</InputLabel>
                    <Select variant="outlined" color="primary" name="cats" onChange={editForm}>
                        <MenuItem value="Costume">Costume</MenuItem>
                        <MenuItem value="Event">Event</MenuItem>
                        <MenuItem value="Guides & Reviews">News</MenuItem>
                        <MenuItem value="Things to Do">Things to Do</MenuItem>
                        <MenuItem value="Food/Drinks">Food/Drinks</MenuItem>
                        <MenuItem value="First Timers">FirstTimers</MenuItem>
                        <MenuItem value="Fanatics">Fanatics</MenuItem>
                    </Select>
                </div>
                <div className="form-group my-4">
                    <InputLabel>Meta Description</InputLabel>
                    <TextField fullWidth multiline placeholder="Summary Text" name="sDesc" onChange={editForm} variant="outlined" color="primary" />
                </div>
                <div className="form-group my-4">
                    <InputLabel>Main Image/Browse</InputLabel>
                    <FilePicker updateFilesCb={getFile} />
                </div>
                <div className="form-group my-4">
                    <InputLabel>Description</InputLabel>
                    <TextField fullWidth multiline name="desc" placeholder="Description" variant="outlined" color="primary" onChange={editForm} />
                </div>
                <div className="form-group my-4">
                    <h5>Tags</h5>
                </div>
                <div className="form-group my-4">
                    <InputLabel>City</InputLabel>
                    <Tag updateTags={update} name="city" />
                </div>
                <div className="form-group my-4">
                    <InputLabel>Carnival</InputLabel>
                    <Tag updateTags={update} name="carnival" />
                </div>
                <div className="form-group my-4">
                    <InputLabel>Band</InputLabel>
                    <Tag updateTags={update} name="band" />
                </div>
                <div className="form-group my-4">
                    <InputLabel>Designer</InputLabel>
                    <Tag updateTags={update} name="designer" />
                </div>
                <div className="form-group my-4">
                    <InputLabel>Artist</InputLabel>
                    <Tag updateTags={update} name="artist" />
                </div>
                <Divider />
                <Button variant="outlined" color="primary" type="button" className="my-4 float-right" onClick={submit}>Submit</Button>
            </form>
        </div>
    )
}