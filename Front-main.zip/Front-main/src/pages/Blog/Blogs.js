import { useEffect, useState } from "react";
import { getBlogs } from "../../functions/api";
import {
  Checkbox,
} from "@material-ui/core";
import { BiFilterAlt } from "react-icons/all";
import { Link } from "react-router-dom";
import blogCats from "../../Helpers/blogCats"
import Typography from '@material-ui/core/Typography';
import generateAddressImg from "../../functions/generateAddressImg";
import { LazyLoadImage } from 'react-lazy-load-image-component';
export default function Blogs() {
  const [topBlogs, setTopBlogs] = useState([]);
  const [featureBlogs, setFeatureBlogs] = useState([]);
  const [mainBlog, setMainBlog] = useState(null);
  const [catFilters, setCatFilters] = useState([]);
  const [latestBlogs, setLatestBlogs] = useState([]);

  const onFilterChange = async event => {
    let tempCatFilters = [...catFilters];
    if(!event.target.checked) {
      tempCatFilters.splice(tempCatFilters.indexOf(event.target.value), 1)
    } else {
      tempCatFilters.push(event.target.value)
    }
    setCatFilters(tempCatFilters)

    let tempCatQuery = "";
    for(let catFilter of tempCatFilters) {
      tempCatQuery += `&cats=${catFilter}`
    }

    var url = window.location.protocol + "//" + window.location.host + window.location.pathname + "?" + tempCatQuery;
    window.history.pushState({path:url},'', url);

    const result = await getBlogs(window.location.search);
    setTopBlogs(result.topBlogs);
    setFeatureBlogs(result.featureBlogs);
    setLatestBlogs(result.latestBlogs);
    setMainBlog(result.featureBlogs && result.featureBlogs[0])
  };

  useEffect(async function() {
    const result = await getBlogs(window.location.search);
    setTopBlogs(result.topBlogs);
    setFeatureBlogs(result.featureBlogs);
    setLatestBlogs(result.latestBlogs);
    setMainBlog(result.featureBlogs && result.featureBlogs[0])
    }, []);

  useEffect(async function () {
    const params = new URLSearchParams(window.location.search);
    setCatFilters(params.getAll("cats"))
  }, [window.location.search])

  const filtersHtml = (
    <>
      <div className="d-flex flex-row flex-wrap" id="blogFilters" style={{fontSize: "10px"}}>
        <label style={{fontSize: "0.95rem", paddingTop: "2px"}} className="mt-2">
          <BiFilterAlt /> Filters: 
        </label>
        {blogCats.map(cat => 
          <label key={cat.name} style={{fontSize: "0.85rem", cursor: "pointer"}}>
            <Checkbox
              checked={catFilters.indexOf(cat.name) > -1}
              onChange={onFilterChange}
              name="cat"
              color="primary"
              value={cat.name}
            />
            {cat.name}
          </label>
        )}
      </div>
    </>
  );
  return (
    <div className="container">
      <div className=" mt-4">
        <h1>Hello Carnival Blogs</h1>
        <div>{filtersHtml}</div>
      </div>
      <div className="row">
        <div className="col-md-9 col-sm-12">
          {mainBlog && (
            <>
              <div style={{borderBottom: "1px solid #dddddd"}}>
                <h2>Features</h2>
              </div>
              <div className="my-3">
                <Link className=" row" to={`/blogs/${mainBlog.slug}`}>
                <img className="col-md-6 col-sm-12 img-fluid" src={generateAddressImg(mainBlog.img.path,560,315)}/>
                <div className="col-md-6 col-sm-12 ">
                  <h2 className="mt-3">
                    {mainBlog.title}
                  </h2>
                  <Typography color="textSecondary" component="p">
                    {mainBlog.meta}
                  </Typography>
                </div>

              </Link>
              </div>
            </>
          )}
          {featureBlogs && featureBlogs[1] &&
            <>
              <div className="my-3">
                {featureBlogs.map((blog, index) => {
                  if(index !== 0) {
                    return (
                      <div className="my-1" key={index}>
                        <Link className="row" to={`/blogs/${blog.slug}`}>
                            {blog.img &&
                              <div className="col-md-3 col-sm-12">
                                  <LazyLoadImage
                                      src={generateAddressImg(blog.img.path,560,315)}
                                      className="img-fluid"
                                  />
                              </div>
                            }
                            <div className="col-md-9 col-sm-12">
                                <h3>
                                    {blog.title}
                                </h3>
                                <span className="text-dark">
                                  {blog.meta}
                                </span>
                            </div>
                        </Link>
                      </div>
                    )
                  }
                })}
              </div>
            </>
          }
          {latestBlogs && latestBlogs[0] &&
            <>
              <div  className="my-3" style={{borderBottom: "1px solid #dddddd"}}>
                <h2>The Latest</h2>
              </div>
              <div className="my-3">
                {latestBlogs.map((blog, index) => {
                  return (
                    <div className="my-1" key={index}>
                      <Link className="row" to={`/blogs/${blog.slug}`}>
                          {blog.img &&
                            <div className="col-md-3 col-sm-12">
                                <LazyLoadImage
                                    src={generateAddressImg(blog.img.path,560,315)}
                                    className="img-fluid"
                                />
                            </div>
                          }
                          <div className="col-md-9 col-sm-12">
                              <h3>
                                  {blog.title}
                              </h3>
                              <span className="text-dark">
                                {blog.meta}
                              </span>
                          </div>
                      </Link>
                    </div>
                  )
                })}
              </div>
            </>
          }
        </div>
        <div className="col-md-3">
          {topBlogs && topBlogs[0] &&
            <>
              <div style={{borderBottom: "1px solid #dddddd"}}>
                <h2 className="">Top Stories</h2>
              </div>
              <div className="row  my-3">
                {topBlogs.map(tBlog => (
                  <Link className="col-md-12 col-6" key={tBlog.slug} to={`/blogs/${tBlog.slug}`}>
                    <div className="my-2">
                      <img className="img-fluid" src={generateAddressImg(tBlog.img.path,560,315)}/>
                      <div >
                        <h6 className="ml-2 my-3 font-weight-bold">{tBlog.title}</h6>
                      </div>
                    </div>
                  </Link>
                ))}
              </div>
            </>
          }
        </div>
      </div>
    </div>
  );
}
