import { useEffect, useState } from "react";
import { getStatic } from "../functions/api";
import { makeStyles } from "@material-ui/core/styles";
import {Divider} from "@material-ui/core";

const useStyles = makeStyles(theme => ({
  formControl: {
    marginTop: theme.spacing(2),
    marginBottom: theme.spacing(2),
  },
}));

export default function Statics(props) {
    const [page, setPage] = useState(null);
    const classes = useStyles();

    useEffect(async function () {
      const {slug} = props.match.params;
      const page = await getStatic(slug)
      if(!page) {
        window.location.href = "/404"
      }
      setPage(page)
    }, [props.match.params]);

    return (
      <>
        {page ? <div className="container">
          <div className={`d-flex flex-row justify-content-between ${classes.formControl}`} >
            <h1 className="my-auto font-weight-bold">{page.title}</h1>
          </div>
          <Divider />
          <div className="fr-view" style={{marginTop: "10px"}} dangerouslySetInnerHTML={{__html: page.content}}></div>
        </div>: ""}
      </>
    )
}