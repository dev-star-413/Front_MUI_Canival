export default function TruncateText(text, range) {
    if (text && range) {
        if (text.length > range) {
            text = `${text.substr(0, range)}...`;
        }
    }
    return text;
}