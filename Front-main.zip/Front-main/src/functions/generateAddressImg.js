export default function generateAddressImg (address, x,y){
    if(address && typeof address =='string'){
        // console.log(address)
        var array=address.split('/')
        var name=array.pop()
        var imgAddress= x+"/"+y+"/c/"+name
        array.push(imgAddress)
        var img =array.join('/')
        return img
    }
}