import moment from "moment";
let url = process.env.REACT_APP_API_URL;
export let siteUrl = process.env.REACT_APP_SITE_URL;
const limit = 4;

async function logError(err) {
  if(process.env.REACT_APP_ENV !== "production") {
    console.log(err)
  }

  return;
}

export async function getFestivals() {
  try {
    const festivals = await fetch(url + "/festival/landing/" + limit);
    return await festivals.json();
  } catch (error) {
    logError(error);
    throw error;
  }
}
export async function getFestivalsYear(year) {
  try {
    let festivals = await fetch(`${url}/festival/years/${year}`);
    return await festivals.json();
  } catch (error) {
    logError(error);
  }
}
export async function getEvents() {
  try {
    var events = await fetch(url + "/event");
    events = await events.json();
    for (let event of events.events) {
      event.sDate=moment(event.sDate).utc().format('llll')
    }
    return events;
  } catch (error) {
    logError(error);
    throw error;
  }
}
export async function getParades() {
  try {
    const parades = await fetch(`${url}/festival/parade`);
    return await parades.json();
  } catch (error) {
    logError(error);
  }
}
export async function getBlogs(query) {
  try {
    if (!query.startsWith("?")) {
      query = "?" + query
    }
    var blogs = await fetch(`${url}/blog${query}`);
    blogs = await blogs.json();
    return blogs;
  } catch (error) {
    logError(error);
    throw error;
  }
}
export async function getNews() {
  try {
    var news = await fetch(url + "/news");
    news = await news.json();
    return news;
  } catch (error) {
    logError(error);
    throw error;
  }
}
export async function getCostumeBands() {
  try {
    const costumeBands = await fetch(`${url}/band/landing/4`);
    if(costumeBands.status==404) return window.location.href="/404"
    return await costumeBands.json();
  } catch (error) {
    logError(error);
  }
}
export async function getDesigners(queryString) {
  try {
    var designers = await fetch(`${url}/designer${queryString || ""}`);
    if(designers.status==404) return window.location.href = "/404"
    return await designers.json();
  } catch (error) {
    logError(error);
  }
}
export async function getAwards() {
  try {
    const awards = await fetch(`${url}/award`);
    if(awards.status==404) return window.location.href = "/404"
    return awards.json();
  } catch (error) {
    logError(error);
  }
}
export async function getCarouselImages() {
  try {
    var images = await fetch(`${url}/slide-show`);
    images = await images.json();
    return images;
  } catch (error) {
    logError(error);
  }
}
export async function getFaqs() {
  try {
    const faqs = await fetch(`${url}/faq`);
    return await faqs.json();
  } catch (error) {
    logError(error);
  }
}
export async function getSections(bandid) {
  try {
    const sections = await fetch(`${url}/section/getSectionDescs/${bandid}`);
    return await sections.json();
  } catch (error) {
    console.log(error);
  }
}
export async function getComments(collName, docID) {
  try {
    const comments = await fetch(
      `${url}/comment?collName=${collName}&docID=${docID}`
    );
    return await comments.json();
  } catch (error) {
    logError(error);
  }
}
export async function getQuotes() {
  try {
    const quotes = await fetch(`${url}/quote`);
    return await quotes.json();
  } catch (error) {
    logError(error);
  }
}
export async function postComment(comment) {
  try {
    const result = await fetch(`${url}/comment/`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        token: localStorage.getItem("token")
      },
      body: JSON.stringify(comment)
    });
    return await result.json();
  } catch (error) {
    logError(error);
  }
}

export async function commentHelpful(commentID) {
  try {
    const result = await fetch(`${url}/comment/${commentID}/like`, {
      method: "PUT",
      headers: {
        "Content-Type": "application/json",
        token: localStorage.getItem("token")
      },
    });
    return await result.json();
  } catch (error) {
    logError(error);
  }
}

export async function commentNotHelpful(commentID) {
  try {
    const result = await fetch(`${url}/comment/${commentID}/dislike`, {
      method: "PUT",
      headers: {
        "Content-Type": "application/json",
        token: localStorage.getItem("token")
      },
    });
    return await result.json();
  } catch (error) {
    logError(error);
  }
}

export async function updateAwardReviews(data) {
  try {
    const result = await fetch(`${url}/award/review/update`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        token: localStorage.getItem("token")
      },
      body: JSON.stringify(data)
    });
    return await result.json();
  } catch (error) {
    logError(error);
  }
}

export async function updateSectionReview(data) {
  try {
    const result = await fetch(`${url}/section/review/update`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        token: localStorage.token,
      },
      body: JSON.stringify(data)
    });
    return await result.json();
  } catch (error) {
    logError(error);
  }
}

export async function getResult(id) {
  try {
    const result = await fetch(`${url}/award/${id}`);
    return await result.json();
  } catch (error) {
    console.log(error);
  }
}

export async function getProfile() {
  try {
    const profile = await fetch(`${url}/user`, {
      method: "GET",
      headers: {
        token: localStorage.getItem("token"),
        Accept: "application/json"
      }
    });
    return await profile.json();
  } catch (error) {
    logError(error);
  }
}

export async function updateProfile(data) {
  try {
    const profile = await fetch(`${url}/user/profile`, {
      method: "PUT",
      headers: {
        token: localStorage.getItem("token"),
        Accept: "application/json",
        "Content-Type": "application/json"
      },
      body: JSON.stringify(data)
    });
    return await profile.json();
  } catch (error) {
    logError(error);
  }
}

export async function logout() {
  try {
    var res = await fetch(`${url}/user/logout`, {
      method: "DELETE",
      headers: {
        token: localStorage.getItem("token"),
        Accept: "application/json",
        "Content-Type": "application/json"
      },
    });
    res = await res.json();
    if (res) {
      localStorage.removeItem("token");
    }
    return res;
  } catch (error) {
    logError(error);
  }
}

export async function getFestivalLastYear(slug) {
  try {
    var response = await fetch(`${url}/dates/festivalLastYear/${slug}`);
    if(response.status !== 200) return window.location.href = "/404"
    response = await response.json()
    return response.data;
  } catch (error) {
    logError(error);
  }
}

export async function getFestivalWhole(slug) {
  try {
    var response = await fetch(`${url}/festival/${slug}`);
    if(response.status !== 200) return window.location.href = "/404"
    response = await response.json()
    return response;
  } catch (error) {
    logError(error);
  }
}

export async function getPastYears (slug) {
  try {
    let pastYears = await fetch(`${url}/dates/pastYears/${slug}`)
    if (pastYears.status == 404) return window.location.href = "/404"
    pastYears = await pastYears.json();
    if (pastYears.code != 0) return [];
    return pastYears.data;
  } catch (err) {
    await logError(err);
  }
}

export async function getFestival(slug) {
  try {
    var festival = await fetch(`${url}/dates/festival/${slug}`);
    if(festival.status==404) return window.location.href = "/404"
    festival = await festival.json();
    if (festival.code != 0) return []; // error
    return festival.data;
  } catch (error) {
    logError(error);
  }
}

export async function getFestivalsData(year) {
  try {
    const data = await fetch(`${url}/dates/festivals?year=${year}`);
    return await data.json();
  } catch (error) {
    logError(error);
  }
}

export async function getHistory(slug) {
  try {
    const history = await fetch(`${url}/festival/${slug}/history`);
    return await history.json();
  } catch (error) {
    logError(error);
  }
}

export async function getEvent(slug) {
  try {
    var data = await fetch(`${url}/event/${slug}`);
    data = await data.json();
    if (data.event) {
      if (data.event.sDate) {
        data.event.sDate=moment(data.event.sDate).utc().format('llll')
      }
      if (data.event.eDate) {
        data.event.eDate=moment(data.event.eDate).utc().format('llll')
      }
    }
    return data;
  } catch (error) {
    logError(error);
  }
}

export async function getFestivalsList() {
  try {
    const list = await fetch(`${url}/festival/list/names`);
    return await list.json();
  } catch (error) {
    logError(error);
  }
}

export async function getOneNews(id) {
  try {
    var oneNews = await fetch(`${url}/news/${id}`);
    oneNews = await oneNews.json();
    return oneNews;
  } catch (error) {
    logError(error);
  }
}

export async function getBlog(slug) {
  try {
    let data = await fetch(`${url}/blog/${slug}`);
    data = await data.json();
    if(data && data.blog && data.blog.pDate){
      data.blog.pDate=moment(data.blog.pDate).utc().format('llll')
    }
    return data;
  } catch (error) {
    logError(error);
  }
}

export async function getCostumeBand(slug) {
  try {
    let data = await fetch(`${url}/band-date/slug/${slug}`,{
      method: "GET",
      headers: {
        token: localStorage.getItem("token"),
        Accept: "application/json",
      },
    });
    if(data.status==404) return window.location.href = "/404"
    data = await data.json();
    if (data.bandDate && data.bandDate.lDate) {
      data.bandDate.lDate = dateConvertWithoutHour(data.bandDate.lDate);
    }
    if (data.bandDate && data.bandDate.rdDate) {
      data.bandDate.rdDate = dateConvertWithoutHour(data.bandDate.rdDate);
    }
    if (data.sections && data.sections.length > 0) {
      for(let section of data.sections) {
        if (section.lDate) section.lDate = dateConvertWithoutHour(section.lDate);
        if (section.rdDate) section.rdDate = dateConvertWithoutHour(section.rdDate);
      }
    }
    if (data.lines && data.lines.length > 0) {
      for(let line of data.lines) {
        if (line.lDate) line.lDate = dateConvertWithoutHour(line.lDate);
        if (line.rdDate) line.rdDate = dateConvertWithoutHour(line.rdDate);
      }
    }
    if (data.events) {
      data.events.map(event => event.sDate = dateConverter(event.sDate))
    }
    return data;
  } catch (error) {
    logError(error);
  }
}

export async function postBandDateScoreReview(data) {
  try {
    const result = await fetch(`${url}/band-date/score/update`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        token: localStorage.getItem("token")
      },
      body: JSON.stringify(data)
    });
    return await result.json();
  } catch (error) {
    logError(error);
  }
}

export async function getCostumeBandsByYear(data) {
  try {
    const bands = await fetch(`${url}/band-date/filtered?year=${data.year}&band=${data.band}&carnival=${data.carnival}&sections=${data.sections}`);
    return await bands.json();
  } catch (error) {
    logError(error);
  }
}

export async function getDesigner(slug) {
  try {
    var designer = await fetch(`${url}/designer/${slug}`);
    designer = await designer.json();
    return designer;
  } catch (error) {
    logError(error);
  }
}
// get user info
export async function logInByGoogleToken(data) {
  try {
    var result = await fetch(`${url}/user/login/google/`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        tokenId: data.tokenId
      }
    });
    result = await result.json();
    result.token && localStorage.setItem("token", result.token);
    return result;
  } catch (error) {
    logError(error);
  }
}

export async function logInByOtp(data) {
  try {
    const fetchRes = await fetch(`${url}/user/login/otp`, {
      method: "POST",
      body: JSON.stringify({
        otp: data.otp
      }),
      headers: {
        "Content-Type": "application/json",
      }
    });
    const fetchJson = await fetchRes.json();
    return fetchJson;
  } catch (err) {
    logError(err);
    throw err;
  }
}

export async function getSection(bandid) {
  try {
    const section = await fetch(`${url}/section/getSectionDetails/${bandid}`);
    return await section.json();
  } catch (error) {
    logError(error);
  }
}

export async function like(collName, docID) {
  try {
    const token = localStorage.getItem("token");
    const response = await fetch(`${url}/like`, {
      method: "POST",
      mode: "no-cors",
      headers: {
        token: token
      },
      body: JSON.stringify({
        collName: collName,
        docID: docID
      })
    });
    return await response.json();
  } catch (error) {
    logError(error);
  }
}

export async function createPost(collName, data) {
  try {
    const response = await fetch(`${url}/${collName}/create`, {
      method: "POST",
      headers: {
        token: localStorage.getItem("token"),
        Accept: "application/json",
        "Content-Type": "application/json"
      },
      body: JSON.stringify(data)
    });
    return await response.json();
  } catch (error) {
    logError(error);
  }
}

export async function getFormData(collName) {
  try {
    const data = await fetch(`${url}/${collName}/form/params`, {
      method: "GET",
      headers: {
        token: localStorage.getItem('token'),
        Accept: "application/json",
        "Content-Type": "application/json"
      },
    });
    return await data.json();
  } catch (error) {
    logError(error)
  }
}

export async function getFilterData(collName) {
  try {
    const data = await fetch(`${url}/${collName}/filter/params`, {
      method: "GET",
      headers: {
        token: localStorage.getItem('token'),
        Accept: "application/json",
        "Content-Type": "application/json"
      },
    })
    return await data.json();
  } catch (error) {
    logError(error)
  }
}

export async function getRandomAd({page,node}) {
  try {
    const ad = await fetch(`${url}/ad/random?page=${page}&node=${node}`);
    return await ad.json();
  } catch (error) {
    logError(error);
  }
}
export async function getLandingFestival() {
  try {
    let festivalDate = await fetch(`${url}/dates/landing`);
    festivalDate = await festivalDate.json();
    return festivalDate;
  } catch (error) {
    console.log(error);
    // return error
  }
}
export async function getWatchList() {
  try {
    const watchList = await fetch(`${url}/watch-list`, {
      method: "GET",
      headers: {
        token: localStorage.getItem('token'),
        Accept: "application/json",
        "Content-Type": "application/json"
      },
    });
    return await watchList.json();
  } catch (error) {
    console.log(error);
    // return error
  }
}
export async function addWatchList(caseId, collName) {
  try {
    if (!caseId || !collName)
      return { code: -2, msg: "please send caseId & collName" };
    const data = { caseId, collName };
    const response = await fetch(`${url}/watch-list`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        token: localStorage.token,
      },
      body: JSON.stringify(data)
    });
    return await response.json();
  } catch (error) {
    logError(error);
  }
}
export async function removeWatchList(id) {
  try {
    if (!id) return { code: -2, msg: "please send id of your Watch List" };
    const response = await fetch(`${url}/watch-list/remove/${id}`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        token: localStorage.token,
      },
    });
    return await response.json();
  } catch (error) {
    console.log(error);
    // return error
  }
}
export async function checkInWatchList(caseId, collName) {
  try {
    if (!caseId) return { code: -2, msg: "send your caseId" };
    const response = await fetch(`${url}/watch-list/check?caseId=${caseId}&collName=${collName}`, {
      headers: {
        token: localStorage.token,
      },
    });
    return await response.json();
  } catch (error) {
    logError(error);
  }
}
export async function bandsCompare(slugs) {
  try {

    var response = await fetch(`${url}/band-date/compare?slugs=${slugs}`)
    response = await response.json();
    if (response.code != 0) throw response.msg
    return response.data
  }
  catch (error) {
    console.log(error)
  }
}

export async function getStatic(slug) {
  try {
    const res = await fetch(`${url}/statics?slug=${slug}`)
    const resJson = await res.json();
    if (resJson.code === 0) {
      return resJson.data
    } else {
      return null;
    }
  } catch (err) {
    console.log(err)
  }
}
export async function searchBand(text,sort){
  try{
    var res =await fetch(`${url}/band/search/name?q=${text}&sort=${sort}`)
    res=await res.json()
    if (res.code === 0) return res.bands
    return []
    }catch(err){
      console.log(err)
      return []
  }
}
export async function uploadProfilePicture(data){
  try {
    var res=await fetch(`${url}/user/profile/picture`,{
      method:'POST',
      headers: {
        token: localStorage.getItem("token"),
        Accept: "application/json",
        "Content-Type": "application/json"
      },
      body: JSON.stringify({picture:data})
    })
    res=await res.json()
    return res
  } catch (error) {
    console.log(error)
    return {code:-1,msg:"Something is wrong, Please try again"}
  }

}

export async function removeProfilePicture(){
  try {
    var res=await fetch(`${url}/user/profile/picture`,{
      method:'DELETE',
      headers: {
        token: localStorage.getItem("token"),
        Accept: "application/json",
        "Content-Type": "application/json"
      },
    })
    res=await res.json()
    return res
  } catch (error) {
    console.log(error)
    return {code:-1,msg:"Something is wrong, Please try again"}
  }

}
export async function getBandBySlug(slug){
  try {
    var res=await fetch(`${url}/band/${slug}`,{
      method:'Get',
      headers: {
        token: localStorage.getItem("token"),
      },
    })
    res=await res.json()
    return res
  } catch (error) {
    console.log(error)
    return {code:-1,msg:"Something is wrong, Please try again"}
  }
}

export async function searchAll (value) {
  let res = await fetch( `${url}/festival/search/all?q=${value}`);
  res = await res.json();
  return res;
}

// export async function searchCarnival(q){
//   var res=await fetch( `${url}/dates/search/name?q=${q}`)
//   res=await res.json()
//   return res
// }
export async function searchFestivals(q){
  var res = await fetch( `${url}/festival/search/name?q=${q}`)
  res = await res.json()
  return res;
}
export async function logInByFacebookToken(data){
  try {
    var res=await fetch(`${url}/user/login/facebook`,{
      method:"POST",
      headers: {
        "Content-Type": "application/json",
        accesstoken: data.accessToken
      },
      body:JSON.stringify({userID:data.userID})
    })
    res=await res.json()
    if(res && res.data && res.data.token ){
      localStorage.setItem("token", res.data.token);
    } 
    return res
  } catch (error) {
    return {code:-1,msg:error.message,data:null}
  }
}
export async function getYearsHaveFestival(){
  var res=await fetch( `${url}/festival/list/years`)
  res=await res.json()
  return res
}
export async function getBandsFestivalDate(id){
  var res=await fetch( `${url}/band-date/festival?id=${id}`)
  res=await res.json()
  return res
}
export async function getListFestivals(){
  var res=await fetch( `${url}/festival/list/all`)
  res=await res.json()
  return res
}

function dateConvertWithoutHour(data){
  return moment(data).utc().format("ddd, MMM D, YYYY"); 
}
function dateConverter(data) {
  return moment(data).utc().format('llll')
}
