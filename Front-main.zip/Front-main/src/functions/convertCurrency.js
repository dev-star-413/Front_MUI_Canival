export default function convertToUSD(amout,rates, from ){
    var currency=rates.find((coin)=>coin.from==from)
    var price=0
        if(currency && currency.rate){
            price=amout * currency.rate
        }
        price=Math.round(price * 100) / 100
    return price
}