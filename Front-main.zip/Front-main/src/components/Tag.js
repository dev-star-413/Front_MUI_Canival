import { IconButton, TextField } from "@material-ui/core";
import { useState } from "react";
import { IoCloseCircleOutline } from "react-icons/all";

const Tag = ({ updateTags, name, data }) => {
    const [tags, setTags] = useState(data ? data : []);
    function addTag(event) {
        if (event.key === "Enter" && event.target.value !== "") {
            update([...tags, event.target.value]);
            setTags([...tags, event.target.value]);
            event.target.value = "";
        }
    }
    function removeTag(index) {
        update([...tags.filter(tag => tags.indexOf(tag) !== index)])
        setTags([...tags.filter(tag => tags.indexOf(tag) !== index)])
    }
    function update(data) {
        updateTags(name, data)
    }
    return (
        <div>
            <div className="d-flex flex-row flex-wrap">
                {tags.map((tag, index) => (
                    <div className="mx-1 my-1 tag px-1" key={index}>
                        <span className="subtitleText">{tag}</span>
                        <IconButton size="small" color="primary" onClick={() => removeTag(index)}>
                            <IoCloseCircleOutline />
                        </IconButton>
                    </div>
                ))}
            </div>
            <TextField placeholder="Press Enter to add tag" variant="outlined" onKeyUp={addTag} />
        </div>
    )
}

export default Tag;