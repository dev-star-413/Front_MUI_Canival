import { Link } from "react-router-dom"
import generateAddressImg from "../functions/generateAddressImg"

export default function Compare({ sections, bandDateSlug }) {
    const section1 = sections[0]
    const section2 = sections[1]
    return (
        <div className="col-lg-6 col-12 py-2">
            <div className="col-12 shadow-lg rounded card bg-dark">
                <div className="d-flex flex-row justify-content-center">
                    <div className="col-5">
                        <div className=" p-1">
                            {/* <div style={{
                                height: '180px', width: '100%', backgroundImage: `url('${section1.img}')`,
                                backgroundSize: 'contain', backgroundPosition: 'center', backgroundRepeat: 'no-repeat',
                            }} /> */}
                            <img src={generateAddressImg(section1.img,300,400)} className="img-fluid"/>
                            <div className="p-2 text-center text-light">
                                <h6>{section1.name}</h6>
                            </div>
                        </div>
                    </div>
                    <div className="col-2 d-flex justify-content-center align-items-center">
                        <span className="text-white" style={{ fontSize: "1.5rem", fontWeight: "bold" }}>VS.</span>
                    </div>
                    <div className="col-5">
                        <div className="p-1 d-flex flex-column">
                            {/* <div style={{
                                height: "180px", width: '100%', backgroundImage: `url('${section2.img}')`,
                                backgroundSize: 'contain', backgroundPosition: 'center', backgroundRepeat: 'no-repeat',
                            }} /> */}
                            <img src={generateAddressImg(section2.img,300,400)} className="img-fluid"/>

                            <div className="p-2 text-center text-light">
                                <h6 >{section2.name}</h6>
                            </div>
                        </div>
                    </div>
                </div>
                <div className=" justify-content-center py-3">
                    <div className="text-center">
                        <span className="text-uppercase btn btn-secondary">
                            <Link to={`/bands/compare/${bandDateSlug}~${section1._id}/${bandDateSlug}~${section2._id}`} className="px-2 text-white" style={{ fontWeight: 'bold' }}>
                                Compare Now
                            </Link>
                        </span>
                    </div>
                </div>
            </div>
        </div>

    )

}