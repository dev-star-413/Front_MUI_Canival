import React from "react";
import "../assets/styles/Festival.css";
import {Link} from "react-router-dom";
import "@fortawesome/fontawesome-free/css/all.css"
import "../App.css"
import {LazyLoadImage} from 'react-lazy-load-image-component';
import generateAddressImg from "../functions/generateAddressImg";


export default function  CardCompare({coupleBands}){
    //first, second,cityCode,festivalName
  if(!coupleBands || !coupleBands[0] || !coupleBands[1]) return <></>
    var first=coupleBands[0]
    var second=coupleBands[1]
    var firstImg=''
    var sImg=''
    if(first && first.section && first.section.img) firstImg=first.section.img.path 
    else if(first && first.mainImg && first.mainImg.path) firstImg=first.mainImg.path
    // second img
    if(second && second.section && second.section.img) sImg=second.section.img.path 
    else if(second && second.mainImg && second.mainImg.path) sImg=second.mainImg.path
    let fUrl=(first && first.section)?first && first.slug+"~"+first.section._id : first && first.slug
    let sUrl=(second && second.section)?second && second.slug+"~"+second.section._id :second && second.slug
    var compareUrl='/bands/compare/'+fUrl +'/'+sUrl

    return (
        <div className="col-12 shadow-lg  rounded card bg-dark">
            <div className="row">
                <div className="col-5 ">
                    <div className=" p-1">
                        {/* <div  style={{maxHeight:"200px",maxWidth:'200px', backgroundImage: `url('${firstImg}')`,
                            backgroundSize: 'contain', backgroundRepeat:"no-repeat",
                            backgroundPosition:'center',height:'40vh'
                            }} >
                        </div> */}
                        <LazyLoadImage className="img-fluid" src={generateAddressImg(firstImg,195,260)} />
                        <div className="text-white  p-2">
                          <Link to={'/bands/'+first.slug}>
                            <span>{first && first.name} </span>
                          </Link>
                        </div>
                    </div>
                </div>
                <div className="col-2 d-flex justify-content-center align-items-center text-white">
                    <span style={{fontSize:"1.5rem", fontWeight:"bold"}}>VS.</span>
                </div>
                <div className="col-5 ">
                    <div className=" p-1 d-flex  flex-column">
                        {/* <div   style={{maxHeight:"200px",maxWidth:'200px', backgroundImage: `url('${sImg}')`,
                            backgroundSize: 'contain',backgroundRepeat:"no-repeat",
                            backgroundPosition:'center',height:'40vh'
                            }} >
                        </div> */}
                         <LazyLoadImage className="img-fluid" src={generateAddressImg(sImg,195,260)} />
                        <div className="text-white  p-2">
                          <Link to={'/bands/'+second.slug}>
                            <span>{second && second.name}</span>
                          </Link>
                        </div>
                    </div>
                </div>
            </div>
            <div className=" justify-content-center py-3">
                <div className="text-center">
                    <span className="text-uppercase text-white">
                        <Link to={compareUrl} className="px-2">
                            compare now
                        </Link>
                    </span>
                </div>
            </div>
        </div>
    )
  
}