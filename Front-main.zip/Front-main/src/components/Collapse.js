import { FormControlLabel, IconButton } from "@material-ui/core";
import { useState } from "react";
import { Link } from "react-router-dom";
import TruncateText from "../functions/TruncateText";
import { IoAdd, AiOutlineMinus } from "react-icons/all";
import generateAddressImg from "../functions/generateAddressImg";

export default function Collapse(props) {
    const [open, setOpen] = useState(false);
    function handleChange(event) {
        event.preventDefault();
        setOpen(!open);
    }
    if (props.items) {
        var items = props.items.map(function (item) {
            return (
                <li className="list-group-item" key={item._id}>
                    <div className="d-flex flex-wrap col-12">
                        <div className="col-md-7 col-sm-12 d-flex flex-column">
                            <Link to={`/festivals/${item.festival.slug}`}>
                                <h3 className="subtitleText">
                                    {item.festival.name}
                                    {item.canceled && <h5 className="text-muted font-weight-bold">&nbsp;<small className="badge bg-danger text-white">{item.festival.canceled}</small></h5>}
                                </h3>
                            </Link>
                            <p className="text-dark text-justify">{TruncateText(item.about, 404)}</p>
                            <Link className="text-secondary mt-auto" to={`/festivals/${item.festival.slug}`}>More...</Link>
                        </div>
                        <Link className="col-md-5 col-sm-12 text-secondary mt-auto" to={`/festivals/${item.festival.slug}`}>
                            <div className="zoomContainer shadow">
                                {
                                    item.imgs[0] &&
                                    // <div className="bandPicture zoom" style={{ backgroundImage: `url(${imagesURL}${item.imgs[0].path})` }} />
                                    <img src={generateAddressImg(item.imgs[0].path,150,150)} className="img-fluid"/>
                                }
                            </div>
                        </Link>
                    </div>
                </li >
            )
        });
    }
    return (
        <>
            <FormControlLabel onClick={handleChange} control={<IconButton color="primary">{open ? <AiOutlineMinus /> : <IoAdd />}</IconButton >} label={<h3 className="titleText">{props.title && `${props.title} Festivals`}</h3>} />
            <ul className={`list-group list-group-flush pb-4 d-${open ? "block" : "none"}`}>
                {items}
            </ul>
        </>
    )
}