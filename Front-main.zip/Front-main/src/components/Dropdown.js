import { makeStyles } from '@material-ui/core/styles';
import InputLabel from '@material-ui/core/InputLabel';
import MenuItem from '@material-ui/core/MenuItem';
import FormHelperText from '@material-ui/core/FormHelperText';
import FormControl from '@material-ui/core/FormControl';
import Select from '@material-ui/core/Select';
import { useState } from 'react';

const useStyles = makeStyles((theme) => ({
    formControl: {
        margin: theme.spacing(1),
        minWidth: 120,
    },
    selectEmpty: {
        marginTop: theme.spacing(2),
    },
}));

export default function Dropdown(props) {
    const classes = useStyles();
    const [val, setVal] = useState(props.default);
    const handleChange = (event) => {
        setVal(event.target.value);
        if (props.onChange) {
            props.onChange(event)
        }
    };
    return (
        <div className={props.class}>
            <FormControl className={classes.formControl}>
                {props.label && <InputLabel id="demo-simple-select-helper-label">{props.label}</InputLabel>}
                <Select
                    labelId={`${props.label}Label`}
                    id={`${props.label}Dropdown`}
                    value={val}
                    onChange={handleChange}>
                    <MenuItem value="">Choose One...</MenuItem>
                    {props.items}
                </Select>
                <FormHelperText>{props.hint}</FormHelperText>
            </FormControl>
        </div>
    );
}
