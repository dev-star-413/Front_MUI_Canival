import { GrFacebook, SiGmail } from "react-icons/all";
import { GoogleLogin } from 'react-google-login';
import { logInByGoogleToken, logout,logInByFacebookToken } from '../functions/api';
import FacebookLogin from 'react-facebook-login/dist/facebook-login-render-props';
// import FacebookLogin from 'react-facebook-login';
import React from 'react';
import { Dialog, IconButton, Typography, Slide, Button } from "@material-ui/core";
import CloseIcon from '@material-ui/icons/Close';
import { memo } from "react";

const Transition = React.forwardRef(function Transition(props, ref) {
    return <Slide direction="up" timeout={800} ref={ref} {...props} />;
});

export default memo(function Signin(props) {
    const token = localStorage.token;
    async function responseGoogle(params) {
        const res = await logInByGoogleToken(params)
        if (!res ||  !res.code || res.code !== -1) {
            window.location.reload();
        }
    }

    const [open, setOpen] = React.useState(false);

    const handleClickOpen = () => {
        setOpen(true);
    }

    const handleClose = () => {
        setOpen(false);
    }

    function failedLogin(params) {
      console.log(params)
      alert(`${props.btnTitle?props.btnTitle:"Sign In"} failed!`)
    }

    async function responseFacebook(data) {
      const res = await logInByFacebookToken(data)
      if (!res ||  !res.code || res.code !== -1) {
          window.location.reload();
      }
    }

    async function logoutAcc() {
        const res = await logout()
        if (res && res.code === 1) {
            window.location.reload();
        }
    }
    async function handleOnFailure(x){
      console.log("-----handleOnFailure-------")
      console.log(x)
    }

    return (
        <>
            {props.profile ?
             <a id="signinBtn" className=" pointer my-auto mx-2"  onClick={handleClickOpen}>{props.btnTitle?props.btnTitle:"Sign In"}</a>
            : (
              token ? 
              <button className="sidebar-item px-4 mx-4 sidebar-link pt-2 text-white" style={{backgroundColor: "#181716" }}  onClick={handleClickOpen}>Sign Out</button>

              :
                <button className={props.className?props.className:"px-4 btn pt-2 text-white"} style={props.style?props.style:{ fontSize: '1.5rem', fontWeight: 'bold', backgroundColor: "#181716" }}  onClick={handleClickOpen}>{props.btnTitle?props.btnTitle:"Sign In"}</button>
            )}
            <Dialog open={open} onClose={handleClose} TransitionComponent={Transition}>
              {token ?
                <div className="col-12">
                    <IconButton color="inherit" className="mx-1 float-right mt-2 " onClick={handleClose} aria-label="close">
                        <CloseIcon />
                    </IconButton>
                    <h5 className="my-4 mx-4">Sign Out</h5>
                    <Typography className="px-4">
                        Are you sure?
                    </Typography>
                    <div className="col-12 py-4">
                        <Button variant="outlined" color="secondary" onClick={logoutAcc} className="mx-2">Sign Out</Button>
                        <Button variant="outlined" color="primary" onClick={handleClose} className="mx-2">Cancel</Button>
                    </div>
                </div>
              :
                <div className="col-12">
                    <IconButton color="inherit" className="float-right mt-2" onClick={handleClose} aria-label="close">
                        <CloseIcon />
                    </IconButton>
                    <Typography className="pb-4">
                      <GoogleLogin
                          clientId={process.env.REACT_APP_WEB_CLIENT_ID}
                          buttonText="Login"
                          onSuccess={responseGoogle}
                          onFailure={failedLogin}
                          // cookiePolicy={'single_host_origin'}
                          // isSignedIn={true}
                          autoLoad={false}
                          render={res => (
                            <button onClick={function () {
                                handleClose();
                                res.onClick();
                            }} disabled={res.disabled} className="btn btn-block btn-lg btn-danger">
                              {res.disabled ? 
                              <>
                                Please wait ... 
                              </> 
                              : 
                              <>
                                <SiGmail /> Continue with Google 
                              </>}
                            </button>
                          )}
                        /> 
                        <FacebookLogin
                            appId='646220410531328'
                            autoLoad={false}
                            callback={responseFacebook}
                            fields="name,email,picture"
                            scope="public_profile,email"
                            // returnScopes={true}
                            // icon="fa-facebook"
                            onFailure={handleOnFailure}
                            render={res => (
                              <button onClick={function () {
                                  handleClose();
                                  res.onClick();
                              }} disabled={res.disabled} className="btn btn-block btn-lg btn-primary">
                                {res.disabled ? 
                                <>
                                  Please wait ... 
                                </> 
                                : 
                                <>
                                  <GrFacebook /> Continue with Facebook
                                </>}
                              </button>
                            )}
                        />
                    </Typography>
                </div>}
            </Dialog>
        </>
    )
})
