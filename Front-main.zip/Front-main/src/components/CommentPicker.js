import { TextField, Button } from "@material-ui/core";
import { useState } from "react";
import { postComment } from "../functions/api";
import Rate from "react-rating-stars-component";
import Comment from "../components/Comment";

export default function CommentPicker({
  label,
  docID,
  collName,
  hasRate,
  hasReply,
  comments,
  hasText,
  color,
  index
}) {
  const showComments = Boolean(comments);
  const userExists = Boolean(localStorage.token);
  const [cmts, setComments] = useState(comments || []);
  const [comment, setComment] = useState({
    comment: "",
    docID: docID,
    rate: 1,
    collName: collName,
    index
  });

  function editComment(event) {
    setComment({ ...comment, [event.target.name]: event.target.value });
  }

  async function submitComment() {
    if (userExists) {
      const res = await postComment(comment);
      if (res && res._id) {
        setComment({ ...comment, comment: "" });
        let commentsTemp = cmts;
        commentsTemp.push(res)
        setComments(commentsTemp);
      }
    } else {
      alert("You shall register first.");
    }
  }

  function setNewRate(rate) {
    setComment({ ...comment, rate: rate });
  }

  return (
    <>
      <div className="my-3 card shadow-sm" style={color && { backgroundColor: color }}>
        <div className="card-body">
          <h5 className="font-weight-bold">{label || 'Post your comment'}</h5>
          {hasRate && (
            <Rate
              value={comment.rate}
              className="mr-4"
              edit
              count={5}
              size="15px"
              onChange={setNewRate}
            />
          )}
          {hasText && (
            <TextField
              name="comment"
              value={comment.comment}
              onChange={editComment}
              rows="4"
              placeholder="Start typing here..."
              label="Enter your comment"
              multiline
              fullWidth
            />
          )}
          <div className="d-flex">
            <Button
              type="submit"
              onClick={submitComment}
              variant="contained"
              className="ml-auto mt-3"
              color="primary"
            >
              Send
            </Button>
          </div>
        </div>
      </div>
      {showComments &&
        <div>
          {cmts && cmts.length > 0 &&
            <details className="col-12">
              <summary>
                <h5 className="mb-3 font-weight-bold d-inline-block">
                  {cmts.length} Comment{cmts.length != 1 ? 's' : null} - Click to view
                </h5>
              </summary>
              <div>
                {cmts && cmts.map((review, key) => (
                  <Comment key={key} index={index} collName={collName} docID={docID} comment={review} hasRate={hasRate} hasReply={hasReply} />
                ))}
              </div>
            </details>
          }
        </div>
      }
    </>
  );
}
