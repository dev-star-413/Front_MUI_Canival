import React from 'react';
import Dialog from '@material-ui/core/Dialog';
import IconButton from '@material-ui/core/IconButton';
import CloseIcon from '@material-ui/icons/Close';
import Slide from '@material-ui/core/Slide';
import { AiOutlineSearch } from "react-icons/all";
import TextField from '@material-ui/core/TextField';
import {searchAll} from '../functions/api';
import AwesomeDebouncePromise from 'awesome-debounce-promise';
import {
  withStyles,
  makeStyles,
} from '@material-ui/core/styles';

const Transition = React.forwardRef(function Transition(props, ref) {
  return <Slide direction="up" ref={ref} {...props} />;
});

const useStyles = makeStyles((theme) => ({
  root: {
    display: 'flex',
    flexWrap: 'wrap',
  },
  margin: {
    margin: theme.spacing(1),
  },
}));

const CssTextField = withStyles({
  root: {
    '& label.Mui-focused': {
      color: '#fff',
    },
    '& label': {
      color: "#fff",
    },
    "& .MuiInput-input": {
      color: "#fff",
    },
    '& .MuiInput-underline:after': {
      borderBottomColor: '#fff',
    },
    '& .MuiInput-underline:before': {
      borderBottomColor: '#fff',
    },
    '& .MuiInput-underline': {
      borderBottomColor: '#fff',
    },
    '& .MuiOutlinedInput-root': {
      '& fieldset': {
        borderColor: '#fff',
      },
      '&:hover fieldset': {
        borderColor: '#fff',
      },
      '&.Mui-focused fieldset': {
        borderColor: '#fff',
      },
    },
  },
})(TextField);

export default function Search() {
  const [open, setOpen] = React.useState(false);
  const [festivals, setFestivals] = React.useState([]);
  const [bandDates, setBandDates] = React.useState([]);
  const [events, setEvents] = React.useState([]);

  const handleClickOpen = () => {
    setOpen(true);
  };

  const handleClose = () => {
    setFestivals([]);
    setBandDates([]);
    setEvents([]);
    setOpen(false);
  };

  const search = async ({target}) => {
    if (!target.value || target.value.length < 3) {
      setFestivals([]);
      setBandDates([]);
      setEvents([]);
    } else {
      let res = await searchAPIDebounced(target.value);
      renderSections(res)
    }
  }

  function renderSections (props) {
    if (!props) return;
    let content = {};

    //  construct festival section
    content['festivals'] = [];
    if (props['festivals'] && props['festivals'][0]) for (let festival of props['festivals']) {
      content['festivals'].push(
          <a className = {'list-group-item bg-transparent list-group-item-action text-light border-dark'}
             href={`/festival/${festival.slug}`}>
            {festival.name}
          </a>
      );
    }

    //  construct bandDate section
    content['bandDates'] = [];
    if (props['bandDates'] && props['bandDates'][0]) for (let bandDate of props['bandDates']) {
      content['bandDates'].push(
          <a className = {'list-group-item bg-transparent list-group-item-action text-light border-dark'}
             href={`/bands/${bandDate.slug}`}>
            {bandDate.name} {bandDate.year? ' - ' + bandDate.year : ''}
          </a>
      );
    }

    //  construct event section
    content['events'] = [];
    if (props['events'] && props['events'][0]) for (let event of props['events']) {
      content['events'].push(
          <a className = {'list-group-item bg-transparent list-group-item-action text-light border-dark'}
             href={`/events/${event.slug}`}>
            {event.name} {event.year ? ' - ' + event.year : ''}
          </a>
      );
    }

    const listCount = [content['festivals'][0], content['bandDates'][0], content['events'][0]].filter(Boolean).length;
    const h = listCount === 1 ? 400 : listCount === 2 ? 195 : 130;

    for (let item of [{func: setFestivals, str: 'festivals'}, {func: setBandDates, str: 'bandDates'}, {func: setEvents, str: 'events'}]) {
      if (!content[item.str][0]) continue ;
      item.func(
        [
          <>
            <div className={'w-75 m-auto'}>
              <h5 className={'text-light mt-4'}>{item.str}</h5>
              <hr color={'white'} className={'m-0'}/>
              <div className={'list-group list-group-flush bg-transparent overflow-auto'} style={{maxHeight: h}}>
                {content[item.str]}
              </div>
            </div>
          </>
        ]
      )
    }
  }

  const classes = useStyles();
  return (
    <div>
      <button className="btn navbar-button btn-dark">
        <AiOutlineSearch className="navbarIcon" onClick={handleClickOpen} />
      </button>
      <Dialog fullScreen open={open} onClose={handleClose} TransitionComponent={Transition}>
        <div className="h-100 w-100" id="searchModal">
          <IconButton edge="end" onClick={handleClose} aria-label="close">
            <CloseIcon className="text-light" />
          </IconButton>
          <form className={classes.root} noValidate onChange={search}>
            <CssTextField className={`${classes.margin} mx-auto my-auto w-75 text-white`} label="Search" placeholder={'Please insert at least 3 characters'}/>
          </form>
          {festivals}
          {bandDates}
          {events}
        </div>
      </Dialog>
    </div>
  )
}

const searchAPIDebounced = AwesomeDebouncePromise(searchAll, 800);
