import { NavbarBrand } from "react-bootstrap";
import { BsPersonFill } from "react-icons/all";
import Search from "./Search";
import Sidebar from "./Sidebar";
import sidebarItems from "../Helpers/SidebarItems";
import { Link } from "react-router-dom";
import Signin from "./Signin";

export default function Header() {
    return (
        <div className="navbar navbar-expand-sm navbar-light justify-content-between d-flex shadow">
            <div className="d-flex flex-row my-auto ">
                <Sidebar items={sidebarItems} />
                <NavbarBrand className="ml-2" style={{ color: '#fcfcfc' }}>
                    <Link className="text-white" to="/" style={{ fontFamily: `"Circular Pro", "Helvetica Neue", Helvetica, Roboto, Arial, sans-serif` }}>
                        Hello Carnival
                    </Link>
                </NavbarBrand>
            </div>
            <div className="d-flex flex-row">
                {localStorage.token ?
                    <Link className="btn navbar-button btn-dark" to="/profile">
                        <BsPersonFill className="navbarIcon" />
                    </Link>
                    :
                    <Signin profile btnTitle="Sign In" />
                }
                <Search />
            </div>
        </div>
    );
}