import { useEffect, useState } from "react";
import "../assets/styles/Advertisement.css";
import { getRandomAd } from "../functions/api";

export default function Advertisement({slot}) {
    const [code,setCode]=useState('')

    useEffect(() => {
      try {
        (window.adsbygoogle = window.adsbygoogle || []).push({});
      } catch (error) {
        console.log()
      }
      
    }, [])

    return (
      
        <div className="text-center" id="adsParentDiv" style={{width:"100%"}}>
          <ins className="adsbygoogle infeed"
              style={{display:'block'}}
              data-ad-client="ca-pub-9140791068839294"
              data-ad-slot={slot}
              data-ad-format="fluid"
              data-full-width-responsive="true"></ins> 
        </div>

    )
}