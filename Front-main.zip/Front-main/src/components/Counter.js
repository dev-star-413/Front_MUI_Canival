function Counter(props) {
    return (
        <div className="d-flex flex-column" style={{backgroundColor:"#181716"}}>
            <div className=" text-white d-flex flex-column align-items-center">
                <h1 className="mt-1" style={{marginBottom: "-5px", fontSize: "3.2rem"}}><strong>{props.days}</strong></h1>
                <h5 className="mb-2"><i>Days to Parade</i></h5>
                <h5 className="text-warning">{props.time}</h5>
            </div>
        </div>
    )
}

export default Counter;