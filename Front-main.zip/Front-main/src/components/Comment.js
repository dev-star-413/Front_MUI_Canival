import { Divider, Button, TextField } from "@material-ui/core";
import { useEffect, useState } from "react";
import { postComment,getComments } from "../functions/api";
import Rate from "react-rating-stars-component";
import generateAddressImg from "../functions/generateAddressImg";
import profilePicture from "../assets/imgs/profile.png";

function Comment({  collName, docID, index, hasReply, hasRate, countCoumments }) {
  const options = { year: "numeric", month: "long", day: "numeric" };
  const [openComments,setOpenComments]=useState(false)
  const [count, setCount]=useState(countCoumments || 0) 
  const [comments,setComments]=useState([])
  const [newComment,setNewComment]=useState({
    docID,
    comment:"",
    collName
  })
  useEffect(()=>{
    setOpenComments(false)
    setCount(countCoumments || 0)
    setComments([])
    setNewComment({
      docID,
      comment:"",
      collName
    })
  },[docID])
  function convertDate(date) {
    if (date) {
      return new Date(date).toLocaleDateString("en-US", options);
    }
    return date;
  }


  function avatarAddress(path){
    if(!path) return profilePicture
    if (path && path.startsWith('https://')) return path
    return generateAddressImg(path,36,36)
  }

  function handleCommentChange(e){
    var elValue=e.target.value
    if(!docID) return alert("Something is wrong, Please try again")
    setNewComment({ ...newComment,comment:elValue,docID:docID });    
  }
  async function submitComment(){
    const com = await postComment(newComment);
    if(com && com._id){
      setCount(count+1)
      setComments([...comments,com])
    }

    setNewComment({...newComment,comment:""})
  }
  
  async function  showComment(){
    let open=!openComments
    setOpenComments(open)
    if(open){
      let findComments=await getComments(collName,docID)
      if(findComments && Array.isArray(findComments)){
        findComments=findComments.filter((com)=>{
          if(!com.replyTo){
            let replies=findComments.filter((index)=>index.replyTo==com._id)
            com.replies=replies
            return com
          }
        })
        setComments(findComments)
      }

    }
  }


  return (
    <div className="my-2">
    <details>
        <summary onClick={showComment}>{count} user comment for this {collName}</summary>
        <div>
          {(comments && Array.isArray(comments) && comments.map((comment)=>{
            return(
              <div className={`card shadow-sm mb-3`} key={"com-"+comment._id}>
                <div className="card-body ">
                  <div className="row">
                    <div className="col-sm-10">
                      <div className="row d-flex flex-row align-items-center mb-1">
                        <div className="ml-2">
                          <img className="rounded-circle" style={{width:'36px',height:"36px"}} src={avatarAddress(comment && comment.avatar)}/>
                        </div>
                        <h5 className="px-2 d-flex flex-row align-items-center m-0">
                          { comment && comment.name} - <small>{convertDate(comment && comment.createAt)}</small>
                          {comment && comment.rate && hasRate && <Rate edit={false} value={comment.rate} count={5} size="15px" />}
                        </h5>
                      </div>

                      <Divider />
                    </div>
                  </div>
                  <p className="my-3">{comment && comment.comment}</p>
                  {hasReply && localStorage.token  && (
                    <Reply commentID={comment._id} docID={docID} collName={collName} allReplies={comment.replies || []}/>
                  )}
                </div>
              </div>
            )}))}
        </div>
        {localStorage.token ? <div className="my-3 card shadow-sm">
        <div className="card-body">
          <h5 className="font-weight-bold">Post your comment</h5>
          <TextField
            name="comment"
            value={newComment && newComment.comment ? newComment.comment: ""}
            onChange={handleCommentChange}
            rows="4"
            placeholder="Start typing here..."
            multiline
            fullWidth
          />
        <div className="d-flex">
          <Button
            type="submit"
            onClick={submitComment}
            className="mt-3 ml-auto"
            variant="text"
          >
            Send
          </Button>
        </div>
      </div>
      </div>: <h6>You have to sign in before post a comment</h6>
    }
    </details>

    </div>
  );
}

export default Comment;

function Reply({commentID,docID,collName,allReplies,hasRate}){
  const [openReply,setOpenReply]=useState(false)
  const [replies,setReplies]=useState(allReplies || [])
  const [reply,setReply]=useState({
    replyTo:commentID,
    collName,
    docID,
    comment:""
  })
  async function submitReply() {
    setReply({ ...reply, comment: "" });
    var result=await postComment(reply);
      if(result && result._id) setReplies([...replies,result])
  }
  function avatarAddress(path){
    if(!path) return profilePicture
    if (path && path.startsWith('https://')) return path
    return generateAddressImg(path,36,36)
  }
  function convertDate(date) {
    if (date) {
      return new Date(date).toLocaleDateString("en-US",{ year: "numeric", month: "long", day: "numeric" });
    }
    return date;
  }
  function handleActionOpenReply(){
    setOpenReply(!openReply)
  }

  return(
    <div className="col-12"> 
      <div className=" ml-auto col-sm-2 py-1">
        <Button onClick={handleActionOpenReply}  variant="outlined">
          Reply
        </Button>
      </div>
      <div className="col-12">
      {(replies && Array.isArray(replies) && replies.map ((rep)=>{
        return(
          <div className="col-sm-12 py-2" key={rep._id}>
            <div className="col-sm-12">
              <div className="d-flex flex-row align-items-center">
                <img className=" img-fluid  c-avatar-img  rounded-circle" style={{width:'26px',height:"26px"}} src={avatarAddress(rep && rep.avatar)}/>
                <h5 className="px-2 d-flex flex-row align-items-center">
                  { rep && rep.name} - <small>{convertDate(rep && rep.createAt)}</small>
                  {rep && rep.rate && hasRate && <Rate edit={false} value={rep.rate} count={5} size="15px" />}
                </h5>
              </div>
            </div>
            <p className="col-12">{rep && rep.comment}</p>
            <Divider/>
          </div>
        )
      }))}
      </div>
      {openReply  && localStorage.token  && 
        <div className="col-12 pt-3">
          <TextField
            fullWidth
            multiline
            onChange={event =>
              setReply({ ...reply, comment: event.target.value })
            }
            className="mr-2"
            value={reply.comment}
            name="comment"
            color="primary"
            placeholder="Type reply here..."
          />
          <div className="d-flex 1">
            <Button
              onClick={submitReply}
              variant="contained"
              className="ml-auto mt-2"
              color="primary"
            >
              Send
            </Button>
          </div>
        </div>
      }
    </div>
  )
}