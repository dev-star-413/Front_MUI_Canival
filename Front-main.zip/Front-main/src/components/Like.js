import React from 'react';
import FormControlLabel from '@material-ui/core/FormControlLabel';
import Checkbox from '@material-ui/core/Checkbox';
import Favorite from '@material-ui/icons/Favorite';
import FavoriteBorder from '@material-ui/icons/FavoriteBorder';
import { like } from "../functions/api";

export default function Like(props) {
    async function handleClick() {
        await like(props.collName, props.docID)
    }
    return (
        <FormControlLabel
            control={<Checkbox icon={<FavoriteBorder />}
                checkedIcon={<Favorite />} name="like" />} onClick={handleClick} />
    );
}
