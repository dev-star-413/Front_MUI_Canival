import { BsArrowRight } from "react-icons/all";
import { Link } from 'react-router-dom';

function Event(props) {
    const carnivals = [];
    for (var anEvent of props.events) {
        if (anEvent.image) {
            carnivals.push(
                <Link to="festival" params={{ festivalId: anEvent.id }} className={props.colSize} key={anEvent.title}>
                    <div className="d-flex flex-column my-4 py-2 text-center">
                        <div className="mb-4">
                            <img src={anEvent.image.source} alt={anEvent.image.alt} className="w-100" />
                        </div>
                        <span>
                            <h2>{anEvent.title}</h2>
                            <div className="d-flex flex-row justify-content-center">
                                <div className="border-div" />
                            </div>
                            <h6>{anEvent.date} {anEvent.innerEvent && <span>| <i>{anEvent.innerEvent.title}</i> {anEvent.innerEvent.date} - {anEvent.innerEvent.time}</span>}</h6>
                        </span>
                        {anEvent.description && <p>{truncateText(anEvent.description, 200)}</p>}
                    </div>
                </Link>
            )
        } else {
            carnivals.push(
                <Link to={`/festivals/${anEvent.id}`} className={props.colSize} key={anEvent.title}>
                    <div className="carnival-item d-flex flex-column my-4 py-2">
                        <span>
                            <h2>{anEvent.title}</h2>
                            <h6>{anEvent.date} | <i>{anEvent.innerEvent.title}</i> {anEvent.innerEvent.date} - {anEvent.innerEvent.time}</h6>
                        </span>
                        {anEvent.description && <p>{truncateText(anEvent.description, 200)}</p>}
                    </div>
                </Link>
            )
        }
    }
    return (
        <div className="d-flex flex-row flex-wrap">
            {props.title && <Title notifs={props.notifs} title={props.title} />}
            {carnivals}
            {!props.more &&
                <div className="col-12 w-100">
                    <h6 className="more-button" ><b>More</b> <BsArrowRight /></h6>
                </div>}
            {props.more && props.more}
        </div>
    )
}

function Title(props) {
    return (
        <div className="col-12 w-100" style={{ color: `${props.color}` }}>
            <div className="title my-4 py-3 d-flex flew-row">
                <h1>{props.title}</h1>
                {(props.notifs && props.notifs === "true") && <button data-toggle="modal" data-target="#notificationsModal" className="btn btn-outline-dark ml-auto">Notifications</button>}
            </div>
        </div>
    )
}

function truncateText(text, maxLength) {
    if (text.length > maxLength) {
        text = text.substr(0, maxLength) + '...';
    }
    return text;
}

export default Event;