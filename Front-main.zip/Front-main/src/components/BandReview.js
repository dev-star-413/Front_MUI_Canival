import {
    Button, CardContent,
    InputLabel, MenuItem, Select, TextField,
    Dialog, DialogActions, DialogContent, DialogContentText,
    DialogTitle, Snackbar, IconButton, Radio
} from "@material-ui/core";
import MuiAlert from '@material-ui/lab/Alert';
import React, { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import Rate from "react-rating-stars-component";
import { postComment, commentHelpful, commentNotHelpful } from "../functions/api";
import moment from "moment";
import { GrStar } from "react-icons/all";
import convertBase64 from "../functions/base64converter";
import generateAddressImg from "../functions/generateAddressImg";
import { BsChevronCompactDown } from "react-icons/all";
import Signin from '../components/Signin'
import ShareButton from "./ShareButton";
import profilePicture from "../assets/imgs/profile.png";
import CloseIcon from '@material-ui/icons/Close';
import DeleteIcon from '@material-ui/icons/Delete';
import ReviewExplanation from "./modal/ReviewExplanation";
import "../assets/styles/RangeInput_2.css";

const Slideshow = React.lazy(() => import("./SlideShow"));

function Alert(props) {
  return <MuiAlert elevation={6} variant="filled" {...props} />;
}

export default function BandReview({ id, years, bands, carnivals, sections, comments, average,
  fId, year, bandName, dateName, thisBandInOtherFYs }) {
    const rawReview = {
        docID: id,
        collName: 'band',
        year: year,
        fId: fId,
        bdId: id,
        sId: '',
        imgs: [],
        title: '',
        design: 1,
        food: 1,
        events: 1,
        service: 1,
        parade:1,
        // noCancel: 1,
        // wasPaidFor: 1,
        average: 1,
        text: '',
        visible: false,
    }
    const [avg, setAvg] = useState(average);
    const [review, setReview] = useState(rawReview);
    const [reviews, setReviews] = useState([]);
    const [snackbar, setSnackbar] = useState({});
    const [reply, setReply] = useState({
      to: "",
      open: false,
      text: "",
    });
    const [summary, setSummary] = useState(null)
    const [slideShow, setSlideShow] = useState({
      open: false,
      images: [],
      type: "list",
      dialogTitle: "",
    });
    const [thisBandInOtherFYsOpen, setThisBandInOtherFYsOpen] = useState(false);
    const reviewThanksMessage = 'Thank you for sharing a detailed review of your experiences. Users like you appreciate this.';
    function editReview(event) {
        setReview({ ...review, [event.target.name]: event.target.value });
        checkData(event);
    }
    function checkData(event) {
        if (event.target.name === 'year') {
            setReview({ ...review, [event.target.name]: event.target.value, fId: '', bdId: '', sId: '' });
        } else if (event.target.name === 'fId') {
            setReview({ ...review, [event.target.name]: event.target.value, bdId: '', sId: '' });
        } else if (event.target.name === 'bdId') {
            setReview({ ...review, [event.target.name]: event.target.value, sId: '' });
        }
    }
    async function postReview() {
      var {design,food,events,service,parade}=review
      var arr=[design,food,events,service,parade]
      arr=arr.filter((n)=> n && n!=0)
      var sumScore=(arr.reduce((a,b)=>a+b))
      let postObj = {
        collName: 'band',
        docID: review.bdId,
        subID: review.sId,
        imgs: review.imgs,
        comment: review.text,
        title: review.title,
        score: {
            design: review.design,
            food: review.food,
            events: review.events,
            service: review.service,
            parade: review.parade,
            // wasPaidFor: review.wasPaidFor,
            avg:Number.parseFloat( sumScore/ arr.length).toFixed(2),
        },
      }

      const res = await postComment(postObj);
      if(res && res.code && res.code !== 0) {
        setSnackbar({
          isOpen: true,
          msg: res.msg,
          severity: "error",
        })
      } else if (res && res.data && res.data) {
        setSnackbar({
          isOpen: true,
          msg: "New comment posted",
          severity: "success",
        })

        if(review.docID === review.bdId && review.year === year) {
          let tmpReviews = JSON.parse(JSON.stringify(reviews));
          tmpReviews.push(res.data)
          setReviews(tmpReviews);
          setAvg(res.averageReview);
        }

        setReview(rawReview);
      } else {
        setSnackbar({
          isOpen: true,
          msg: "Some error occurred",
          severity: "error",
        })
      }
    }
    function changeChaserImg(imgIndex) {
      const imgs = [...review.imgs];
      for(let i in imgs) {
        if(i != imgIndex) {
          imgs[i].isChaserImg = false;
        }
      }
      imgs[imgIndex].isChaserImg = !imgs[imgIndex].isChaserImg
      setReview({ ...review, imgs })
    }
    function removeReviewImg(imgIndex) {
      const imgs = [...review.imgs];
      imgs.splice(imgIndex, 1);
      setReview({ ...review, imgs })
    }
    async function handleFiles(event) {
      if (event.target.files && event.target.files.length > 0) {
        if(event.target.files.length > 5) {
          setSnackbar({
            isOpen: true,
            msg: "Upload at most 5 images.",
            severity: "error",
          })
          event.target.value = ""
          return;
        }
        const files = []
        for (const file of event.target.files) {
          const { type, size, name } = file;
          if(size > 5 * 1024 * 1024) {
            setSnackbar({
              isOpen: true,
              msg: "One or more file is bigger than 5MB.",
              severity: "error",
            })
            event.target.value = ""
            return;
          }
          if(!file['type'].includes('image')) {
            setSnackbar({
              isOpen: true,
              msg: "One or more file is not an image.",
              severity: "error",
            })
            event.target.value = ""
            return;
          }

          const convertedFile = await convertBase64(file);
          files.push({ name, type, size, base64: convertedFile.split('base64,').pop(), isChaserImg: false });
        }
        setReview({ ...review, imgs: files });
      }
    }
    useEffect(() => {
      let replies = [];
      let parentComments = []
      for(let comment of comments) {
        if(comment.replyTo) {
          replies.push(JSON.parse(JSON.stringify(comment)))
        } else {
          parentComments.push(JSON.parse(JSON.stringify(comment)))
        }
      }

      for(let reply of replies) {
        let parent = parentComments.find(item => item._id === reply.replyTo)
        if(parent) {
          if(Array.isArray(parent.replies)) {
            parent.replies.push(reply)
          } else {
            parent.replies = [reply]
          }
        }
      }

      setReviews(parentComments);
    }, [comments])

    useEffect(() => {
      let tmpSummary = {
        design: 0,
        food: 0,
        events: 0,
        service: 0,
        parade:0,
        // noCancel: 0,
        // wasPaidFor: 0,
      };
      if(reviews.length > 0) {
        for(let review of reviews){
          for(let i in tmpSummary) {
            if(review.score[i] && !isNaN(review.score[i])){
              tmpSummary[i] += Number(review.score[i])
            }
          }
        }
        for(let i in tmpSummary) {
          tmpSummary[i] = Number((tmpSummary[i] / reviews.length).toFixed(1))
        }
      }
      setSummary(tmpSummary)

    }, [reviews])
    useEffect(()=>{
      setAvg(average)
    },[average])
    function setRating (key, value) {
      let obj = { ...review }
      obj[key] = value;
      var {design,food,events,service,parade}=obj
      var arr=[design,food,events,service,parade]
      arr=arr.filter((n)=> n && n!=0)

      // obj.average = ((obj.design + obj.food + obj.events + obj.service/* + obj.noCancel + obj.wasPaidFor*/) / 4).toFixed(2)
      obj.average=Number.parseFloat((arr.reduce((a,b)=>a+b)) / arr.length).toFixed(1)
      setReview(obj)
    }

    function handleSnackClose () {
      setSnackbar({
        isOpen: false,
        msg: "",
      })
    };

    function toggleReplyTextarea(reviewID) {
      if(reply.open){
        setReply({
          to: "",
          open: false,
          text: ""
        })
      } else {
        setReply({
          to: reviewID,
          open: true,
          text: ""
        })
      }
    }

    async function sendReply() {
      let postObj = {
        collName: 'band',
        docID: review.bdId,
        comment: reply.text,
        replyTo: reply.to,
      }

      const res = await postComment(postObj);
      if(res.code === 0) {
        setSnackbar({
          isOpen: true,
          msg: "New reply posted",
          severity: "success",
        })

        const data = res.data;
        let tmpReviews = JSON.parse(JSON.stringify(reviews))
        let parent = tmpReviews.find(item => item._id === data.replyTo)
        if(parent) {
          if(Array.isArray(parent.replies)) {
            parent.replies.push(data)
          } else {
            parent.replies = [data]
          }
        }
        setReviews(tmpReviews)
        toggleReplyTextarea();
      } else {
        setSnackbar({
          isOpen: true,
          msg: res.msg,
          severity: "error",
        })
      }
    }

    function toggleReplies(reviewID) {
      let tmpReviews = JSON.parse(JSON.stringify(reviews))
      let comment = tmpReviews.find(item => item._id === reviewID)
      if(comment) {
        comment.showReplies = !comment.showReplies
      }
      setReviews(tmpReviews)
    }

    function showReviewImages(review, imagName) {
      let tmpSlideShow = {
        images: review.imgs.map((item, index) => {
          return {
            _id: item.name,
            img: (item.mime && item.mime.includes('video')) ? item.path : generateAddressImg(item.path, 1120, 630),
            name: `Image number ${index+1} by ${review.name}`
          }
        }),
        open: true,
        type: "list",
        selected: imagName,
        dialogTitle: ``
      }
      setSlideShow(tmpSlideShow)
    }

    function handleActionSlide() {
      setSlideShow({...slideShow, open: false})
    }
    function avatarAddress(path){
      if(!path) return profilePicture
      if (path && path.startsWith('https://')) return path
      return generateAddressImg(path,36,36)
    }

    function helpfulAction(review) {
      if(review.likedByMe) {
        commentNotHelpful(review._id)
        let tmpReviews = JSON.parse(JSON.stringify(reviews))
        let comment = tmpReviews.find(item => item._id === review._id)
        if(comment) {
          comment.likeCount--;
          comment.likedByMe = false;
        }
        setReviews(tmpReviews)
      } else {
        commentHelpful(review._id)
        let tmpReviews = JSON.parse(JSON.stringify(reviews))
        let comment = tmpReviews.find(item => item._id === review._id)
        if(comment) {
          comment.likeCount++;
          comment.likedByMe = true;
        }
        setReviews(tmpReviews)
      }
    }

    return (
        <div>
          <Slideshow images={slideShow.images} open={slideShow.open} type={slideShow.type} handleAction={handleActionSlide} selected={slideShow.selectedImage} dialogTitle={slideShow.dialogTitle} continuous={false}/>
          {thisBandInOtherFYs && thisBandInOtherFYs.length > 0 && <Dialog
            open={thisBandInOtherFYsOpen}
            onClose={() => setThisBandInOtherFYsOpen(false)}
            fullWidth = {true}
            maxWidth="xs"
          >
            <DialogTitle className="pt-2">
              <div style={{display:"flex", justifyContent: "space-between", alignItems: "center"}}>
                {bandName} in other festivals
                <IconButton className="mt-0">
                  <CloseIcon onClick={() => setThisBandInOtherFYsOpen(false)}/>
                </IconButton>
              </div>
            </DialogTitle>
            <DialogContent>
              {thisBandInOtherFYs.map(band => (
                <Link to={`/bands/${band.slug}#section-userreviews`} onClick={() => setThisBandInOtherFYsOpen(false)}>
                  <h5>{band.dateName}&nbsp;{band.year}</h5>
                </Link>
              ))}
            </DialogContent>
          </Dialog>}
          <details>
            <summary className="row">
              <div className="col-12">
                <h2>
                  <div className="d-inline-block">
                    {(avg!=0.0)?
                    <>
                    {Number(avg).toFixed(1)}/<small>5</small>
                    </>
                    :<small>- - </small>}
                    <GrStar style={{ color: '#ffeb3b', paddingBottom: "3px" }} /></div>
                    Reviews and Summary for {bandName} {dateName}
                  <BsChevronCompactDown className="d-inline-block ml-2"></BsChevronCompactDown>
                </h2>
              </div>
              <div className="col-12">
                <h5 className="col-12">
                  { (reviews && reviews.length >0)?reviews.length:"--"} User Review{reviews &&  reviews.length !== 1 && 's'} for {bandName}&nbsp;
                  {thisBandInOtherFYs && thisBandInOtherFYs.length > 0 &&
                    <a href="javascript: void(0)" onClick={() => setThisBandInOtherFYsOpen(true)}>More reviews</a>
                  }
                </h5>

              </div>
              {summary && <div className="col-12">
                <div className="row col-12">
                  <div className="col-md-3 col-6">Design:</div>
                  <div className="col-md-9 col-6"> 
                    {summary.design || '-'} <GrStar style={{ color: '#ffeb3b', paddingBottom: "3px" }} />
                    {/* <Rate size={18} value={summary.design} edit={false} key={summary.design} /> */}
                  </div>
                </div>
                <div className="row col-12">
                  <div className="col-md-3 col-6">Food/Drinks:</div>
                  <div className="col-md-9 col-6"> 
                    {summary.food || '-'} <GrStar style={{ color: '#ffeb3b', paddingBottom: "3px" }} />
                    {/* <Rate size={18} value={summary.food} edit={false} key={summary.food} /> */}
                  </div>
                </div>
                <div className="row col-12">
                  <div className="col-md-3 col-6">Parade Road Vibes</div>
                  <div className="col-md-9 col-6"> 
                    {summary.parade || '-'} <GrStar style={{ color: '#ffeb3b', paddingBottom: "3px" }} />
                    {/* <Rate size={18} value={summary.parade} edit={false} key={summary.parade} /> */}
                  </div>
                </div>
                <div className="row col-12">
                  <div className="col-md-3 col-6">Events/Fetes:</div>
                  <div className="col-md-9 col-6"> 
                  {summary.events || '-'} <GrStar style={{ color: '#ffeb3b', paddingBottom: "3px" }} />
                  {/* <Rate size={18} value={summary.events} edit={false} key={summary.events} /> */}
                  </div>
                </div>
                <div className="row col-12">
                  <div className="col-md-3 col-6">Customer Service:</div>
                  <div className="col-md-9 col-6"> 
                  {summary.service || '-'} <GrStar style={{ color: '#ffeb3b', paddingBottom: "3px" }} />
                  {/* <Rate size={18} value={summary.service} edit={false} key={summary.service} /> */}
                  </div>
                </div>
                {/* <div className="row col-12">
                  <div className="col-md-3 col-6">Canceled / No refund:</div>
                  <div className="col-md-9 col-6"> <Rate size={18} value={summary.noCancel} edit={false} key={summary.noCancel} /></div>
                </div>
                <div className="row col-12">
                  <div className="col-md-3 col-6">Get what was paid for:</div>
                  <div className="col-md-9 col-6"> <Rate size={18} value={summary.wasPaidFor} edit={false} key={summary.wasPaidFor} /></div>
                </div> */}
              </div>}
              <div className="col-12 text-center">
                <ReviewExplanation/>
              </div>
            </summary>


            <div className="col-12">
              {reviews && reviews.map((r, rI) =>
                {
                  if(r.replyTo) {
                    return
                  }
                  const section = sections.find(item => item._id === r.subID);
                  return (<React.Fragment key={rI}>
                    <hr className="my-3"/>
                    <div>
                      <div className="row mb-2">
                        <div className="ml-2">
                          <img className="rounded-circle" style={{width:'36px',height:"36px"}} src={avatarAddress(r.avatar)}/>
                        </div>
                        <h5 className="px-2 col-6 d-flex flex-row align-items-center m-0">{r.name} &nbsp;
                          {/* {console.log("-------r.score.avg----------",(r.score.avg).toFixed(1))} */}
                          <small>{(Number.parseFloat(r && r.score && r.score.avg)!=0.00 )?(Number.parseFloat(r.score.avg)).toFixed(2) :'--'}</small><GrStar style={{ color: '#ffeb3b', paddingBottom: "3px" }} /></h5>
                        <h6 className="col-5 d-flex flex-row align-items-center justify-content-end m-0">
                          {moment(r.createAt).format('MMM D, YYYY')}
                        </h6>
                      </div>
                      <div className="row">
                        {r.title ? <h5 className="col-12 font-weight-bold">{r.title}</h5> : ""}
                      </div>
                      <div className="row">
                        <small className="col-12 mb-2 text-muted">Band: {bandName} at {dateName} {year}</small>
                      </div>
                      <div className="row">
                        {section && <small className="col-12 mb-2 text-muted">Section: {section.name}</small>}
                      </div>
                      <div className="col-12 row">
                        {r.imgs && Array.isArray(r.imgs) && r.imgs[0] &&
                            <a  href="javascript: void(0)" onClick={() => showReviewImages(r, r.imgs[0].name)}>
                              <img src={generateAddressImg(r.imgs[0].path,150,150)} className="img-fluid" alt={r.imgs[0].title}/>
                              <br/>
                              <span>{(r.imgs.length>1)?`${r.imgs.length} images`:""}</span>
                            </a>
                        }
                      </div>
                      <div className="row">
                        {r.comment && <p className="col-12 mt-2" style={{whiteSpace:'pre-line'}}>{r.comment}</p>}
                      </div>
                      <div className="row">
                        <div className="col-md-3 col-6 ">Design:</div>
                        <div className="col-md-9 col-6 "> <Rate size={18} value={r.score.design} edit={false} /></div>
                        <div className="col-md-3 col-6 ">Food/Drinks:</div>
                        <div className="col-md-9 col-6 "> <Rate size={18} value={r.score.food} edit={false} /></div>
                        <div className="col-md-3 col-6 ">Parade Road Vibes:</div>
                        <div className="col-md-9 col-6 "> <Rate size={18} value={r.score?.parade || 0} edit={false} /></div>
                        <div className="col-md-3 col-6 ">Events/Fetes:</div>
                        <div className="col-md-9 col-6 "> <Rate size={18} value={r.score.events} edit={false} /></div>
                        <div className="col-md-3 col-6 ">Customer Service:</div>
                        <div className="col-md-9 col-6 "> <Rate size={18} value={r.score.service} edit={false} /></div>
                        {/* <div className="col-md-3 col-6 ">Canceled / No refund:</div>
                        <div className="col-md-9 col-6 "> <Rate size={18} value={r.score.noCancel} edit={false} /></div>
                        <div className="col-md-3 col-6 ">Get what was paid for:</div>
                        <div className="col-md-9 col-6 "> <Rate size={18} value={r.score.wasPaidFor} edit={false} /></div> */}
                        <div className="col-12 pt-2" style={{display:"flex", flexDirection: "row", justifyContent: "space-between"}}>
                          <Button variant="outlined" color="default" title="helpful"
                            onClick={() => helpfulAction(r)}>
                            <i className="fa fa-thumbs-up pr-2" style={r.likedByMe ? {color: "#dd2e44"} : {}}></i>Helpful&nbsp;{r.likeCount > 0 ? `\u00d7${r.likeCount}`: ""}
                          </Button>
                          <Button variant="outlined" color="default" onClick={() => toggleReplyTextarea(r._id)} title="reply">
                            <i className="fa fa-reply pr-2"></i> Reply
                          </Button>
                          <ShareButton link={`${window.location.pathname}#section-userreviews`} text={`Check this comment by ${r.name} on ${bandName} ${year}\n`}/>
                        </div>
                        {r.replies && Array.isArray(r.replies) &&
                          <div className="col-12" style={{cursor: "pointer", color: "#00A1AF"}} onClick={() => toggleReplies(r._id)}>
                            {r.showReplies ? `Hide replies` : `Show ${r.replies.length} replies`}
                          </div>
                        }
                      </div>
                    </div>
                    {reply.open && reply.to === r._id &&
                      <div className="row py-2">
                        <div className="col-md-10">
                          <TextField rows={3} dir="auto" placeholder="Write your reply" type="text" name="text" multiline fullWidth
                            value={reply.text} variant="outlined" onChange={(event) => {
                              setReply({ ...reply, text: event.target.value });
                            }}/>
                        </div>
                        <div className="col-md-2 text-center my-auto ">
                          <Button variant="contained" color="primary" title="send" onClick={sendReply}>
                            send
                          </Button>
                        </div>
                      </div>
                    }
                    {
                      r.showReplies && r.replies && Array.isArray(r.replies) && r.replies.map(rThisReply => {
                        return (
                          <div style={{paddingLeft: "40px"}} key={rThisReply._id}>
                            <hr className="my-2"/>
                            <div className="row">
                              <img className=" img-fluid rounded-circle" style={{width:'36px',height:"36px"}} src={avatarAddress(r.avatar)}/>
                              <div className="col-6 d-flex flex-row align-items-center">{rThisReply.name}
                              {(rThisReply && rThisReply.isOrganizer)?<>&nbsp;(<i>{bandName}</i>&nbsp;Organizer)<i className='fa fa-check text-primary   mx-1'></i></>:""}</div>
                              <div className="col-5 d-flex flex-row align-items-center justify-content-end">{moment(rThisReply.createAt).format('MMM D, YYYY')}</div>
                            </div>
                            <div className="mt-2">
                              <p className="col-12" style={{whiteSpace:"pre-line"}}>
                                {rThisReply.comment}
                              </p>
                            </div>
                          </div>
                        )
                      })
                    }
                  </React.Fragment>)
                }

              )}
            </div>
          </details>
              <>
                  <div className="text-center mb-3 col-12">
                  {localStorage.token &&
                  <div className="pt-2">
                  <Button className="btn btn-block text-white font-weight-bold py-2" style={{ backgroundColor: '#00A1AF' }}
                      onClick={() => {setReview({ ...review, visible: !review.visible })}}>Write Review
                  </Button>

                  </div>
                  }
                  {!localStorage.token &&
                  <div>
                    <Signin style={{ backgroundColor: '#00A1AF' }} className="btn btn-block text-white font-weight-bold py-2" btnTitle="Write Review (Sign In Required)"   />
                  </div>
                  }
                  </div>
                  <Dialog
                      open={review.visible}
                      onBackdropClick={() => setReview({ ...review, visible: !review.visible })}
                      maxWidth="md"
                  >
                  <DialogTitle style={{paddingBottom: "5px"}}><h2>{bandName} band review</h2></DialogTitle>
                  <DialogContent>
                    <DialogContentText variant="h6" >
                      Write reviews of your own experience with Costume bands during a Carnival.&nbsp;
                      <Link className="titleText" to="/how-are-costume-band-score" target={'_blank'}>Why Write?</Link>
                    </DialogContentText>
                    <CardContent className="my-2 px-0">
                      <div className="form-group">
                        <InputLabel>Year</InputLabel>
                        <Select fullWidth required name="year" value={review.year} onChange={editReview}>
                            {years && years.map(year => <MenuItem key={year} value={year}>{year}</MenuItem>)}
                        </Select>
                      </div>
                      <div className="form-group">
                        <InputLabel>Carnival</InputLabel>
                        <Select disabled={!review.year} value={review.fId} fullWidth required name="fId" onChange={editReview}>
                            {carnivals && carnivals.filter(carnival => carnival.year === review.year).map(carnival => <MenuItem key={carnival._id} value={carnival._id}>{carnival.festival.name} - {carnival.year}</MenuItem>)}
                        </Select>
                      </div>
                      <div className="form-group">
                        <InputLabel>Costume Band</InputLabel>
                        <Select disabled={!review.fId} fullWidth value={review.bdId} required name="bdId" onChange={editReview}>
                            {bands && bands.filter(band => band.dateId === review.fId).map(band => <MenuItem key={band._id} value={band._id}>{band.name}</MenuItem>)}
                        </Select>
                      </div>
                      <div className="form-group">
                        <InputLabel>Section</InputLabel>
                        <Select disabled={!review.bdId} fullWidth required value={review.sId} name="sId" onChange={editReview}>
                            {sections && sections.filter(section => section.bdId === review.bdId).map(section => <MenuItem key={section._id} value={section._id}>{section.name}</MenuItem>)}
                        </Select>
                      </div>
                      <div className="form-group">
                          <InputLabel>Share your photos and select your best costume image (Max 5)</InputLabel>
                          <input type="file" accept="image/*" multiple name="imgs" onChange={handleFiles} />
                          {review.imgs && review.imgs[0] ?
                            <div className="row">
                              {review.imgs.map((item, index) => 
                                <div className="col-md-6 py-3">
                                  <Radio 
                                    checked={item.isChaserImg}
                                    onClick={() => changeChaserImg(index)}
                                  />
                                  <img src={`data:${item.type};base64,${item.base64}`} 
                                    style={{maxHeight: "150px", maxWidth: "75%"}} onClick={() => changeChaserImg(index)}/>
                                  <IconButton aria-label="delete" onClick={() => removeReviewImg(index)}>
                                    <DeleteIcon fontSize="inherit" color="error"/>
                                  </IconButton>
                                </div>
                              )}
                            </div>
                          : ""}
                      </div>
                      <div className="form-group">
                          <InputLabel>Add Headline to your Review</InputLabel>
                          <TextField dir="auto" placeholder="Title" type="text" name="title" fullWidth required value={review.title} color="primary" onChange={editReview} />
                      </div>
                      <div className="row mb-3">
                        <div className="col-md-3 col-6 my-auto">Design:</div>
                        <div className="col-md-9 col-6 ">
                            <input alt="Service Rate" type="range" min="1" defaultValue={review.design || 0} max="5" step="0.5" className="col-sm-5 col-md-3" onMouseUp={(input) => { setRating("design", Number(input.target.value)) }}/>
                        </div>
                        <div className="col-md-3 col-6 my-auto">Food/Drink:</div>
                        <div className="col-md-9 col-6 ">
                            <input alt="Service Rate" type="range" min="1" defaultValue={review.food || 0} max="5" step="0.5" className="col-sm-5 col-md-3" onMouseUp={(input) => { setRating("food", Number(input.target.value)) }}/>
                        </div>
                        <div className="col-md-3 col-6 my-auto">Parade Road Vibes</div>
                        <div className="col-md-9 col-6 ">
                            <input alt="Service Rate" type="range" min="1" defaultValue={review.parade || 0} max="5" step="0.5" className="col-sm-5 col-md-3" onMouseUp={(input) => { setRating("parade", Number(input.target.value)) }}/>
                        </div>
                        <div className="col-md-3 col-6 my-auto">Events/Fetes:</div>
                        <div className="col-md-9 col-6 ">
                            <input alt="Service Rate" type="range" min="1" defaultValue={review.events || 0} max="5" step="0.5" className="col-sm-5 col-md-3" onMouseUp={(input) => { setRating("events", Number(input.target.value)) }}/>
                        </div>
                        <div className="col-md-3 col-6 my-auto">Customer Service:</div>
                        <div className="col-md-9 col-6 ">
                            <input alt="Service Rate" type="range" min="1" defaultValue={review.service || 0} max="5" step="0.5" className="col-sm-5 col-md-3" onMouseUp={(input) => { setRating("service", Number(input.target.value)) }}/>
                        </div>
                        {/* <div className="col-md-3 col-6 ">Canceled / No refund:</div>
                        <div className="col-md-9 col-6 ">
                          <Rate size={22} edit={true} value={review.noCancel || 0} onChange={(input) => { setRating("noCancel", input) }} />
                        </div>
                        <div className="col-md-3 col-6 ">Get what was paid for:</div>
                        <div className="col-md-9 col-6 ">
                          <Rate size={22} edit={true} value={review.wasPaidFor || 0} onChange={(input) => { setRating("wasPaidFor", input) }} />
                        </div> */}
                        <div className="col-md-3 col-6 mt-3">Overall Rating:</div>
                        <div className="col-md-9 col-6 mt-3">
                          {(review.average !=0)?
                            Number.parseFloat(review.average).toFixed(2)
                          :"--"}
                        </div>
                      </div>
                      <div className="form-group">
                          <InputLabel>Write details</InputLabel>
                          <TextField rows={3} dir="auto" placeholder="Text" type="text" name="text" multiline fullWidth value={review.text} variant="outlined" color="primary" onChange={editReview} />
                      </div>
                      <h6>{reviewThanksMessage}</h6>
                    </CardContent>
                  </DialogContent>
                  <DialogActions>
                      <Button className="m-2" variant="contained" onClick={() => setReview({ ...review, visible: false })}>Close</Button>
                      <Button className="m-2" variant="contained" color="primary" onClick={postReview}>Submit</Button>
                  </DialogActions>
              </Dialog>
            </>
          <Snackbar open={snackbar.isOpen} autoHideDuration={6000} onClose={handleSnackClose}>
            <Alert severity={snackbar.severity} sx={{ width: '100%' }}>
              {snackbar.msg}
            </Alert>
          </Snackbar>
      </div>
    )
}
