import React, { useState } from 'react';
import SideNav from 'react-simple-sidenav';
import {
    EmailShareButton,
    EmailIcon,
    FacebookShareButton,
    FacebookIcon,
    TwitterShareButton,
    TwitterIcon,
    ViberShareButton,
    ViberIcon,
    WhatsappShareButton,
    WhatsappIcon,
} from "react-share";
import '../assets/styles/ShareButton.css';
import { BiShareAlt } from "react-icons/all"
import { Button, Snackbar } from '@material-ui/core';
import { siteUrl } from '../functions/api';
import MuiAlert from '@material-ui/lab/Alert';

const ShareButton = ({ link, text }) => {

    const [showNav, setShowNav] = useState();
    const [snackbar, setSnackbar] = useState({});

    const url = `${siteUrl}${link}` || "https://hellocarnival.com";
    const title = text ? `Hello Carnival - ${text}` : 'Hello Carnival - Caribbean Carnivals';

    function copyClipboard() {
      try{
        navigator.clipboard.writeText(`${title}\n${url}`)
        setSnackbar({
          isOpen: true,
          msg: "Copied!",
          severity: "success",
        })
      } catch (err) {
        setSnackbar({
          isOpen: true,
          msg: "Can't copy!",
          severity: "error",
        })
      }
    }

    function copyOneClick() {
      setSnackbar({
        isOpen: true,
        msg: "Double click to copy link to clipboard",
        severity: "warning",
      })
    }

    function Alert(props) {
      return <MuiAlert elevation={6} variant="filled" {...props} />;
    }

    function handleSnackClose () {
      setSnackbar({
        isOpen: false,
        msg: "",
      })
    };

    const items = [
        <EmailShareButton url={url} subject={title}><EmailIcon size={40} /></EmailShareButton>,
        <FacebookShareButton url={url}><FacebookIcon size={40} /></FacebookShareButton>,
        <TwitterShareButton title={title} url={url}><TwitterIcon size={40} /></TwitterShareButton>,
        <ViberShareButton title={title} url={url}><ViberIcon size={40} /></ViberShareButton>,
        <WhatsappShareButton title={title} url={url}><WhatsappIcon size={40} /></WhatsappShareButton>,
        <button title="Double click to copy link to clipboard" onClick={copyOneClick} onDoubleClick={copyClipboard} style={{backgroundColor: "transparent", border: "none", font: "inherit", paddingLeft: "4px", color: "inherit", cursor: "pointer"}}>
          <svg viewBox="0 0 560 640" focusable="false" data-prefix="fal" data-icon="copy" 
            role="img" xmlns="http://www.w3.org/2000/svg" className="svg-inline--fa fa-copy fa-w-14 fa-fw fa-2x">
          <path fill="" d="M433.941 65.941l-51.882-51.882A48 48 0 0 0 348.118 0H176c-26.51 0-48 21.49-48 48v48H48c-26.51 0-48 21.49-48 48v320c0 26.51 21.49 48 48 48h224c26.51 0 48-21.49 48-48v-48h80c26.51 0 48-21.49 48-48V99.882a48 48 0 0 0-14.059-33.941zM352 32.491a15.88 15.88 0 0 1 7.431 4.195l51.882 51.883A15.885 15.885 0 0 1 415.508 96H352V32.491zM288 464c0 8.822-7.178 16-16 16H48c-8.822 0-16-7.178-16-16V144c0-8.822 7.178-16 16-16h80v240c0 26.51 21.49 48 48 48h112v48zm128-96c0 8.822-7.178 16-16 16H176c-8.822 0-16-7.178-16-16V48c0-8.822 7.178-16 16-16h144v72c0 13.2 10.8 24 24 24h72v240z"></path>
          </svg>
        </button>,        
    ]

    return (
        <>
            <Button variant="outlined" color="default" onClick={() => setShowNav(true)}>
                <BiShareAlt />&nbsp;
                <span>Share</span>
            </Button>
            <SideNav
                openFromRight={true}
                items={items}
                showNav={showNav}
                onHideNav={() =>
                    setShowNav(false)}
                titleStyle={{ display: 'none' }}
                itemStyle={{ listStyleType: 'none', padding: '5px', paddingLeft: "0px", outline: 'none', marginRight: "2rem"}}
                navStyle={{ backgroundColor: 'white', padding: '0', maxWidth: "7rem", paddingTop: '5rem' }}
            />
            <Snackbar open={snackbar.isOpen} autoHideDuration={6000} onClose={handleSnackClose}>
              <Alert severity={snackbar.severity} sx={{ width: '100%' }}>
                {snackbar.msg}
              </Alert>
            </Snackbar>
        </>
    );
};

export default ShareButton;
