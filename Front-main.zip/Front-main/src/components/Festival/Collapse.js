import { FormControlLabel, IconButton } from "@material-ui/core";
import { useState } from "react";
import { IoAdd, AiOutlineMinus } from "react-icons/all";

export default function Collapse(props) {
  const [state, setState] = useState(false);
  function handleChange(e) {
    e.preventDefault();
    setState(!state);
  }
  return (
    <>
      {props.notItem ? (
        <div>
          <FormControlLabel
            onClick={handleChange}
            control={
              <IconButton color="primary">
                {state ? <AiOutlineMinus /> : <IoAdd />}
              </IconButton>
            }
            label={
              <h3 className="titleText">{props.title && `${props.title}`}</h3>
            }
          />
          <div className={`d-${state ? "block" : "none"}`}>{props.content}</div>
        </div>
      ) : (
        <li className="list-group-item">
          <FormControlLabel
            onClick={handleChange}
            control={
              <IconButton color="primary">
                {state ? <AiOutlineMinus /> : <IoAdd />}
              </IconButton>
            }
            label={
              <h3 className="titleText">{props.title && `${props.title}`}</h3>
            }
          />
          <div className={`d-${state ? "block" : "none"}`}>{props.content}</div>
        </li>
      )}
    </>
  );
}
