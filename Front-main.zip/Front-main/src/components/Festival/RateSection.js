import Rate from "react-rating-stars-component";
import Popover from "../Popover";
import { BiGitCompare, VscFilter, MdSort } from "react-icons/all";
import Like from "../Like";
import { TextField, Button } from "@material-ui/core";
import { useEffect, useState } from "react";
import { addWatchList, checkInWatchList, removeWatchList } from "../../functions/api";
import { useHistory } from "react-router-dom";
import ShareButton from "../ShareButton";
import { GrStar } from "react-icons/all";

export default function RateSection(props) {
  const history = useHistory();
  const [watch, setWatch] = useState(false)
  const [score, setScore] = useState()
  const [ur, setUr] = useState()

  useEffect(() => {
    (async () => {
      var check = {}
      if (props.docID && props.collName)
        check = await checkInWatchList(props.docID, props.collName)
      if (check.code == 1) setWatch(check.data || false)
    })()
  }, [props.docID, props.collName])

  function handleCompare() {
    history.push(props.compare);
  }

  async function changeWatchList(e) {
    if(watch) {
      const res = await removeWatchList(watch._id);
      if (res && res.code === 1) {
        setWatch(null);
      }
    } else {
      const res = await addWatchList(props.docID, props.collName);
      if (res && res.code === 1) {
        setWatch(res.data);
      }
    }
  }

  useEffect(()=>{
    setScore(props.score)
    setUr(props.ur)
  },[props.ur, props.score])
  return (
    <div className="d-flex flex-row justify-content-between align-items-center flex-wrap">
      {typeof props.hot !== "undefined" && <Button variant="outlined"><i className="fa fa-fire fa-lg" style={{color:'rgb(255, 100, 0)'}}></i>&nbsp;{props.hot}</Button>}
      {props.title && <h5 className="px-2">{props.title}</h5>}
      {props.category && <h4 className="my-auto">
      {props.category}
      {/*{props.slug?<a  href={'/festivals/'+props.slug}>{props.category}</a>:props.category}  */}
      </h4>}
      {(score || ur )?
        <span className="rateSectionItem px-2 d-flex">
          {
            (score)?
            <>
              <h5 className="d-inline-block font-weight-bold">
                {Number(score).toFixed(1)}
              </h5>
              <span>/10 &nbsp;</span>
            </>
          :''}
          {
            
          (ur)?
            (score)?'| UR '+ ur.toFixed(1):'UR '+ ur.toFixed(1)
          :""} 
          {(ur)?
                <GrStar size={25} style={{ color: '#ffeb3b', verticalAlign:"middle"}} />
          :""}
        </span>
      :""}
      {props.rate &&
        <span className="d-flex px-2 rateSectionItem"><Rate className="mr-4" edit={false} value={props.rate} size="15px" />&nbsp;&nbsp;{props.rate}</span>
      }
      {props.search && <TextField className="searchField" label="Search" color="default" />}
      {props.like &&
        <span className="px-2 rateSectionItem"><Like collName={props.collName} docID={props.docID} /></span>
      }
      {props.sort && 
        <Popover handleOpen={props.handleSortsOpen} handleClose={props.handleSortsClose} open={props.sortsOpen}
          item={<span className="rateSectionItem"><MdSort />&nbsp;Sort</span>} id="sort" content={props.sort} />}
      {props.filter &&
        <Popover handleOpen={props.handleOpen} handleClose={props.handleClose} open={props.open} 
          item={<span><VscFilter />&nbsp;Filter</span>} id="filter" content={props.filter} />
      }
      {props.helpful &&
        <Button variant="text" color="default" className="px-2 rateSectionItem">+&nbsp;Helpful?</Button>
      }
      {props.compare && <Button onClick={handleCompare} color="default" variant="outlined" className="px-2 rateSectionItem"><BiGitCompare />&nbsp;Compare</Button>}
      {localStorage.token && props.wishlist &&
        <div className="px-2 rateSectionItem">
          <Button variant="outlined" color="default" onClick={changeWatchList}>
            {(watch)?
            <i className="far fa-check-square"></i>
            :
            <i className="far fa-square"></i>
            }
            <span>&nbsp;Watch List</span>
          </Button>
        </div>
      }
      {props.share && <ShareButton link={props.link} text={props.text} />}
      {props.sold && <SoldoutBadge number={props.sold} />}
    </div>
  )
}

function SoldoutBadge({ number }) {
  number = number ? number : 0;
  return (
    <span className={`text-white badge ${number < 40 ? 'badge-success' : number < 80 ? 'badge-warning' : 'badge-danger'}`}>
      {number}% Sold Out
    </span>
  )
}
