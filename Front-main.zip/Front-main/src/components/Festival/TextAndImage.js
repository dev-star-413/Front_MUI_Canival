import { Link } from "react-router-dom";
import generateAddressImg from "../../functions/generateAddressImg";

export default function TextAndImage(props) {
  const innerContent = [];
  let counter = 0;
  if (props.sections) {
    for (var sect of props.sections) {
      innerContent.push(
        <li className={`col-12 d-flex list-group-item flex-wrap-reverse`} key={counter++}>
          <div className="col-md-7 col-sm-12 d-flex flex-column mt-2">
            {sect.canceled && <h5 className="text-muted font-weight-bold">{sect.title}&nbsp;<small className="badge bg-danger text-white">{sect.canceled}</small></h5>}
            {!sect.canceled && <h5 className="subtitleText font-weight-bold">{sect.title}</h5>}
            {sect.sDesc && <p className="text-dark text-justify">{sect.sDesc}</p>}
            {props.type === "designers" &&
              <div>
                <h5 className="titleText font-weight-bolder">{sect.name}</h5>
                <p className="text-dark text-justify">{sect.about}</p>
              </div>}
            {props.type !== "news" && <Link className="text-secondary mt-auto" to={`/${props.type}/${sect.slug}`}>More...</Link>}
          </div>
          <Link className="col-md-5 col-sm-12 text-secondary mt-auto" to={`/${props.type}/${sect.slug}`}>
            <div className="zoomContainer">
              {/* <div className="bandPicture shadow zoom" style={{ backgroundImage: `url(${sect.imgs[0] && sect.imgs[0].path})` }} /> */}
              <img className="img-fluid" src={generateAddressImg(sect.imgs[0] && sect.imgs[0].path,300,400)}/>
            </div>
          </Link>
          {props.type === "news" && <p className="mt-4 text-dark text-justify">{sect.desc}</p>}
        </li>
      )
    }
  }
  return (
    <ul className="list-group list-group-flush">
      {innerContent}
    </ul>
  )
}