function FestivalTitle(props) {
    return (
        <div className="festival-title my-4">
            <h1 className="font-weight-bold text-dark">
                {props.year && `${props.year}&nbsp;`}{props.title && `${props.title}&nbsp;`}{props.page && props.page}
            </h1>
        </div>
    )
}

export default FestivalTitle;