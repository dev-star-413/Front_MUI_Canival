import Rate from "react-rating-stars-component";
import Flag from "../Flag";


function ThingsToDoItem(props) {
  const style = {
    color: '#292b2c ',
    backgroundColor: '#292b2c ',
    height: 1,
  }
  return (
    <div className="my-2 py-2 px-2 thingstodoItem">
      <h5>Things to Do</h5>
      <h6 className="d-flex">{props.type}&nbsp;|&nbsp;<Rate edit={false} count={5} value={5.0} size="15px" /></h6>
      <hr style={style} />
      <h6>Address</h6>
      <hr style={style} />
      <h6>[Image]</h6>
      <hr style={style} />
      <h5>Days and Hours</h5>
      <ul className="list-group list-group-flush mb-4">
        <li className="list-group-item thingstodoItem">Sunday</li>
        <li className="list-group-item thingstodoItem">Monday</li>
        <li className="list-group-item thingstodoItem">Tuesday</li>
        <li className="list-group-item thingstodoItem">Wednesday</li>
        <li className="list-group-item thingstodoItem">Thursday</li>
        <li className="list-group-item thingstodoItem">Friday</li>
        <li className="list-group-item thingstodoItem">Saturday</li>
      </ul>
      <h6>Price:</h6>
      <h5>What is it?</h5>
      <p></p>
      <h5>Why go?</h5>
      <p></p>
      <h5>Don't miss:</h5>
      <p></p>
      <Flag />
      <h5 className="mt-4">Web/Social</h5>
      <h6>Phone:</h6>
      <h6>Website:</h6>
      <h6>Instagram:</h6>
      <h6>Facebook:</h6>
    </div>
  )
}

export default ThingsToDoItem;