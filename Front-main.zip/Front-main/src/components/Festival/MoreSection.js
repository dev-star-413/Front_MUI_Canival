import { HiOutlineArrowDown } from "react-icons/all";
import Collapse from "./Collapse";

export default function MoreSection(props) {
  const items = props.items.map(item => (
    <Collapse title={item.title} content={item.content} />
  ));
  return (
    <div>
      <h3 className="ml-4 mt-2">More&nbsp;<HiOutlineArrowDown /></h3>
      <ul className="list-group list-group-flush">
        {items}
      </ul>
    </div>
  )
}