import Signin from "./Signin";
import { Link } from "react-router-dom";
import { useState } from "react";
import { GoThreeBars } from "react-icons/all";
import React from 'react';
import Dialog from '@material-ui/core/Dialog';
import IconButton from '@material-ui/core/IconButton';
import CloseIcon from '@material-ui/icons/Close';
import Slide from '@material-ui/core/Slide';
import ReviewForm from './modal/ReviewForm'

const Transition = React.forwardRef(function Transition(props, ref) {
    return <Slide direction="right" ref={ref} {...props} />;
});

export default function Sidebar(props) {
    // generate sidebar items
    let counter = 0;
    const [open, setOpen] = useState(false);
    const [openReview, setOpenReview] = useState(false)

    const handleClickOpen = () => {
        setOpen(true);
    };

    const handleClose = () => {
        setOpen(false);
    };
    const handleCloseReviewForm=()=>{
      setOpenReview(false)
      setOpen(false)
    }
    const handleOpenReviewForm=()=>{
      setOpenReview(true)
      setOpen(false)
    }
    const items = props.items.map(function (item) {
      if(item.target === 'UR'){
        return (
          <div key={counter++}>
            <Link onClick={handleOpenReviewForm}>
              <div className="sidebar-item px-4 pt-2 mx-4">{item.title}</div>
            </Link>
          </div>
        )  
      }
      return (
        <div key={counter++}>
          <Link to={item.target} onClick={handleClose}>
            <div className="sidebar-item px-4 pt-2 mx-4">{item.title}</div>
          </Link>
        </div>
      )
    });
    return (
      <>
        <span className="btn btn-dark navbar-button" id="toggler" onClick={handleClickOpen}>
          <GoThreeBars className="navbarIcon" />
        </span>
        <Dialog transitionDuration={{ enter: 250, exit: 125 }} open={open} onClose={handleClose} 
          TransitionComponent={Transition}>
            <div id="sidebar" className="col-12 col-md-3 px-0" style={{position: "fixed", left: "0", top: "0", overflowY: "hidden"}}>
              <IconButton color="inherit" onClick={handleClose} aria-label="close">
                <CloseIcon />
              </IconButton>
              <Link to="/">
                <h4 onClick={handleClose} className="mx-5 my-3 font-weight-bold">Hello Carnival</h4>
              </Link>
              {items}
              {/* <BandReview/> */}
              <Signin />
            </div>
        </Dialog>
        <ReviewForm open={openReview} handleClose={handleCloseReviewForm}/>
      </>
    )
}