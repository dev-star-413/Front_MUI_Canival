import { Button, Divider, IconButton } from "@material-ui/core";
import { useEffect, useState } from "react";
import { FaShare, CgChevronLeft, CgChevronRight } from "react-icons/all";
import { getQuotes } from "../functions/api";
import "../assets/styles/Quote.css";

export default function Quote() {
    const [quotes, setQuotes] = useState(null);
    const blocks = [];
    const [index, setIndex] = useState(0);
    useEffect(function () {
        loadData();
    });
    const loadData = async () => {
        if (!quotes) {
            setQuotes(await getQuotes());
        }
    }
    function setQuote(sign) {
        setIndex((index + sign) % Math.round((blocks.length / 2)))
    }
    if (quotes) {
        let number = 0;
        for (let quote of quotes) {
            if (number === 0) {
                blocks.push(
                    <div className="col-12 quoteBlock text-center" style={{ marginLeft: `${index * -200}%` }}>
                        <h3 className="font-weight-bold text-center quote"><i>“{quote.quote}”<br /><h4 className="mt-2">{quote.source}</h4></i></h3>
                        <Button variant="text" color="primary" className="mt-4"><FaShare />&nbsp;<b>Share</b></Button>
                    </div>
                )
            } else {
                blocks.push(
                    <div className="col-12 text-center">
                        <h3 className="font-weight-bold text-center quote"><i>“{quote.quote}”<br /><h4 className="mt-2">{quote.source}</h4></i></h3>
                        <Button variant="text" color="primary" className="mt-4"><FaShare />&nbsp;<b>Share</b></Button>
                    </div>
                )
            }
            number++;
        }
    }
    return (
        <section className="mx-1">
            <Divider className="my-5 mx-5" />
            <h6 className="text-center">People are saying:</h6>
            <div className="d-flex flex-row justify-content-between">
                <div className="align-self-center">
                    <IconButton disabled={index == blocks.length / 2} onClick={() => setQuote(-1)}>
                        <CgChevronLeft />
                    </IconButton>
                </div>
                <div className="d-flex flex-row quotesContainer flex-nowrap my-4 justify-content-center">
                    {blocks}
                </div>
                <div className="align-self-center">
                    <IconButton disabled={index == -blocks.length / 2} onClick={() => setQuote(1)}>
                        <CgChevronRight />
                    </IconButton>
                </div>
            </div>
            <Divider className="my-5 mx-5" />
        </section>
    )
}