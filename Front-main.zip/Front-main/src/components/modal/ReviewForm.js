import {
    Button, CardContent,
    InputLabel, MenuItem, Select, TextField,
    Dialog, DialogActions, DialogContent, DialogContentText,
    DialogTitle, Snackbar, IconButton,FormControl
} from "@material-ui/core";
import { useEffect, useState } from "react";
import {getFestivalsYear,getYearsHaveFestival,getBandsFestivalDate} from '../../functions/api'
import { Link } from "react-router-dom";
export default function ReviewForm({open,handleClose}) {
    // const [years, setYears] = useState()
    const [optionYears, setOptionYears] = useState()
    const [optionBands, setOptionBands] = useState()
    const [optionCarnivals, setOptionCarnivals] = useState()
    const [linkTo,setLinkTo]=useState('/')

    useEffect(()=>{

        if(open && !optionYears){
            getListYears()
        }
        setOptionCarnivals()
        setOptionBands()
        setLinkTo()

    },[open])

    const getListYears=async ()=>{
       let years= await getYearsHaveFestival()
       const content=[]
       for(let y of years){
            content.push(
                <MenuItem key={y} value={y}>{y}</MenuItem>
            )
        }
        setOptionYears(content)
        
    }
    

    const handleChangeYear=async (event)=>{
        // get carnivals of year
        const year=event.target.value
        console.log(year)
        let carnivals=await getFestivalsYear(year)
        console.log(carnivals)
        // const carnivals=['car-1','ca-2','ca-3','ca-4','ca-5']
        const arr=[]
        for(let car of carnivals){
            arr.push(
                <MenuItem key={car._id} value={car._id}>{car.festival && car.festival.name}</MenuItem>
                )
            }
        setOptionCarnivals(arr)
        setOptionBands()
        setLinkTo()


    }
    const handleChangeCarnival=async (event)=>{
        // get bands of carnival
        const date=event.target.value
        let res=await getBandsFestivalDate(date)
        console.log(res)
        if(res.code !=0) return // show msg error
        const bands=res.data
        // const bands=['band-1','band-2','band-3','band-4','band-5']
        if(!bands || !bands[0]) return
        const arr=[]
        for(let ba of bands){
            arr.push(
                <MenuItem key={ba._id} value={ba.slug}>{ba && ba.name}</MenuItem>
                )
            }
        setOptionBands(arr)
        setLinkTo()
    }
    const handleChangeBand=(event)=>{
        // get band link
        const slug=event.target.value
        setLinkTo(`/bands/${slug}#section-userreviews`)

    }

    return (
        <Dialog id="modalAddCompare"  maxWidth="sm"  open={open} onClose={handleClose}>
            <DialogTitle>To write or view Caribbean Carnival Costume Band Reviews</DialogTitle>
            <DialogContent>
                <div className="container">
                    <div className="row">
                        <div className="col-12 py-2">
                            <FormControl className="col-sm-12">
                            <InputLabel id="select-year-label">Select Year</InputLabel>
                            <Select id="selector-compare-year" labelId="select-year-label" name="year" onChange={handleChangeYear}  required>
                                {optionYears}
                            </Select>
                            </FormControl>
                        </div>
                        <div className="col-12 py-2">
                            <FormControl className="col-sm-12">
                            <InputLabel id="select-carnival-label" >Select Carnival</InputLabel>
                            <Select disabled={!optionCarnivals} id="selector-carnival-band" labelId="select-carnival-label" name="carnival" onChange={handleChangeCarnival} required>
                                {optionCarnivals}
                            </Select>
                            </FormControl>
                        </div>

                        <div className="col-12 py-2">
                            <FormControl className="col-sm-12">
                            <InputLabel id="select-band-label" >Select Band</InputLabel>
                            <Select disabled={!optionBands} id="selector-compare-band" labelId="select-band-label" name="band" onChange={handleChangeBand} required>
                                {optionBands}
                            </Select>
                            </FormControl>
                        </div>
                        {/* <div className="col-12 py-2">
                            <FormControl className="col-sm-12">
                            <InputLabel id="select-section-label">Select Section</InputLabel>
                            <Select id="selector-compare-section" labelId="select-section-label" name="section" onChange={changeSection}>
                                {optionSections}
                            </Select>
                            </FormControl>
                        </div> */}
                    </div>
                </div>
            </DialogContent>
            <DialogActions>
                {(linkTo)?
                    <Link to={linkTo} onClick={handleClose} style={{color:'blue',padding:'10px'}} >Next</Link>:
                    <span title="disable" style={{padding:'10px'}}>Next</span>
                }
            </DialogActions>
    </Dialog>
    )
}