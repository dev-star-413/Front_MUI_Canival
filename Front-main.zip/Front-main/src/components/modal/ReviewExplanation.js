import { Dialog, DialogContent,
    DialogTitle, IconButton,
} from "@material-ui/core";
import CloseIcon from '@material-ui/icons/Close';

import { useState } from "react";
export default function ReviewExplanation({}) {
    // const [years, setYears] = useState()
    const [open, setOpen] = useState(false)

    const handleOpen=()=>{
        setOpen(true)
    }
    const handleClose=()=>{
        setOpen(false)
    }


    return (
        <div className="text-center my-2">
        <a className="text-decoration-none" href="javascript: void(0)" onClick={handleOpen}>View Explanation</a>
        <Dialog   maxWidth="sm"  open={open} onClose={handleClose} aria-labelledby="modalExplanationTitle">
            <DialogTitle  className="align-item-center" >
                <b>Use the following to guide your rating and review.</b>
                <IconButton className="float-right" aria-label="close" onClick={handleClose}>
                    <CloseIcon />
                </IconButton>
            </DialogTitle>
            <DialogContent >
                <div className="container">
                    <div >
                        <h5>Costumes </h5>
                        <span className="col" >-Promo images vs. What you got vs. Sturdiness.</span>
                    </div>
                    <div className="my-1">
                        <h5>Food & Drinks</h5>
                        <span className="col">-Choices, varieties and flowing beverage. </span>
                    </div>
                    <div className="my-1">
                        <h5>Parade Road Vibes </h5>
                        <span className="col">-Vibe of the band on the road, Djs, entertainers, good people. </span>
                    </div>
                    <div className="my-1">
                        <h5>Events/Fetes</h5>
                        <span className="col">-How were other events by this band or their partners? </span>
                    </div>
                    <div className="my-1">
                        <h5>Customer Service</h5>
                        <span className="col">-Organizers planned for everything and or quickly answered questions or resolved issues.</span>
                    </div>
                </div>
            </DialogContent>
        </Dialog>
    </div>
    )
}