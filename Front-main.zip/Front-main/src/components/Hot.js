import GaugeChart from "react-gauge-chart/dist/GaugeChart";
import { useState } from "react";
import { updateSectionReview } from "../functions/api";
import { Button } from "@material-ui/core";
import { Link } from "react-router-dom";
import "../assets/styles/RangeInput.css";
import generateAddressImg from '../functions/generateAddressImg'
export default function Hot({ average, section }) {

    const [data, setData] = useState({
        docID: section._id,
        rate: 4,
        collName: 'section',
    });

    const [avg, setAverage] = useState(average);

    function handleChange(e) {
        setData({ ...data, rate: e.target.value });
    }

    async function submit() {
        const res = await updateSectionReview(data);
        if (res && res.code === 0) {
            setData({ ...data, rate: 4 });
            setAverage(res.data);
        }
    }
    return (
        <div className="my-3 py-2" style={{ backgroundColor: '#f9fbe7' }}>
            <div className="d-flex flex-column align-items-center py-3">
                    <h3 className="d-inline-block font-weight-bold">
                        {(avg!=0)?avg:"-"}
                        <small className="text-center">
                            {(avg!=0)?'/5 -'  : ""} {section.name}
                        </small>
                    </h3>

                {section.img &&  <img src={generateAddressImg(section.img.path,100,100)} className="img-fluid"/>}
            </div>
            <GaugeChart
                className="mx-auto"
                arcsLength={[0.2, 0.2, 0.2, 0.2, 0.2]}
                colors={['#283593', '#b3e5fc', '#fff176', '#fb8c00', '#dd2c00']}
                percent={avg / 5 || 0.5}
                style={{ height: '13rem', width: '45%' }}
            />
            <div className="d-flex flex-column justify-content-center align-items-center">
                <Link className="my-3 titleText" to="/how-hot">View Rating Tips</Link>
                <h5 className="text-center">Hot or Not? (<b>{data.rate}</b> / 5)</h5>
                <input alt="Hotnesss Rate" type="range" name="rate" min="0" value={data.rate} max="5" step="0.1" className="col-sm-10 col-md-6" onChange={handleChange} />
                <Button className="my-2" variant="outlined" color="default" onClick={submit}>SUBMIT</Button>
            </div>
        </div>
    )
}