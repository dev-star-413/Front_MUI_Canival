import { Button, Popover } from "@material-ui/core";
import { useState } from "react";

export default function PopoverPage(props) {
    const [anchorEl, setAnchorEl] = useState(null);
    const handleClick = (event) => {
        setAnchorEl(event.currentTarget);
        props.handleOpen && props.handleOpen();
    }
    const handleClose = () => {
        setAnchorEl(null);
        props.handleClose && props.handleClose();
    }
    const open = typeof props.open === 'undefined' ? Boolean(anchorEl) : props.open && Boolean(anchorEl);
    const id = open ? props.id : undefined;
    return (
        <div className="my-auto">
            <Button aria-describedby={id} variant="outlined" color="default" onClick={handleClick}>{props.item}</Button>
            <Popover
                id={id}
                open={open}
                anchorEl={anchorEl}
                onClose={handleClose}
                anchorOrigin={{
                    vertical: 'bottom',
                    horizontal: 'center',
                }}
                transformOrigin={{
                    vertical: 'top',
                    horizontal: 'center',
                }}
            >
                {props.content}
            </Popover>
        </div>
    )
}
