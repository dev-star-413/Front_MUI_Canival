import { SiTwitter, FaFacebook, FiInstagram } from "react-icons/all";
import { Link } from "react-router-dom";

function footer(props) {
  return (
    <footer className=" py-4 text-white" style={{backgroundColor: "#181716"}}>
      <div className="container d-flex flex-row flex-wrap">
        <div className="col-xs-12 col-sm-6 col-md-3">
          <div style={{fontWeight: "bolder", fontSize: "1.15rem"}}>About Us</div>
          <hr style={{backgroundColor: "white", marginTop: "5px", marginBottom: "5px"}}/>
          <Link className="text-white" target={'_blank'} to={`/our-story`} style={{display:"block", fontSize: "14px", lineHeight: "22px"}}>Our story</Link>
          <Link className="text-white" target={'_blank'} to={`/faq`} style={{display:"block", fontSize: "14px", lineHeight: "22px"}}>FAQs</Link>
          <Link className="text-white" target={'_blank'} to={`/privacy-policy`} style={{display:"block", fontSize: "14px", lineHeight: "22px"}}>Privacy Policy</Link>
          <Link className="text-white" target={'_blank'} to={`/legal-terms`} style={{display:"block", fontSize: "14px", lineHeight: "22px"}}>Legal Terms</Link>
          <Link className="text-white" target={'_blank'} to={`/advertise`} style={{display:"block", fontSize: "14px", lineHeight: "22px"}}>Advertise</Link>
          <Link className="text-white" target={'_blank'} to={`/contact-us`} style={{display:"block", fontSize: "14px", lineHeight: "22px"}}>Contact Us</Link>
        </div>
        <div className="col-xs-12 col-sm-6 col-md-3">
          <div style={{fontWeight: "bolder", fontSize: "1.15rem"}}>For Organizers</div>
          <hr style={{backgroundColor: "white", marginTop: "5px", marginBottom: "5px"}}/>
          <Link className="text-white" target={'_blank'} to={`/advertise-with-us`} style={{display:"block", fontSize: "14px", lineHeight: "22px"}}>Advertise With Us</Link>
          <Link className="text-white" target={'_blank'} to={`/adding-your-event`} style={{display:"block", fontSize: "14px", lineHeight: "22px"}}>Adding Your Event</Link>
          <Link className="text-white" target={'_blank'} to={`/adding-your-mas-band`} style={{display:"block", fontSize: "14px", lineHeight: "22px"}}>Adding Your Mas band</Link>
        </div>
        <div className="col-xs-12 col-sm-6 col-md-3">
          <div style={{fontWeight: "bolder", fontSize: "1.15rem"}}>Our Links</div>
          <hr style={{backgroundColor: "white", marginTop: "5px", marginBottom: "5px"}}/>
          <Link className="text-white" to={`/festivals`} style={{display:"block", fontSize: "14px", lineHeight: "22px"}}>Carnival</Link>
          <Link className="text-white" to={`/events`} style={{display:"block", fontSize: "14px", lineHeight: "22px"}}>Events & Fetes</Link>
          <Link className="text-white" to={`/blogs`} style={{display:"block", fontSize: "14px", lineHeight: "22px"}}>Blog</Link>
        </div>
        <div className="col-xs-12 col-sm-6 col-md-3">
          <div style={{fontWeight: "bolder", fontSize: "1.15rem"}}>Find Us</div>
          <hr style={{backgroundColor: "white", marginTop: "5px", marginBottom: "5px"}}/>
          <div style={{display:"block", fontSize: "14px", lineHeight: "22px"}}><a className="text-white" href="https://www.instagram.com/realhellocarnival/"><FiInstagram className="instagram" style={{fontSize: "14px"}}/> Instagram </a></div>
          <div style={{display:"block", fontSize: "14px", lineHeight: "22px"}}><FaFacebook className="facebook" style={{fontSize: "14px"}}/> Facebook</div>
          <div style={{display:"block", fontSize: "14px", lineHeight: "22px"}}><SiTwitter className="twitter" style={{fontSize: "14px"}}/> Twitter</div>
        </div>
        <div className="col-md-12" style={{color: "#e6e6e6", fontSize: "13px", paddingTop: "5px"}}>
          &#169;{new Date().getFullYear()} Festivals. All Rights Reserved.
        </div>
      </div>

    </footer>
  )
}

export default footer;