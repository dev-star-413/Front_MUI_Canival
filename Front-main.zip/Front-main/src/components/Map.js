import React, { useEffect, useState } from 'react';
import "leaflet/dist/leaflet.css";
import L from "leaflet";
import "leaflet-polylinedecorator";
import "leaflet.locatecontrol/dist/L.Control.Locate.min.css";
import "leaflet.locatecontrol/dist/L.Control.Locate.min.js";
import "leaflet-fullscreen/dist/leaflet.fullscreen.css";
import "leaflet-fullscreen/dist/Leaflet.fullscreen.min.js";
import "@fortawesome/fontawesome-free/css/all.css"
import markerIcon from '../assets/imgs/marker.png'
export default function Map(props) {
  const [clientMap, setClientMap] = useState(null);
  // const [allWayPoints, setAllWayPoints] = useState([null]);
  const [arrowMarkers, setArrowMarkers] = useState([]);
  const [routeLayer, setRouteLayer] = useState(null);
  const [marker, setMarker] = useState(null);

  useEffect(() => {
    if(!clientMap){
      const map = new L.map("clientMap", {
        zoomControl: false,
        fullscreenControl: {
          position: "topright",
        },
      }).setView([40.7484, -73.9857], 13);
      map.scrollWheelZoom.disable();
      L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", {
        attribution: "© OpenStreetMap contributors",
        maxZoom: 19,
      }).addTo(map);
      L.control
        .zoom({
          position: "bottomright",
        })
        .addTo(map);

      setClientMap(map);
    }
  }, [])

  function geometryToJeoJson(route) {
    let jeoJson = [];
    for (let i = 0; i < route.legs.length; i++) {
      const leg = route.legs[i];
      for (let j = 0; j < leg.steps.length; j++) {
        const step = leg.steps[j];
        const thisStepGeoCor = step.geometry.coordinates;
        for (let k = 0; k < thisStepGeoCor.length; k++) {
          if (thisStepGeoCor[k + 1]) {
            jeoJson.push({
              type: "LineString",
              coordinates: [thisStepGeoCor[k], thisStepGeoCor[k + 1]],
            });
          }
        }
      }
    }
    return jeoJson;
  }
  useEffect(()=>{
    if(props.city && clientMap){
      if((!props.paradeGeo || !props.paradeGeo.routes) && (!props.marker || !props.marker.lat))
        clientMap.setView(props.city)
    }
  },[props.city,clientMap])

  useEffect(() => {
    if (
      clientMap &&
      props.paradeGeo &&
      props.paradeGeo.routes
    ) {
      if (routeLayer) {
        clientMap.removeLayer(routeLayer);
      }
      for (let arrow of arrowMarkers) {
        clientMap.removeLayer(arrow);
      }

      let tempArrowMarkers = [];
      const jeoJson = geometryToJeoJson(props.paradeGeo.routes[0]);
      const tempRouteLayer = L.geoJSON(jeoJson, {
        onEachFeature: function (feature, layer) {
          const thisDecorator = L.polylineDecorator(layer, {
            patterns: [
              {
                offset: 10,
                repeat: 0,
                symbol: L.Symbol.arrowHead({
                  pixelSize: 7,
                  polygon: false,
                  pathOptions: { stroke: true },
                }),
              },
            ],
          }).addTo(clientMap);
          tempArrowMarkers.push(thisDecorator);
        },
      }).addTo(clientMap);
      
      L.control
        .locate({
          keepCurrentZoomLevel: true,
          drawCircle: false,
          icon: "fas fa-crosshairs",
          position: "bottomright",
        })
        .addTo(clientMap);
      setRouteLayer(tempRouteLayer);
      setArrowMarkers(tempArrowMarkers);
      clientMap.fitBounds(tempRouteLayer.getBounds());
    }
  }, [props.paradeGeo, clientMap]);

  useEffect(()=>{
    if(clientMap && props.marker &&props.marker.lat ){
      var latlng=props.marker
      if(marker) clientMap.removeControl(marker);
      var icon = L.icon({
        iconUrl: markerIcon,
        iconSize: [25, 41],
        iconAnchor: [12, 41],
      });
      let newMarker=new L.marker(latlng, {
            draggable: false,
            icon: icon,
        });
        newMarker.addTo(clientMap)
        clientMap.setView(latlng)
        setMarker(newMarker)
        setClientMap(clientMap)
    }
  },[props.marker, clientMap])
  useEffect(()=>{
    if(props.address && marker) marker.bindPopup(props.address || 'No Address').openPopup()
  },[props.address,marker])

  return (
    <div>
      <div style={{height: props.height || "75vh", width: "100%",zIndex:'1'}} id="clientMap" />
    </div>
  )
}
