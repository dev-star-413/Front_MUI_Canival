import { useEffect, useState } from "react";
import FadeLoader from "react-spinners/FadeLoader";
import {Snackbar} from "@material-ui/core";
import MuiAlert from '@material-ui/lab/Alert';
import * as api from '../functions/api';

function Alert(props) {
  return <MuiAlert elevation={6} variant="filled" {...props} />;
}

export default function LoginByOtp(props) {
  const [errMsg, setErrMsg] = useState("");

  useEffect(()=>{
    const {otp} = props.match.params;
    if(!otp) {
      setErrMsg("No otp passed");
    }

    login(otp)
  },[])

  const login = async (otp) => {
    try{
      const result = await api.logInByOtp({otp});
      if(result.code !== 0) {
        setErrMsg(result.msg);
      } else {
        localStorage.setItem("token", result.data.token);
        window.location.href = "/"
      }
    } catch (err) {
      setErrMsg(err.message);
    }
  }

  return (
    <>
      <div style={{position: "fixed", top: "50%", left: "50%", transform: "translate(-50%, -50%)"}}>
        <FadeLoader size={150}/>
      </div>
      <Snackbar open={!!errMsg} autoHideDuration={10000} onClose={() => setErrMsg("")}>
        <Alert severity="error" sx={{ width: '100%' }}>
          {errMsg}
        </Alert>
      </Snackbar>    
    </>
  )
}