import generateAddressImg from "../functions/generateAddressImg";

export default function AddOn({ index, title, price, img }) {
    return (
        <div  key={index} className="row my-5">
            <div className="col-12 col-md-3 ">
                <img src={generateAddressImg(img,330,440)} className="img-fluid" alt="AddOn"/>
            </div>
            <div className="col-12 col-md-9 text-dark">
                <h5>
                    {title} {price ? `+$${price} USD` : ''}
                </h5>
            </div>
        </div>
    )
}