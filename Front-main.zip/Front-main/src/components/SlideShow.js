import React, {useEffect, useState, useRef} from 'react';
import { Slide } from 'react-slideshow-image';
import 'react-slideshow-image/dist/styles.css'
import "../assets/styles/SlideShow.css";
import {  Dialog, DialogContent, DialogTitle, DialogActions, Button } from "@material-ui/core";

const Slideshow = ({ images: imagesFromProps, open, handleAction, type, sectionIndex, selected, dialogTitle, continuous ,handleSliderChooseSection,sectionsList}) => {
  const [images, setImages] = useState([]);
  const [selectImage, setSelected] = useState([]);
  const [typeState, setTypeState] = useState(type)
  const slideRef = useRef();
  const [showListSections,setShowListSections]=useState(null)
  useEffect(()=>{
    setImages(imagesFromProps)
  }, [imagesFromProps])

  useEffect(()=>{
    setTypeState(type)
  }, [type])

  useEffect(()=>{
    setSelected(selected)
  },[selected])

  useEffect(()=>{
    setShowListSections(null)
    if(open && selectImage) {
      if(typeState === "list") {
        var readyCheckInterval = setInterval(() => {
          if(checkIfReady()) {
            clearInterval(readyCheckInterval);
          }
        }, 10);
      } else {
        var readyCheckInterval2 = setInterval(() => {
          if(checkIfReady2()) {
            clearInterval(readyCheckInterval2);
          }
        }, 10);
      }

      return () => {
        clearInterval(readyCheckInterval);
        clearInterval(readyCheckInterval2);
      }
    }
  },[open, selectImage, typeState])

  function checkIfReady() {
    const el = document.getElementById(selectImage)
    if(el.complete) {
      el.scrollIntoView({behavior: "smooth"});
      return true;
    } else {
      return false;
    }
  }

  function checkIfReady2() {
    if(slideRef.current) {
      slideRef.current.goTo(images.findIndex(item => item._id == selectImage))
      return true;
    }
    return false;
  }

  function handleChange(prevIndex, currIndex) {
    if(continuous && prevIndex === images.length-1 && currIndex === 0) {
      if(sectionsList && sectionsList[0]){
        var list=[]
        for(let section of sectionsList){
          let el=<div className='col-md-4' key={section._id}>
              <a href="javascript: void(0)" onClick={()=>{
                setShowListSections(null)
                handleAction()
                handleSliderChooseSection(section._id)
              }}>{section.name}</a>
            </div>
            list.push(el)
        }
        setShowListSections(
          <div className='col-12'>
            <h5 className='pt-2'>Sections List</h5>
            <div className='row'>
              {list}
            </div>
          </div>
        )
      }

      // const showNext = window.confirm("You've reached to the end of this section. Would you like to continue see next section's images?")
      // if(showNext) {
      //   handleAction();
      //   document.getElementById("showSlide" + (parseInt(sectionIndex)+1)) && document.getElementById("showSlide" + (parseInt(sectionIndex)+1)).click()
      // }
    }
  }

  return (
    <div>
    <Dialog
      open={open}
      onClose={handleAction}
      aria-labelledby="scroll-dialog-title"
      aria-describedby="scroll-dialog-description"
      style={{ maxWidth: 'auto' }}
    >

      <div>
        {dialogTitle ? 
          <DialogTitle className='pb-0' id="scroll-dialog-title"><span dangerouslySetInnerHTML={{__html: dialogTitle}}></span></DialogTitle> :
          <DialogTitle className='pb-0' id="scroll-dialog-title">View {typeState}</DialogTitle> 
        }
        <div className='pl-4 pb-2'>
          {typeState === "list" ? 
            <a href="javascript: void(0)" onClick={() => setTypeState("slideShow")}>Switch to slide show view</a> :
            <a href="javascript: void(0)" onClick={() => setTypeState("list")}>Switch to list view</a>
          }
        </div>
          <DialogContent className="d-flex flex-column pt-0" style={{ overflowY: `${typeState == "list" ? "auto" : "hidden"}` }} id="dialogContent">
          {(showListSections)?
              showListSections :
              <div>
                {images.length > 0 && typeState != 'list' &&
                    <Slide easing="ease" onChange={handleChange} ref={slideRef}>
                        { images.map((image, index) =>
                            <div className="each-slide" key={index} id={image._id}>
                                {(image.mime && image.mime.includes('video'))
                                    ? 
                                    <>
                                    <video width='100%' style={{objectFit:'center'}} height="90%"  controls> <source src={image && image.img} typeState={image && image.mime}/></video>
                                    <br/>
                                    <h6 className="text-center">
                                    {image.name} {image.deposit && `$${image.deposit} USD`}
                                    </h6>
                                    </>
                                    :
                                    <div  className="slideShowImage d-flex" style={{ 'backgroundImage': `url("${image.img}")`, width: "100%"}}>
                                        <h6 className="mt-auto mx-auto text-center backgroundText">
                                            {image.name} {image.deposit && `$${image.deposit} USD`}
                                            <br />
                                            {(image.bandName || image.dateName)? 
                                            <span>{image.bandName} - {image.dateName} {image.year}</span>:"" }
                                            
                                        </h6>
                                    </div>
                                }    

                            </div>
                        )}
                    </Slide>                                
                }
              </div>
            }
              {images && typeState == 'list' && images.length > 0 && images.map((image, index) => {
                  return(
                    <div className={typeState != "list" ? "col-12": ""} key={index} >
                      <div className="mb-4">
                        {(image.mime && image.mime.includes('video'))
                        ?
                          <>
                          <video width='100%' height='90%' controls id={image._id}> <source src={image && image.img} typeState={image && image.mime}/></video>
                          <br/>
                          <h6 className="text-center">
                              {image.name} {image.deposit && `$${image.deposit} USD`}
                          </h6>
                          </>
                        :
                          <>
                          <img alt={image.name} src={image && image.img} width="100%" id={image._id} height="auto"/>
                          <h6 className="text-center pt-1">
                              {image.name} {image.price && `$${image.price} USD`}
                              <br />
                              {(image.bandName || image.dateName)? 
                                  <span>{image.bandName} - {image.dateName} {image.year}</span>:"" }
                          </h6>
                          </>
                        }               
                      </div>
                    </div>
                  )                    
              })}
              {(typeState == 'list' && !showListSections && sectionsList && Array.isArray(sectionsList) && sectionsList[0])?
              <div>
                <h5 className='pt-2'>Sections List</h5>
                  <div className='row'>
                  {sectionsList.map((section)=>{
                    return(
                      <div className='col-md-4' key={section._id}>
                        <a href="javascript: void(0)" onClick={()=>{
                          setShowListSections(null)
                          handleAction()
                          handleSliderChooseSection(section._id)
                        }}>{section.name}</a>
                      </div>
                    )
                  })}
                </div>
              </div>
              :"" 
            }
 
          </DialogContent>
      </div>
    
        <DialogActions>
            <Button onClick={handleAction} color="default">
                Close
            </Button>
        </DialogActions>
    </Dialog>
    </div>
  )
};

export default Slideshow;