import { IconButton, InputBase, makeStyles, Paper } from "@material-ui/core";
import { useState } from "react";
import { IoFlag, RiSendPlaneFill } from "react-icons/all";

const useStyles = makeStyles((theme) => ({
  root: {
    padding: '2px 10px',
    alignItems: 'center',
    width: "100%",
  },
  input: {
    flex: 1,
  },
  iconButton: {
    padding: 10,
  }
}));

export default function Flag() {
  const classes = useStyles();
  const [open, setOpen] = useState(false);
  const [desc, setDesc] = useState(null);
  function modify() {
    setOpen(!open);
  }
  function editForm(event) {
    setDesc(event.target.value);
  }
  function submit() {
    // send report message
    setDesc("");
    modify();
  }
  return (
    <div className="mb-3">
      <span className="flag" onClickCapture={modify} >
        <IoFlag />&nbsp;<small>Flag?</small>
      </span>
      <small>&nbsp;Let us know!</small>
      <Paper component="form" className={`my-3 d-${open ? "flex" : "none"} ${classes.root}`}>
        <InputBase
          className={classes.input}
          placeholder="Message"
          multiline
          onChangeCapture={editForm}
          value={desc || ""}
        />
        <IconButton color="secondary" type="button" className={classes.iconButton} aria-label="send" onClickCapture={submit}>
          <RiSendPlaneFill />
        </IconButton>
      </Paper>
    </div>
  )
}